package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.AdminRepository;
import com.example.myapplication.your.model.AppUserAdminRow;

import java.util.List;

public class AdminUsersViewModel extends AndroidViewModel {

    private final AdminRepository repository;
    private final MutableLiveData<List<AppUserAdminRow>> users = new MutableLiveData<>();
    private final MutableLiveData<String> error = new MutableLiveData<>();
    private final MutableLiveData<Boolean> loading = new MutableLiveData<>();

    public AdminUsersViewModel(@NonNull Application application) {
        super(application);
        repository = AdminRepository.getInstance(application);
    }

    public LiveData<List<AppUserAdminRow>> getUsers() { return users; }
    public LiveData<String> getError() { return error; }
    public LiveData<Boolean> getLoading() { return loading; }

    public void loadUsers() {
        loading.setValue(true);
        new Thread(() -> {
            try {
                List<AppUserAdminRow> list = repository.listAppUsers();
                users.postValue(list);
            } catch (Exception e) {
                error.postValue(e.getMessage() != null ? e.getMessage() : e.toString());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void updateRole(String userId, String newRole) {
        loading.setValue(true);
        new Thread(() -> {
            try {
                repository.patchUserRole(userId, newRole);
                List<AppUserAdminRow> list = repository.listAppUsers();
                users.postValue(list);
            } catch (Exception e) {
                error.postValue(e.getMessage() != null ? e.getMessage() : e.toString());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void clearError() {
        error.setValue(null);
    }
}
