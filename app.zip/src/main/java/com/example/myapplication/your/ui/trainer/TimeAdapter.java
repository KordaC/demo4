package com.example.myapplication.your.ui.trainer;

import androidx.core.content.ContextCompat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TimeAdapter extends RecyclerView.Adapter<TimeAdapter.TimeViewHolder> {

    private List<String> times;
    private List<String> busyTimes;
    private OnTimeClickListener listener;
    private LocalDate selectedDate = LocalDate.now();

    public interface OnTimeClickListener {
        void onClick(String time);
    }

    public TimeAdapter(List<String> times, List<String> busyTimes, OnTimeClickListener listener) {
        this.times = times != null ? times : new ArrayList<>();
        this.busyTimes = busyTimes != null ? busyTimes : new ArrayList<>();
        this.listener = listener;
    }

    public void setBusyTimes(List<String> busyTimes) {
        this.busyTimes = busyTimes != null ? busyTimes : new ArrayList<>();
        notifyDataSetChanged();
    }

    public void setSelectedDate(LocalDate date) {
        this.selectedDate = date;
        notifyDataSetChanged();
    }

    private List<String> visibleSlots() {
        LocalDate today = LocalDate.now();
        if (selectedDate == null || !selectedDate.equals(today)) {
            return times;
        }
        LocalDateTime now = LocalDateTime.now();
        List<String> out = new ArrayList<>();
        DateTimeFormatter hm = DateTimeFormatter.ofPattern("HH:mm");
        for (String t : times) {
            try {
                LocalTime slot = LocalTime.parse(t, hm);
                LocalDateTime slotStart = today.atTime(slot);
                if (slotStart.isAfter(now)) {
                    out.add(t);
                }
            } catch (Exception e) {
                out.add(t);
            }
        }
        return out;
    }

    @NonNull
    @Override
    public TimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_time, parent, false);
        return new TimeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TimeViewHolder holder, int position) {
        List<String> slots = visibleSlots();
        if (position >= slots.size()) return;
        String time = slots.get(position);
        boolean busy = busyTimes.contains(time);

        holder.timeText.setText(busy ? time + "\nЗанято" : time);
        int freeBg = ContextCompat.getColor(holder.itemView.getContext(), R.color.primary_blue_soft);
        int busyBg = ContextCompat.getColor(holder.itemView.getContext(), R.color.slot_busy_bg);
        int busyTextColor = ContextCompat.getColor(holder.itemView.getContext(), R.color.slot_busy_text);
        holder.timeText.setBackgroundColor(busy ? busyBg : freeBg);
        holder.timeText.setTextColor(busy ? busyTextColor : ContextCompat.getColor(holder.itemView.getContext(), R.color.text_primary));
        holder.itemView.setEnabled(!busy);
        holder.itemView.setOnClickListener(busy ? null : v -> {
            if (listener != null) listener.onClick(time);
        });
    }

    @Override
    public int getItemCount() {
        return visibleSlots().size();
    }

    static class TimeViewHolder extends RecyclerView.ViewHolder {

        TextView timeText;

        public TimeViewHolder(@NonNull View itemView) {
            super(itemView);
            timeText = itemView.findViewById(R.id.timeText);
        }
    }
}
