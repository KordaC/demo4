package com.example.myapplication.your.data;

import android.content.Context;
import android.util.Log;

import com.example.myapplication.your.model.TrainerProfile;
import com.example.myapplication.your.model.TrainerReview;
import com.example.myapplication.your.model.TrainingDirection;
import com.example.myapplication.your.util.AppUserDisplayName;
import com.example.myapplication.your.util.JsonResponseUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
// Репозиторий для работы с тренерами, направлениями и отзывами
public class TrainerRepository {
    private static final String TAG = "TrainerRepository";
    private static TrainerRepository instance;
    private final Context appContext;
    private final String supabaseUrl;
    private final String supabaseKey;

    private TrainerRepository(Context context) {
        appContext = context.getApplicationContext();
        supabaseUrl = SupabaseClientProvider.getSupabaseUrl();
        supabaseKey = SupabaseClientProvider.getSupabaseAnonKey();
    }

    public static synchronized TrainerRepository getInstance(Context context) {
        if (instance == null) {
            instance = new TrainerRepository(context);
        }
        return instance;
    }
    // Получает ID профиля тренера по ID пользователя
    public String getTrainerProfileIdByAppUserId(String appUserId) throws Exception {
        if (appUserId == null || appUserId.trim().isEmpty()) return null;
        String url = supabaseUrl + "/rest/v1/trainer_profile?user_id=eq." + appUserId.trim()
                + "&select=id&limit=1";
        String json = makeGetRequest(url);
        if (json == null || json.trim().isEmpty() || "[]".equals(json.trim())) return null;
        JSONArray arr = JsonResponseUtil.requireArray(json);
        if (arr.length() == 0) return null;
        String id = arr.getJSONObject(0).optString("id", "");
        return id.isEmpty() ? null : id;
    }
    // Получает список всех тренеров
    public List<TrainerProfile> getAllTrainers() throws Exception {
        String sel;
        try {
            sel = URLEncoder.encode(
                    "id,user_id,bio,experience_years,specializations,photo_url,app_user(name),trainer_review(rating)",
                    StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            sel = "*";
        }
        String urlEmbed = supabaseUrl + "/rest/v1/trainer_profile?select=" + sel + "&order=id.asc";
        String urlPlain = supabaseUrl + "/rest/v1/trainer_profile?select=*&order=id.asc";
        try {
            String jsonResponse = makeGetRequest(urlEmbed);
            List<TrainerProfile> list = parseTrainerProfilesResponse(jsonResponse);
            enrichTrainerReviewStatsFromTable(list);
            if (jsonResponse != null && !jsonResponse.trim().isEmpty()) {
                UiDataCache.getInstance(appContext).putTrainersJson(jsonResponse);
            }
            return list;
        } catch (Exception e) {
            Log.w(TAG, "trainer_profile embed failed (HTTP или Could not embed), fallback *", e);
            String jsonResponse = makeGetRequest(urlPlain);
            List<TrainerProfile> list = parseTrainerProfilesResponse(jsonResponse);
            enrichTrainerReviewStatsFromTable(list);
            if (jsonResponse != null && !jsonResponse.trim().isEmpty()) {
                UiDataCache.getInstance(appContext).putTrainersJson(jsonResponse);
            }
            return list;
        }
    }
    // Получает тренеров из кэша
    public List<TrainerProfile> getAllTrainersFromCache() {
        try {
            String raw = UiDataCache.getInstance(appContext).getTrainersJson();
            if (raw == null || raw.trim().isEmpty()) return null;
            List<TrainerProfile> list = parseTrainerProfilesResponse(raw);
            enrichTrainerReviewStatsFromTable(list);
            return list;
        } catch (Exception e) {
            Log.w(TAG, "getAllTrainersFromCache", e);
            return null;
        }
    }
    // Парсит JSON-ответ с тренерами
    private List<TrainerProfile> parseTrainerProfilesResponse(String jsonResponse) throws Exception {
        List<TrainerProfile> list = new ArrayList<>();
        if (jsonResponse == null || jsonResponse.trim().isEmpty()) return list;
        JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
        java.util.LinkedHashSet<String> missingUserIds = new java.util.LinkedHashSet<>();
        for (int i = 0; i < arr.length(); i++) {
            TrainerProfile p = mapTrainerProfile(arr.getJSONObject(i));
            list.add(p);
            if (p != null) {
                String uid = p.getUserId() != null ? p.getUserId().trim() : "";
                String nm = p.getName() != null ? p.getName().trim() : "";
                if (!uid.isEmpty() && (nm.isEmpty() || "Тренер".equalsIgnoreCase(nm))) {
                    missingUserIds.add(uid);
                }
            }
        }

        if (!missingUserIds.isEmpty()) {
            try {
                Map<String, String> namesById = loadAppUserDisplayNamesByIds(missingUserIds);
                for (TrainerProfile p : list) {
                    if (p == null) continue;
                    String uid = p.getUserId() != null ? p.getUserId().trim() : "";
                    if (uid.isEmpty()) continue;
                    String nm = p.getName() != null ? p.getName().trim() : "";
                    if (!nm.isEmpty() && !"Тренер".equalsIgnoreCase(nm)) continue;
                    String dn = namesById.get(uid);
                    if (dn != null && !dn.trim().isEmpty()) {
                        p.setName(dn.trim());
                    }
                }
            } catch (Exception e) {
                Log.w(TAG, "Could not enrich trainer names from app_user", e);
            }
        }
        return list;
    }
    // Получает тренера по ID
    public TrainerProfile getTrainerById(String trainerId) throws Exception {
        if (trainerId == null || trainerId.trim().isEmpty()) return null;
        String sel;
        try {
            sel = URLEncoder.encode(
                    "id,user_id,bio,experience_years,specializations,photo_url,app_user(name),trainer_review(rating)",
                    StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            sel = "*";
        }
        String tid = trainerId.trim();
        String urlEmbed = supabaseUrl + "/rest/v1/trainer_profile?id=eq." + tid + "&select=" + sel + "&limit=1";
        String urlPlain = supabaseUrl + "/rest/v1/trainer_profile?id=eq." + tid + "&select=*&limit=1";
        try {
            String jsonResponse = makeGetRequest(urlEmbed);
            JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
            if (arr.length() == 0) return null;
            TrainerProfile p = mapTrainerProfile(arr.getJSONObject(0));
            enrichTrainerNameIfMissing(p);
            enrichTrainerReviewStatsFromTable(java.util.Collections.singletonList(p));
            try {
                if (p.getRating() == null) {
                    enrichTrainerStatsFromReviewList(p, getReviews(tid));
                }
            } catch (Exception ex) {
                Log.w(TAG, "getTrainerById getReviews stats enrichment", ex);
            }
            return p;
        } catch (Exception e) {
            Log.w(TAG, "getTrainerById embed failed, fallback *", e);
            String jsonResponse = makeGetRequest(urlPlain);
            JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
            if (arr.length() == 0) return null;
            TrainerProfile p = mapTrainerProfile(arr.getJSONObject(0));
            enrichTrainerNameIfMissing(p);
            enrichTrainerReviewStatsFromTable(java.util.Collections.singletonList(p));
            try {
                if (p.getRating() == null) {
                    enrichTrainerStatsFromReviewList(p, getReviews(tid));
                }
            } catch (Exception ex) {
                Log.w(TAG, "getTrainerById getReviews stats enrichment", ex);
            }
            return p;
        }
    }

    private static void enrichTrainerStatsFromReviewList(TrainerProfile p, List<TrainerReview> reviews) {
        if (p == null || reviews == null || reviews.isEmpty()) return;
        double sum = 0;
        int n = 0;
        for (TrainerReview r : reviews) {
            if (r == null) continue;
            int rv = r.getRating();
            if (rv > 0) {
                sum += rv;
                n++;
            }
        }
        if (n > 0) {
            p.setRating(sum / n);
            p.setReviewCount(n);
        }
    }
    // Получает тренеров по списку ID
    public List<TrainerProfile> getTrainersByIds(List<String> trainerIds) throws Exception {
        if (trainerIds == null || trainerIds.isEmpty()) {
            return new ArrayList<>();
        }
        StringBuilder inClause = new StringBuilder();
        for (String raw : trainerIds) {
            if (raw == null) continue;
            String id = raw.trim();
            if (id.isEmpty()) continue;
            if (inClause.length() > 0) inClause.append(',');
            inClause.append(id);
        }
        if (inClause.length() == 0) {
            return new ArrayList<>();
        }
        String sel;
        try {
            sel = URLEncoder.encode(
                    "id,user_id,bio,experience_years,specializations,photo_url,app_user(name),trainer_review(rating)",
                    StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            sel = "*";
        }
        String urlEmbed = supabaseUrl + "/rest/v1/trainer_profile?id=in.(" + inClause + ")&select=" + sel;
        String urlPlain = supabaseUrl + "/rest/v1/trainer_profile?id=in.(" + inClause + ")&select=*";
        try {
            String jsonResponse = makeGetRequest(urlEmbed);
            List<TrainerProfile> list = parseTrainerProfilesResponse(jsonResponse);
            enrichTrainerReviewStatsFromTable(list);
            return list;
        } catch (Exception e) {
            Log.w(TAG, "getTrainersByIds embed failed, fallback *", e);
            String jsonResponse = makeGetRequest(urlPlain);
            List<TrainerProfile> list = parseTrainerProfilesResponse(jsonResponse);
            enrichTrainerReviewStatsFromTable(list);
            return list;
        }
    }
    // Получает все направления тренировок
    public List<TrainingDirection> getAllDirections() throws Exception {
        String url = supabaseUrl + "/rest/v1/training_direction?select=*&order=name.asc";
        String jsonResponse = makeGetRequest(url);
        Log.d("DEBUG", "Ответ от Supabase: " + jsonResponse);
        if (jsonResponse != null && !jsonResponse.trim().isEmpty()) {
            UiDataCache.getInstance(appContext).putDirectionsJson(jsonResponse);
        }
        return parseDirectionsResponse(jsonResponse);
    }
    // Получает направления из кэша
    public List<TrainingDirection> getAllDirectionsFromCache() {
        try {
            String raw = UiDataCache.getInstance(appContext).getDirectionsJson();
            if (raw == null || raw.trim().isEmpty()) return null;
            return parseDirectionsResponse(raw);
        } catch (Exception e) {
            Log.w(TAG, "getAllDirectionsFromCache", e);
            return null;
        }
    }
    // Парсит JSON направлений
    private List<TrainingDirection> parseDirectionsResponse(String jsonResponse) throws Exception {
        List<TrainingDirection> list = new ArrayList<>();
        if (jsonResponse == null || jsonResponse.trim().isEmpty()) return list;
        JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            TrainingDirection d = new TrainingDirection();
            d.setId(o.optString("id"));
            d.setName(o.optString("name"));
            d.setDescription(o.optString("description", null));
            if (d.getDescription() != null && d.getDescription().isEmpty()) d.setDescription(null);
            d.setIconUrl(o.optString("icon_url", null));
            if (d.getIconUrl() != null && d.getIconUrl().isEmpty()) d.setIconUrl(null);
            list.add(d);
        }
        return list;
    }
    // Получает направления конкретного тренера
    public List<TrainingDirection> getTrainerDirections(String trainerId) throws Exception {
        if (trainerId == null || trainerId.trim().isEmpty()) return new ArrayList<>();
        String sel;
        try {
            sel = URLEncoder.encode("direction_id,training_direction(id,name,description,icon_url)", StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            sel = "*";
        }
        String tid = trainerId.trim();
        String urlEmbed = supabaseUrl + "/rest/v1/trainer_direction?trainer_id=eq." + tid + "&select=" + sel;
        String urlPlain = supabaseUrl + "/rest/v1/trainer_direction?trainer_id=eq." + tid + "&select=*";
        try {
            return parseTrainerDirectionsResponse(makeGetRequest(urlEmbed));
        } catch (Exception e) {
            Log.w(TAG, "trainer_direction embed failed (HTTP / embed / парсинг), fallback *", e);
            return parseTrainerDirectionsResponse(makeGetRequest(urlPlain));
        }
    }
    // Парсит ответ с направлениями тренера
    private List<TrainingDirection> parseTrainerDirectionsResponse(String jsonResponse) throws Exception {
        Map<String, TrainingDirection> byId = new LinkedHashMap<>();
        java.util.LinkedHashSet<String> directionIds = new java.util.LinkedHashSet<>();
        JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject row = arr.getJSONObject(i);
            String did = row.optString("direction_id", "").trim();
            if (!did.isEmpty()) directionIds.add(did);
            if (!row.has("training_direction") || row.isNull("training_direction")) continue;
            JSONObject td = row.getJSONObject("training_direction");
            TrainingDirection d = new TrainingDirection();
            d.setId(td.optString("id"));
            d.setName(td.optString("name"));
            d.setDescription(td.optString("description", null));
            if (d.getDescription() != null && d.getDescription().isEmpty()) d.setDescription(null);
            d.setIconUrl(td.optString("icon_url", null));
            if (d.getIconUrl() != null && d.getIconUrl().isEmpty()) d.setIconUrl(null);
            if (d.getId() != null && !d.getId().isEmpty()) {
                byId.put(d.getId(), d);
            }
        }
        if (byId.isEmpty() && !directionIds.isEmpty()) {
            List<TrainingDirection> all = getAllDirections();
            for (TrainingDirection d : all) {
                if (d != null && d.getId() != null && directionIds.contains(d.getId())) {
                    byId.put(d.getId(), d);
                }
            }
        }
        return new ArrayList<>(byId.values());
    }
    // Отправляет отзыв на тренера
    public String submitReview(String userId, String trainerId, int rating, String comment) {
        if (userId == null || trainerId == null) return "Неверные данные";
        if (rating < 1) rating = 1;
        if (rating > 5) rating = 5;
        String uid = userId.trim();
        String tid = trainerId.trim();
        if (uid.isEmpty() || tid.isEmpty()) return "Неверные данные";
        try {
            String existingId = findTrainerReviewRowId(uid, tid);
            JSONObject patchBody = new JSONObject();
            patchBody.put("rating", rating);
            patchBody.put("comment", comment != null ? comment : "");
            if (existingId != null && !existingId.isEmpty()) {
                // Обновляем существующий отзыв
                String url = supabaseUrl + "/rest/v1/trainer_review?id=eq." + existingId;
                makePatchRequest(url, patchBody.toString());
                return null;
            }
            // Создаём новый отзыв
            JSONObject body = new JSONObject();
            body.put("user_id", uid);
            body.put("trainer_id", tid);
            body.put("rating", rating);
            body.put("comment", comment != null ? comment : "");
            try {
                makePostJsonRequest(supabaseUrl + "/rest/v1/trainer_review", body.toString());
            } catch (Exception insertEx) {
                String msg = insertEx.getMessage() != null ? insertEx.getMessage() : "";
                if (msg.contains("23505") || msg.contains("409")) {
                    String rid = findTrainerReviewRowId(uid, tid);
                    if (rid != null && !rid.isEmpty()) {
                        String url = supabaseUrl + "/rest/v1/trainer_review?id=eq." + rid;
                        makePatchRequest(url, patchBody.toString());
                        return null;
                    }
                }
                throw insertEx;
            }
            return null;
        } catch (Exception e) {
            Log.e(TAG, "submitReview", e);
            return e.getMessage() != null ? e.getMessage() : e.toString();
        }
    }
    // Ищет ID отзыва по пользователю и тренеру
    private String findTrainerReviewRowId(String userId, String trainerId) {
        try {
            String u = userId.trim();
            String t = trainerId.trim();
            if (u.isEmpty() || t.isEmpty()) return null;
            String url1 = supabaseUrl + "/rest/v1/trainer_review?trainer_id=eq." + t + "&user_id=eq." + u + "&select=id&limit=1";
            String id = firstIdFromTrainerReviewGet(url1);
            if (id != null) return id;
            String url2 = supabaseUrl + "/rest/v1/trainer_review?trainer_profile_id=eq." + t + "&user_id=eq." + u + "&select=id&limit=1";
            return firstIdFromTrainerReviewGet(url2);
        } catch (Exception e) {
            Log.w(TAG, "findTrainerReviewRowId", e);
            return null;
        }
    }

    private String firstIdFromTrainerReviewGet(String url) throws Exception {
        String json = makeGetRequest(url);
        JSONArray arr = JsonResponseUtil.requireArray(json);
        if (arr.length() == 0) return null;
        String id = arr.getJSONObject(0).optString("id", "").trim();
        return id.isEmpty() ? null : id;
    }
    // Получает список отзывов на тренера
    public List<TrainerReview> getReviews(String trainerId) throws Exception {
        if (trainerId == null || trainerId.trim().isEmpty()) return new ArrayList<>();
        String sel;
        try {
            sel = URLEncoder.encode("id,user_id,rating,comment,created_at,app_user(name)", StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            sel = "*";
        }
        String tid = trainerId.trim();
        String urlEmbed = supabaseUrl + "/rest/v1/trainer_review?trainer_id=eq." + tid
                + "&select=" + sel + "&order=created_at.desc";
        String urlPlain = supabaseUrl + "/rest/v1/trainer_review?trainer_id=eq." + tid + "&select=*&order=created_at.desc";
        try {
            List<TrainerReview> list = parseReviewsJson(makeGetRequest(urlEmbed));
            if (list != null && !list.isEmpty()) return list;
            return tryLoadReviewsByAltTrainerColumn(tid, sel);
        } catch (Exception e) {
            Log.w(TAG, "trainer_review embed failed, fallback *", e);
            List<TrainerReview> list = parseReviewsJson(makeGetRequest(urlPlain));
            if (list != null && !list.isEmpty()) return list;
            return tryLoadReviewsByAltTrainerColumn(tid, sel);
        }
    }

    private List<TrainerReview> tryLoadReviewsByAltTrainerColumn(String trainerId, String selEncodedOrStar) {
        try {
            String tid = trainerId != null ? trainerId.trim() : "";
            if (tid.isEmpty()) return new ArrayList<>();
            String urlEmbedAlt = supabaseUrl + "/rest/v1/trainer_review?trainer_profile_id=eq." + tid
                    + "&select=" + selEncodedOrStar + "&order=created_at.desc";
            String urlPlainAlt = supabaseUrl + "/rest/v1/trainer_review?trainer_profile_id=eq." + tid
                    + "&select=*&order=created_at.desc";
            try {
                return parseReviewsJson(makeGetRequest(urlEmbedAlt));
            } catch (Exception e) {
                Log.w(TAG, "trainer_review alt column embed failed, fallback *", e);
                return parseReviewsJson(makeGetRequest(urlPlainAlt));
            }
        } catch (Exception e) {
            Log.w(TAG, "tryLoadReviewsByAltTrainerColumn failed", e);
            return new ArrayList<>();
        }
    }
    // Парсит JSON отзывов
    private List<TrainerReview> parseReviewsJson(String jsonResponse) throws Exception {
        List<TrainerReview> list = new ArrayList<>();
        JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault());
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            int r = o.optInt("rating", 0);
            String c = o.optString("comment", "");
            String createdRaw = o.optString("created_at", "");
            String createdDisplay = "";
            if (!createdRaw.isEmpty()) {
                try {
                    Instant inst = Instant.parse(createdRaw);
                    createdDisplay = fmt.format(inst);
                } catch (Exception ignored) {
                    createdDisplay = createdRaw;
                }
            }
            TrainerReview tr = new TrainerReview(r, c, createdDisplay);
            tr.setId(o.optString("id", null));
            tr.setUserId(o.optString("user_id", null));
            if (o.has("app_user") && !o.isNull("app_user")) {
                JSONObject au = o.getJSONObject("app_user");
                tr.setUserName(AppUserDisplayName.fromAppUserJson(au));
            }
            list.add(tr);
        }
        java.util.LinkedHashSet<String> needNames = new java.util.LinkedHashSet<>();
        for (TrainerReview tr : list) {
            if (tr == null) continue;
            String un = tr.getUserName() != null ? tr.getUserName().trim() : "";
            String uid = tr.getUserId() != null ? tr.getUserId().trim() : "";
            if (un.isEmpty() && !uid.isEmpty()) needNames.add(uid);
        }
        if (!needNames.isEmpty()) {
            try {
                Map<String, String> byId = loadAppUserDisplayNamesByIds(needNames);
                for (TrainerReview tr : list) {
                    if (tr == null || tr.getUserId() == null) continue;
                    String un = tr.getUserName() != null ? tr.getUserName().trim() : "";
                    if (!un.isEmpty()) continue;
                    String dn = byId.get(tr.getUserId().trim());
                    if (dn != null && !dn.trim().isEmpty()) tr.setUserName(dn.trim());
                }
            } catch (Exception e) {
                Log.w(TAG, "parseReviewsJson enrich names", e);
            }
        }
        return list;
    }
    // Преобразует JSON в объект TrainerProfile
    private TrainerProfile mapTrainerProfile(JSONObject json) throws org.json.JSONException {
        TrainerProfile p = new TrainerProfile();
        p.setId(json.optString("id"));
        p.setUserId(json.optString("user_id"));
        p.setBio(json.optString("bio", null));
        if (p.getBio() != null && p.getBio().isEmpty()) p.setBio(null);
        if (json.has("experience_years") && !json.isNull("experience_years")) {
            try {
                p.setExperienceYears(json.getInt("experience_years"));
            } catch (Exception e) {
                p.setExperienceYears(null);
            }
        }
        p.setPhotoUrl(json.optString("photo_url", null));
        if (p.getPhotoUrl() != null && p.getPhotoUrl().isEmpty()) p.setPhotoUrl(null);

        List<String> specs = new ArrayList<>();
        if (json.has("specializations") && !json.isNull("specializations")) {
            Object sp = json.get("specializations");
            if (sp instanceof JSONArray) {
                JSONArray a = (JSONArray) sp;
                for (int i = 0; i < a.length(); i++) {
                    specs.add(a.optString(i));
                }
            } else if (sp instanceof String) {
                String s = ((String) sp).trim();
                if (s.startsWith("{") && s.endsWith("}")) {
                    String inner = s.substring(1, s.length() - 1);
                    for (String part : inner.split(",")) {
                        String t = part.trim().replaceAll("^\"|\"$", "");
                        if (!t.isEmpty()) specs.add(t);
                    }
                }
            }
        }
        p.setSpecializations(specs.isEmpty() ? null : specs);

        if (json.has("app_user") && !json.isNull("app_user")) {
            JSONObject au = json.getJSONObject("app_user");
            p.setName(au.optString("name", "Тренер"));
        }
        if (p.getName() == null || p.getName().isEmpty()) {
            p.setName("Тренер");
        }

        double sum = 0;
        int count = 0;
        if (json.has("trainer_review") && !json.isNull("trainer_review")) {
            Object rev = json.get("trainer_review");
            if (rev instanceof JSONArray) {
                JSONArray ra = (JSONArray) rev;
                for (int i = 0; i < ra.length(); i++) {
                    JSONObject rj = ra.optJSONObject(i);
                    if (rj != null && rj.has("rating")) {
                        sum += rj.optDouble("rating", 0);
                        count++;
                    }
                }
            }
        }
        if (count > 0) {
            p.setRating(sum / count);
            p.setReviewCount(count);
        } else {
            p.setRating(null);
            p.setReviewCount(0);
        }
        return p;
    }
    private void enrichTrainerReviewStatsFromTable(List<TrainerProfile> list) {
        if (list == null || list.isEmpty()) return;
        List<String> idList = new ArrayList<>();
        for (TrainerProfile p : list) {
            if (p == null) continue;
            String id = p.getId();
            if (id != null && !id.trim().isEmpty()) idList.add(id.trim());
        }
        if (idList.isEmpty()) return;
        final int chunkSize = 40;
        Map<String, RatingAgg> merged = new HashMap<>();
        for (int i = 0; i < idList.size(); i += chunkSize) {
            int end = Math.min(i + chunkSize, idList.size());
            List<String> chunk = idList.subList(i, end);
            try {
                Map<String, RatingAgg> part = fetchReviewAggregatesForTrainerChunk(chunk);
                for (Map.Entry<String, RatingAgg> e : part.entrySet()) {
                    RatingAgg dst = merged.computeIfAbsent(e.getKey(), k -> new RatingAgg());
                    dst.sum += e.getValue().sum;
                    dst.count += e.getValue().count;
                }
            } catch (Exception e) {
                Log.w(TAG, "enrichTrainerReviewStatsFromTable chunk failed", e);
            }
        }
        for (TrainerProfile p : list) {
            if (p == null) continue;
            String pid = p.getId();
            if (pid == null) continue;
            RatingAgg a = merged.get(pid.trim());
            if (a != null && a.count > 0) {
                p.setRating(a.sum / a.count);
                p.setReviewCount(a.count);
            }
        }
        List<TrainerProfile> needAggProfiles = new ArrayList<>();
        for (TrainerProfile p : list) {
            if (p == null) continue;
            String pid = p.getId();
            if (pid == null) continue;
            int cnt = p.getReviewCount() != null ? p.getReviewCount() : 0;
            if (cnt > 0) continue;
            needAggProfiles.add(p);
        }
        if (needAggProfiles.isEmpty()) return;
        int n = needAggProfiles.size();
        int pool = Math.min(8, Math.max(2, n));
        ExecutorService ex = Executors.newFixedThreadPool(pool);
        try {
            List<Future<?>> futures = new ArrayList<>(n);
            for (TrainerProfile p : needAggProfiles) {
                final TrainerProfile tp = p;
                final String tid = p.getId().trim();
                futures.add(ex.submit(() -> {
                    RatingAgg fb = fetchReviewAggregateForSingleProfile(tid);
                    if (fb != null && fb.count > 0) {
                        tp.setRating(fb.sum / fb.count);
                        tp.setReviewCount(fb.count);
                    }
                }));
            }
            for (Future<?> fu : futures) {
                try {
                    fu.get(45, TimeUnit.SECONDS);
                } catch (Exception e) {
                    Log.w(TAG, "enrich parallel review agg", e);
                }
            }
        } finally {
            ex.shutdown();
        }
    }
    // Получает агрегированную статистику отзывов для одного тренера
    private RatingAgg fetchReviewAggregateForSingleProfile(String profileId) {
        if (profileId == null || profileId.isEmpty()) return null;
        RatingAgg agg = new RatingAgg();
        Set<String> seenReviewIds = new HashSet<>();
        String selEnc;
        try {
            selEnc = URLEncoder.encode("id,rating", StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            selEnc = "id,rating";
        }
        try {
            String url1 = supabaseUrl + "/rest/v1/trainer_review?trainer_id=eq." + profileId + "&select=" + selEnc;
            accumulateReviewRatingsFromRows(JsonResponseUtil.requireArray(makeGetRequest(url1)), agg, seenReviewIds);
        } catch (Exception e) {
            Log.w(TAG, "fetchReviewAggregate trainer_id=eq " + profileId, e);
        }
        try {
            String url2 = supabaseUrl + "/rest/v1/trainer_review?trainer_profile_id=eq." + profileId + "&select=" + selEnc;
            accumulateReviewRatingsFromRows(JsonResponseUtil.requireArray(makeGetRequest(url2)), agg, seenReviewIds);
        } catch (Exception e) {
            Log.w(TAG, "fetchReviewAggregate trainer_profile_id=eq " + profileId, e);
        }
        return agg.count > 0 ? agg : null;
    }
    // Накопление статистики из строк отзывов
    private void accumulateReviewRatingsFromRows(JSONArray arr, RatingAgg agg, Set<String> seenReviewIds) {
        if (arr == null || agg == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject row = arr.optJSONObject(i);
            if (row == null) continue;
            String rid = row.optString("id", "").trim();
            if (!rid.isEmpty()) {
                if (!seenReviewIds.add(rid)) continue;
            }
            double r = parseRatingForAggregate(row);
            if (r <= 0) continue;
            agg.sum += r;
            agg.count++;
        }
    }

    private Map<String, RatingAgg> fetchReviewAggregatesForTrainerChunk(List<String> chunk) throws Exception {
        Map<String, RatingAgg> byProfile = new HashMap<>();
        if (chunk == null || chunk.isEmpty()) return byProfile;
        Set<String> chunkSet = new HashSet<>();
        StringBuilder inB = new StringBuilder();
        for (String raw : chunk) {
            if (raw == null) continue;
            String id = raw.trim();
            if (id.isEmpty()) continue;
            chunkSet.add(id);
            if (inB.length() > 0) inB.append(',');
            inB.append(id);
        }
        if (inB.length() == 0) return byProfile;

        String selEnc = URLEncoder.encode("id,rating,trainer_id,trainer_profile_id", StandardCharsets.UTF_8.name());
        String inClause = inB.toString();
        Set<String> seenReviewIds = new HashSet<>();
        String urlByTrainerId = supabaseUrl + "/rest/v1/trainer_review?trainer_id=in.(" + inClause + ")&select=" + selEnc;
        String urlByProfileId = supabaseUrl + "/rest/v1/trainer_review?trainer_profile_id=in.(" + inClause + ")&select=" + selEnc;
        try {
            mergeReviewRowsIntoAggregates(JsonResponseUtil.requireArray(makeGetRequest(urlByTrainerId)), chunkSet, byProfile, seenReviewIds);
        } catch (Exception e) {
            Log.w(TAG, "fetchReviewAggregates trainer_id=in", e);
        }
        try {
            mergeReviewRowsIntoAggregates(JsonResponseUtil.requireArray(makeGetRequest(urlByProfileId)), chunkSet, byProfile, seenReviewIds);
        } catch (Exception e) {
            Log.w(TAG, "fetchReviewAggregates trainer_profile_id=in", e);
        }
        return byProfile;
    }

    private void mergeReviewRowsIntoAggregates(JSONArray arr, Set<String> chunkSet, Map<String, RatingAgg> byProfile, Set<String> seenReviewIds) {
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject row = arr.optJSONObject(i);
            if (row == null) continue;
            String rid = row.optString("id", "").trim();
            if (!rid.isEmpty()) {
                if (!seenReviewIds.add(rid)) continue;
            }
            double r = parseRatingForAggregate(row);
            if (r <= 0) continue;
            String tid = row.optString("trainer_id", "").trim();
            String tpid = row.optString("trainer_profile_id", "").trim();
            String profileKey;
            if (!tid.isEmpty() && chunkSet.contains(tid)) profileKey = tid;
            else if (!tpid.isEmpty() && chunkSet.contains(tpid)) profileKey = tpid;
            else continue;
            RatingAgg agg = byProfile.computeIfAbsent(profileKey, k -> new RatingAgg());
            agg.sum += r;
            agg.count++;
        }
    }

    private static double parseRatingForAggregate(JSONObject row) {
        if (row == null || !row.has("rating") || row.isNull("rating")) return 0;
        try {
            return row.getDouble("rating");
        } catch (Exception ignored) {
        }
        try {
            return row.getInt("rating");
        } catch (Exception ignored) {
        }
        try {
            String s = row.optString("rating", "").trim().replace(',', '.');
            if (s.isEmpty()) return 0;
            return Double.parseDouble(s);
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static final class RatingAgg {
        double sum;
        int count;
    }

    private void enrichTrainerNameIfMissing(TrainerProfile p) {
        try {
            if (p == null) return;
            String uid = p.getUserId() != null ? p.getUserId().trim() : "";
            if (uid.isEmpty()) return;
            String nm = p.getName() != null ? p.getName().trim() : "";
            if (!nm.isEmpty() && !"Тренер".equalsIgnoreCase(nm)) return;
            java.util.LinkedHashSet<String> ids = new java.util.LinkedHashSet<>();
            ids.add(uid);
            Map<String, String> byId = loadAppUserDisplayNamesByIds(ids);
            String dn = byId.get(uid);
            if (dn != null && !dn.trim().isEmpty()) {
                p.setName(dn.trim());
            }
        } catch (Exception e) {
            Log.w(TAG, "enrichTrainerNameIfMissing", e);
        }
    }

    private Map<String, String> loadAppUserDisplayNamesByIds(java.util.Set<String> userIds) throws Exception {
        Map<String, String> result = new LinkedHashMap<>();
        if (userIds == null || userIds.isEmpty()) return result;
        StringBuilder inB = new StringBuilder();
        for (String raw : userIds) {
            if (raw == null) continue;
            String id = raw.trim();
            if (id.isEmpty()) continue;
            if (inB.length() > 0) inB.append(',');
            inB.append(id);
        }
        if (inB.length() == 0) return result;

        String url = supabaseUrl + "/rest/v1/app_user?id=in.(" + inB + ")&select=id,name,last_name";
        String json = makeGetRequest(url);
        JSONArray arr = JsonResponseUtil.requireArray(json);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject row = arr.getJSONObject(i);
            String id = row.optString("id", "").trim();
            if (id.isEmpty()) continue;
            String name = AppUserDisplayName.fromAppUserJson(row);
            if (name != null && !name.trim().isEmpty()) {
                result.put(id, name.trim());
            }
        }
        return result;
    }
    // HTTP GET запрос
    private String makeGetRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        applyAuthHeaders(conn);

        int code = conn.getResponseCode();
        BufferedReader reader;
        if (code >= 400) {
            reader = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
        } else {
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        if (code >= 400) {
            Log.w(TAG, "GET " + urlString + " -> " + code + " " + sb);
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }
    private void applyAuthHeaders(HttpURLConnection conn) {
        conn.setRequestProperty("apikey", supabaseKey);
        String tok = SharedPrefManager.getInstance(appContext).getAccessToken();
        if (tok != null && !tok.trim().isEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer " + tok.trim());
        } else {
            conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        }
        conn.setRequestProperty("Content-Type", "application/json");
    }
    // HTTP POST запрос
    private void makePostJsonRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        applyAuthHeaders(conn);
        conn.setRequestProperty("Prefer", "return=minimal");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }
        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader er = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = er.readLine()) != null) sb.append(line);
            er.close();
            throw new Exception("HTTP " + code + ": " + sb);
        }
    }
    // HTTP PATCH запрос
    private void makePatchRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PATCH");
        applyAuthHeaders(conn);
        conn.setRequestProperty("Prefer", "return=minimal");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }
        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader er = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = er.readLine()) != null) sb.append(line);
            er.close();
            throw new Exception("HTTP " + code + ": " + sb);
        }
    }
}
