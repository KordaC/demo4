package com.example.myapplication.your.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class TrainerPtRow implements Serializable {
    private final String id;
    private final LocalDateTime startTime;
    private final String clientName;
    private final String status;

    public TrainerPtRow(String id, LocalDateTime startTime, String clientName, String status) {
        this.id = id;
        this.startTime = startTime;
        this.clientName = clientName != null ? clientName : "";
        this.status = status != null ? status : "";
    }

    public String getId() { return id; }
    public LocalDateTime getStartTime() { return startTime; }
    public String getClientName() { return clientName; }
    public String getStatus() { return status; }

    public String getFormattedDateTime() {
        if (startTime == null) return "";
        return startTime.format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"));
    }

    public String getFormattedDateOnly() {
        if (startTime == null) return "";
        return startTime.format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    }

    public String getFormattedTimeSlot() {
        if (startTime == null) return "";
        java.time.LocalDateTime end = startTime.plusHours(1);
        java.time.format.DateTimeFormatter hm = java.time.format.DateTimeFormatter.ofPattern("HH:mm");
        return startTime.format(hm) + " – " + end.format(hm);
    }
}
