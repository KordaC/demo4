package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.PersonalTrainingRepository;
import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.data.TrainerRepository;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.TrainerProfile;
import com.example.myapplication.your.model.UnifiedBooking;
import com.example.myapplication.your.model.User;
import com.example.myapplication.your.model.UserPersonalBooking;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.time.ZoneId;
import java.util.stream.Collectors;

public class MyBookingsViewModel extends AndroidViewModel {

    public static final class BookingsSplit {
        public final List<UnifiedBooking> upcoming;
        public final List<UnifiedBooking> history;

        public BookingsSplit(List<UnifiedBooking> upcoming, List<UnifiedBooking> history) {
            this.upcoming = upcoming != null ? upcoming : new ArrayList<>();
            this.history = history != null ? history : new ArrayList<>();
        }
    }

    private final PersonalTrainingRepository ptRepository;
    private final ScheduleRepository scheduleRepository;
    private final TrainerRepository trainerRepository;
    private final SharedPrefManager prefManager;
    private final MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private final MutableLiveData<BookingsSplit> bookingsSplit = new MutableLiveData<>(new BookingsSplit(new ArrayList<>(), new ArrayList<>()));
    private final MutableLiveData<String> error = new MutableLiveData<>();
    private final MutableLiveData<Boolean> cancelSuccess = new MutableLiveData<>();

    public MyBookingsViewModel(@NonNull Application application) {
        super(application);
        ptRepository = PersonalTrainingRepository.getInstance(application);
        scheduleRepository = ScheduleRepository.getInstance(application);
        trainerRepository = TrainerRepository.getInstance(application);
        prefManager = SharedPrefManager.getInstance(application);
    }

    public LiveData<Boolean> getLoading() { return loading; }
    public LiveData<BookingsSplit> getBookingsSplit() { return bookingsSplit; }
    public LiveData<String> getError() { return error; }
    public LiveData<Boolean> getCancelSuccess() { return cancelSuccess; }
    // Отмена персональной тренировки
    public void cancelPersonalBooking(String bookingId) {
        User user = prefManager.getCurrentUser();
        if (user == null || user.getId() == null) {
            error.postValue("Войдите в аккаунт");
            return;
        }
        if (bookingId == null || bookingId.trim().isEmpty()) {
            error.postValue("Запись не найдена");
            return;
        }

        loading.postValue(true);
        error.postValue(null);
        new Thread(() -> {
            try {
                String err = ptRepository.cancelPersonalBooking(bookingId);
                if (err == null) {
                    cancelSuccess.postValue(true);
                    loadBookings();
                } else {
                    error.postValue(err);
                }
            } catch (Exception e) {
                error.postValue("Ошибка отмены: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }
    // Отмена групповой тренировки
    public void cancelGroupBooking(String sessionId) {
        User user = prefManager.getCurrentUser();
        if (user == null || user.getId() == null) {
            error.postValue("Войдите в аккаунт");
            return;
        }
        if (sessionId == null || sessionId.trim().isEmpty()) {
            error.postValue("Занятие не найдено");
            return;
        }
        loading.postValue(true);
        error.postValue(null);
        new Thread(() -> {
            try {
                String err = scheduleRepository.cancelSession(user.getId(), sessionId);
                if (err == null) {
                    cancelSuccess.postValue(true);
                    loadBookings();
                } else {
                    error.postValue(err);
                }
            } catch (Exception e) {
                error.postValue("Ошибка отмены: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void clearCancelSuccess() {
        cancelSuccess.postValue(false);
    }
    // Загрузка всех записей пользователя
    public void loadBookings() {
        User user = prefManager.getCurrentUser();
        if (user == null || user.getId() == null) {
            bookingsSplit.postValue(new BookingsSplit(new ArrayList<>(), new ArrayList<>()));
            error.postValue("Войдите в аккаунт");
            return;
        }
        error.postValue(null);
        loading.postValue(true);
        new Thread(() -> {
            try {
                List<UserPersonalBooking> personal = ptRepository.getUserBookings(user.getId());
                List<Session> groupSessions = scheduleRepository.getUserSessions(user.getId());

                List<TrainerProfile> trainers = trainerRepository.getAllTrainers();
                Map<String, String> idToName = trainers.stream()
                        .filter(t -> t.getId() != null)
                        .collect(Collectors.toMap(TrainerProfile::getId, t -> t.getName() != null ? t.getName() : "Тренер", (a, b) -> a));
                for (UserPersonalBooking b : personal) {
                    if (b.getTrainerId() != null) {
                        b.setTrainerName(idToName.get(b.getTrainerId()));
                    }
                    if (b.getTrainerName() == null) b.setTrainerName("Тренер");
                }

                long nowMs = System.currentTimeMillis();
                ZoneId zone = ZoneId.systemDefault();

                List<UnifiedBooking> upcoming = new ArrayList<>();
                List<UnifiedBooking> history = new ArrayList<>();

                for (Session s : groupSessions) {
                    if (s.getStartTime() == null) continue;
                    long endMs;
                    if (s.getEndTime() != null) {
                        endMs = s.getEndTime().atZone(zone).toInstant().toEpochMilli();
                    } else {
                        endMs = s.getStartTime().atZone(zone).toInstant().toEpochMilli();
                    }
                    boolean past = endMs <= nowMs;
                    UnifiedBooking ub = UnifiedBooking.fromGroupSession(s, past);
                    if (past) {
                        history.add(ub);
                    } else {
                        upcoming.add(ub);
                    }
                }
                for (UserPersonalBooking b : personal) {
                    if ("cancelled".equalsIgnoreCase(b.getStatus())) continue;
                    String st = b.getStatus();
                    boolean past = "done".equalsIgnoreCase(st)
                            || "declined".equalsIgnoreCase(st)
                            || (b.getSortTimeMillis() > 0 && b.getSortTimeMillis() < nowMs);
                    UnifiedBooking ub = UnifiedBooking.fromPersonal(b, past);
                    if (past) {
                        history.add(ub);
                    } else {
                        upcoming.add(ub);
                    }
                }

                upcoming.sort(Comparator.comparingLong(UnifiedBooking::getSortTimeMillis));
                history.sort(Comparator.comparingLong(UnifiedBooking::getSortTimeMillis).reversed());

                bookingsSplit.postValue(new BookingsSplit(upcoming, history));
            } catch (Exception e) {
                error.postValue("Ошибка загрузки: " + e.getMessage());
                bookingsSplit.postValue(new BookingsSplit(new ArrayList<>(), new ArrayList<>()));
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void clearError() { error.postValue(null); }
}
