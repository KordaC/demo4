package com.example.myapplication.your.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.myapplication.your.data.SessionRepository;
import com.example.myapplication.your.model.Session;

import java.util.ArrayList;

public class SessionViewModel extends ViewModel {

    private MutableLiveData<ArrayList<Session>> sessions =
            new MutableLiveData<>();

    private SessionRepository repository =
            new SessionRepository();

    public LiveData<ArrayList<Session>> getSessions(){
        return sessions;
    }

    public void loadSessions(){

        repository.loadSessions(new SessionRepository.SessionCallback() {

            @Override
            public void onSuccess(ArrayList<Session> list) {

                sessions.setValue(list);

            }

            @Override
            public void onError(String error) {

            }

        });

    }

}