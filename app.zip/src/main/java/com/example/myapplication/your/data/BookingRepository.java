package com.example.myapplication.your.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BookingRepository {

    private static final String PREF = "trainer_bookings";
    private SharedPreferences prefs;

    public BookingRepository(Context context) {
        prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    // все слоты времени
    public List<String> getTimeSlots(){

        List<String> times = new ArrayList<>();

        times.add("09:00");
        times.add("10:00");
        times.add("11:00");
        times.add("12:00");
        times.add("13:00");
        times.add("14:00");
        times.add("15:00");
        times.add("16:00");
        times.add("17:00");
        times.add("18:00");

        return times;
    }

    // получить занятые слоты
    public List<String> getBusyTimes(String trainerId, String date){

        String key = trainerId + "_" + date;

        Set<String> set = prefs.getStringSet(key, new HashSet<>());

        return new ArrayList<>(set);
    }

    // добавить запись
    public void addBooking(String trainerId, String userId, String date, String time){

        String key = trainerId + "_" + date;

        Set<String> set = prefs.getStringSet(key, new HashSet<>());

        Set<String> newSet = new HashSet<>(set);

        newSet.add(time);

        prefs.edit().putStringSet(key, newSet).apply();
    }
}