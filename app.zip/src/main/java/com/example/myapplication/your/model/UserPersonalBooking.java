package com.example.myapplication.your.model;

public class UserPersonalBooking {
    private String id;
    private String trainerId;
    private String trainerName;
    private String dateTimeFormatted;
    private String status;
    private long sortTimeMillis;

    public UserPersonalBooking(String id, String trainerId, String dateTimeFormatted, String status, long sortTimeMillis) {
        this.id = id;
        this.trainerId = trainerId;
        this.dateTimeFormatted = dateTimeFormatted;
        this.status = status;
        this.sortTimeMillis = sortTimeMillis;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTrainerId() { return trainerId; }
    public void setTrainerId(String trainerId) { this.trainerId = trainerId; }

    public String getTrainerName() { return trainerName; }
    public void setTrainerName(String trainerName) { this.trainerName = trainerName; }

    public String getDateTimeFormatted() { return dateTimeFormatted; }
    public void setDateTimeFormatted(String dateTimeFormatted) { this.dateTimeFormatted = dateTimeFormatted; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public long getSortTimeMillis() { return sortTimeMillis; }
    public void setSortTimeMillis(long sortTimeMillis) { this.sortTimeMillis = sortTimeMillis; }


    public String getStatusDisplay() {
        if (status == null) return "";
        switch (status) {
            case "approved":
            case "requested":
                return "Запланировано";
            case "declined":
                return "Отменено";
            case "done":
                return "Проведено";
            case "cancelled":
                return "Отменено";
            default:
                return status;
        }
    }
}
