package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.data.TrainerProfileIdCache;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.User;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

public class CalendarViewModel extends AndroidViewModel {
    private ScheduleRepository repository;
    private SharedPrefManager prefManager;
    private LocalDate selectedDate;
    private Set<String> userSignedUpSessions = new HashSet<>();
    private MutableLiveData<Boolean> loading = new MutableLiveData<>();
    private MutableLiveData<List<Session>> sessionsForDate = new MutableLiveData<>();
    private MutableLiveData<List<Session>> allSessions = new MutableLiveData<>();
    private MutableLiveData<String> error = new MutableLiveData<>();
    private MutableLiveData<Boolean> signupSuccess = new MutableLiveData<>();
    private MutableLiveData<String> sessionStatusChanged = new MutableLiveData<>();

    public CalendarViewModel(@NonNull Application application) {
        super(application);
        repository = ScheduleRepository.getInstance(application);
        prefManager = SharedPrefManager.getInstance(application);
    }

    public LiveData<Boolean> getLoading() {
        return loading;
    }

    public LiveData<List<Session>> getSessionsForDate() {
        return sessionsForDate;
    }

    public LiveData<List<Session>> getAllSessions() {
        return allSessions;
    }

    public LiveData<String> getError() {
        return error;
    }

    public LiveData<Boolean> getSignupSuccess() {
        return signupSuccess;
    }
    
    public LiveData<String> getSessionStatusChanged() {
        return sessionStatusChanged;
    }

    public boolean isTrainerAccount() {
        User u = prefManager.getCurrentUser();
        return u != null && u.isTrainer();
    }

    public void loadAllSessions() {
        loading.postValue(true);
        new Thread(() -> {
            try {
                List<Session> cached = repository.getUpcomingSessionsFromCache();
                if (cached != null && !cached.isEmpty()) {
                    User cu = prefManager.getCurrentUser();
                    if (cu != null && cu.getId() != null) {
                        try {
                            mergeSignupStatusForSessions(cached, repository.getUserSignedUpSessionIds(cu.getId()));
                        } catch (Exception ignored) {
                        }
                    }
                    allSessions.postValue(cached);
                    if (selectedDate != null) {
                        sessionsForDate.postValue(filterSessionsByDate(cached, selectedDate));
                    }
                }
                TrainerProfileIdCache.refreshFromServer(getApplication());
                User currentUser = prefManager.getCurrentUser();
                List<Session> sessions;
                if (currentUser != null && currentUser.getId() != null) {
                    ExecutorService ex = Executors.newFixedThreadPool(2);
                    try {
                        Future<List<Session>> fSessions = ex.submit(() -> repository.getUpcomingSessions());
                        Future<Set<String>> fSigned = ex.submit(() -> repository.getUserSignedUpSessionIds(currentUser.getId()));
                        sessions = fSessions.get();
                        mergeSignupStatusForSessions(sessions, fSigned.get());
                    } finally {
                        ex.shutdown();
                    }
                } else {
                    sessions = repository.getUpcomingSessions();
                }
                allSessions.postValue(sessions);
                if (selectedDate != null) {
                    List<Session> filteredSessions = filterSessionsByDate(sessions, selectedDate);
                    sessionsForDate.postValue(filteredSessions);
                }
            } catch (Exception e) {
                error.postValue("Ошибка загрузки расписания: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }
    private void mergeSignupStatusForSessions(List<Session> sessions, Set<String> signedAllFromServer) {
        if (sessions == null || signedAllFromServer == null) return;
        Set<String> currentSessionIds = new HashSet<>();
        for (Session session : sessions) {
            if (session.getId() != null) currentSessionIds.add(session.getId());
        }
        userSignedUpSessions.removeIf(id -> !currentSessionIds.contains(id));
        for (String id : signedAllFromServer) {
            if (currentSessionIds.contains(id)) {
                userSignedUpSessions.add(id);
            }
        }
    }
    // Загрузка занятий на выбранную дату
    public void loadSessionsForDate(LocalDate date) {
        this.selectedDate = date;
        loadSessionsForDate(date, false);
    }

    public void loadSessionsForDate(LocalDate date, boolean forceReload) {
        this.selectedDate = date;
        loading.postValue(true);
        new Thread(() -> {
            try {
                TrainerProfileIdCache.refreshFromServer(getApplication());
                User currentUser = prefManager.getCurrentUser();
                List<Session> filteredSessions;
                if (currentUser != null && currentUser.getId() != null) {
                    ExecutorService ex = Executors.newFixedThreadPool(2);
                    try {
                        Future<List<Session>> fDay = ex.submit(() -> repository.getSessionsForDate(date));
                        Future<Set<String>> fSigned = ex.submit(() -> repository.getUserSignedUpSessionIds(currentUser.getId()));
                        filteredSessions = fDay.get();
                        Set<String> signed = fSigned.get();
                        for (Session s : filteredSessions) {
                            if (s.getId() != null && signed.contains(s.getId())) {
                                userSignedUpSessions.add(s.getId());
                            }
                        }
                    } finally {
                        ex.shutdown();
                    }
                } else {
                    filteredSessions = repository.getSessionsForDate(date);
                }
                sessionsForDate.postValue(filteredSessions);
            } catch (Exception e) {
                error.postValue("Ошибка загрузки расписания: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    private List<Session> filterSessionsByDate(List<Session> sessions, LocalDate date) {
        if (sessions == null || date == null) {
            return new ArrayList<>();
        }

        return sessions.stream()
                .filter(session -> {
                    if (session.getStartTime() == null) {
                        return false;
                    }
                    LocalDate sessionDate = session.getStartTime().toLocalDate();
                    return sessionDate.equals(date);
                })
                .sorted((s1, s2) -> {
                    if (s1.getStartTime() == null || s2.getStartTime() == null) {
                        return 0;
                    }
                    return s1.getStartTime().compareTo(s2.getStartTime());
                })
                .collect(Collectors.toList());
    }

    // Запись на занятие
    public void signUpForSession(String sessionId) {
        userSignedUpSessions.add(sessionId);
        optimisticallyUpdateSignupStatus(sessionId, true);
        signupSuccess.postValue(true);
        loading.postValue(true);
        new Thread(() -> {
            try {
                User currentUser = prefManager.getCurrentUser();
                if (currentUser == null || currentUser.getId() == null) {
                    userSignedUpSessions.remove(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, false);
                    error.postValue("Пользователь не авторизован");
                    return;
                }

                if (currentUser.isTrainer()) {
                    userSignedUpSessions.remove(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, false);
                    error.postValue("Тренерам запись на групповые занятия недоступна.");
                    return;
                }

                TrainerProfileIdCache.refreshFromServer(getApplication());
                Session target = repository.getSessionById(sessionId);
                if (target != null && TrainerProfileIdCache.isLedByCachedTrainer(target)) {
                    userSignedUpSessions.remove(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, false);
                    error.postValue("Это ваше занятие — запись на него как на клиента недоступна.");
                    return;
                }

                String err = repository.signUpForSession(currentUser.getId(), sessionId);
                if (err != null) {
                    userSignedUpSessions.remove(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, false);
                    error.postValue(err);
                } else if (selectedDate != null) {
                    loadAllSessions();
                }
            } catch (Exception e) {
                userSignedUpSessions.remove(sessionId);
                optimisticallyUpdateSignupStatus(sessionId, false);
                error.postValue("Ошибка записи: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }
    // Отмена записи
    public void cancelSession(String sessionId) {
        userSignedUpSessions.remove(sessionId);
        optimisticallyUpdateSignupStatus(sessionId, false);
        signupSuccess.postValue(true);
        loading.postValue(true);
        new Thread(() -> {
            try {
                User currentUser = prefManager.getCurrentUser();
                if (currentUser == null || currentUser.getId() == null) {
                    userSignedUpSessions.add(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, true);
                    error.postValue("Пользователь не авторизован");
                    return;
                }

                String err = repository.cancelSession(currentUser.getId(), sessionId);
                if (err != null) {
                    userSignedUpSessions.add(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, true);
                    error.postValue(err);
                } else if (selectedDate != null) {
                    loadAllSessions();
                }
            } catch (Exception e) {
                userSignedUpSessions.add(sessionId);
                optimisticallyUpdateSignupStatus(sessionId, true);
                error.postValue("Ошибка отмены: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public boolean isUserSignedUp(String sessionId) {
        return userSignedUpSessions.contains(sessionId);
    }

    public boolean isLedByCurrentTrainer(Session session) {
        return TrainerProfileIdCache.isLedByCachedTrainer(session);
    }

    public void optimisticallyUpdateSignupStatus(String sessionId, boolean signUp) {
        boolean changed = false;
        if (signUp) {
            changed = userSignedUpSessions.add(sessionId);
        } else {
            changed = userSignedUpSessions.remove(sessionId);
        }
        if (changed) {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                sessionStatusChanged.setValue(sessionId + "_" + System.currentTimeMillis());
            });
        }
    }

    public void clearError() {
        error.postValue(null);
    }

    public void clearSignupSuccess() {
        signupSuccess.postValue(false);
    }

}

