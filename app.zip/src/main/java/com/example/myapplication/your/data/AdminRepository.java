package com.example.myapplication.your.data;

import android.content.Context;
import android.util.Log;

import com.example.myapplication.your.model.AppUserAdminRow;
import com.example.myapplication.your.model.User;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;


public class AdminRepository {
    private static final String TAG = "AdminRepository";
    private static AdminRepository instance;

    private final Context appContext;
    private final String supabaseUrl;
    private final String supabaseKey;

    private AdminRepository(Context context) {
        appContext = context.getApplicationContext();
        supabaseUrl = SupabaseClientProvider.getSupabaseUrl();
        supabaseKey = SupabaseClientProvider.getSupabaseAnonKey();
    }

    public static synchronized AdminRepository getInstance(Context context) {
        if (instance == null) {
            instance = new AdminRepository(context);
        }
        return instance;
    }

    public List<AppUserAdminRow> listAppUsers() throws Exception {
        String token = SharedPrefManager.getInstance(appContext).getAccessToken();
        if (token == null || token.trim().isEmpty()) {
            throw new Exception("Нет сессии.");
        }
        String sel = "id,email,name,last_name,phone,role";
        String enc = URLEncoder.encode(sel, StandardCharsets.UTF_8.name());
        String url = supabaseUrl + "/rest/v1/app_user?select=" + enc + "&role=eq.trainer&order=email.asc";
        String json = makeGetRequestAsUser(url, token.trim());
        JSONArray arr = new JSONArray(json);
        List<AppUserAdminRow> out = new ArrayList<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject j = arr.getJSONObject(i);
            out.add(new AppUserAdminRow(
                    j.optString("id"),
                    j.optString("email"),
                    j.optString("name"),
                    j.optString("last_name"),
                    j.optString("phone"),
                    j.optString("role", User.ROLE_CLIENT)
            ));
        }
        return out;
    }

    public void patchUserRole(String userId, String newRole) throws Exception {
        if (userId == null || userId.trim().isEmpty()) throw new Exception("Нет id пользователя.");
        if (newRole == null || newRole.trim().isEmpty()) throw new Exception("Не указана роль.");
        String token = SharedPrefManager.getInstance(appContext).getAccessToken();
        if (token == null || token.trim().isEmpty()) {
            throw new Exception("Нет сессии.");
        }
        JSONObject body = new JSONObject();
        body.put("role", newRole.trim());
        String url = supabaseUrl + "/rest/v1/app_user?id=eq." + URLEncoder.encode(userId.trim(), StandardCharsets.UTF_8.name());
        makePatchRequestAsUser(url, body.toString(), token.trim());
    }

    private String makeGetRequestAsUser(String urlString, String accessToken) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        conn.setRequestProperty("Accept", "application/json");
        int code = conn.getResponseCode();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                code >= 400 ? conn.getErrorStream() : conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        if (code >= 400) {
            Log.w(TAG, "GET " + code + " " + sb);
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }

    private void makePatchRequestAsUser(String urlString, String jsonBody, String accessToken) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PATCH");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=minimal");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonBody.getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader er = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = er.readLine()) != null) sb.append(line);
            er.close();
            Log.w(TAG, "PATCH " + code + " " + sb);
            throw new Exception("HTTP " + code + ": " + sb);
        }
    }
}
