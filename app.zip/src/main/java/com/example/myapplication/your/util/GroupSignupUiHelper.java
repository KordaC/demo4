package com.example.myapplication.your.util;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CompoundButton;

import com.example.myapplication.R;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.model.User;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public final class GroupSignupUiHelper {
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private GroupSignupUiHelper() {}

    public static void showSignupWarningThen(Context context, Runnable onConfirm) {
        if (context == null || onConfirm == null) return;
        Context appCtx = context.getApplicationContext();
        User user = SharedPrefManager.getInstance(appCtx).getCurrentUser();
        if (user != null && user.getId() != null
                && SharedPrefManager.getInstance(appCtx).isGroupSignupCancelWarningSkipped(user.getId())) {
            MAIN.post(onConfirm);
            return;
        }

        MAIN.post(() -> {
            if (context instanceof Activity && (((Activity) context).isFinishing())) {
                return;
            }
            View content = LayoutInflater.from(context).inflate(R.layout.dialog_group_signup_warning_content, null);
            CompoundButton dontShowAgain = content.findViewById(R.id.checkbox_dont_show_again);

            new MaterialAlertDialogBuilder(context)
                    .setTitle(R.string.group_signup_cancel_rule_title)
                    .setView(content)
                    .setPositiveButton(R.string.group_signup_cancel_rule_confirm, (d, w) -> {
                        User cur = SharedPrefManager.getInstance(appCtx).getCurrentUser();
                        if (dontShowAgain != null && dontShowAgain.isChecked()
                                && cur != null && cur.getId() != null) {
                            SharedPrefManager.getInstance(appCtx).setGroupSignupCancelWarningSkipped(cur.getId(), true);
                        }
                        onConfirm.run();
                    })
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .show();
        });
    }
}
