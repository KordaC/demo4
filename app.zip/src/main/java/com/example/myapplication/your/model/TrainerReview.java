package com.example.myapplication.your.model;


public class TrainerReview {
    private String id;
    private String userId;
    private String userName;
    private int rating;
    private String comment;
    private String createdAtFormatted;

    public TrainerReview(int rating, String comment, String createdAtFormatted) {
        this.rating = rating;
        this.comment = comment != null ? comment : "";
        this.createdAtFormatted = createdAtFormatted != null ? createdAtFormatted : "";
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public String getCreatedAtFormatted() { return createdAtFormatted; }
    public void setCreatedAtFormatted(String createdAtFormatted) { this.createdAtFormatted = createdAtFormatted; }
}
