package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.your.model.MembershipPlan;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Currency;
import java.util.Locale;

public class MembershipTierDetailActivity extends AppCompatActivity {
    public static final String EXTRA_TIER_PLANS = "extra_tier_plans";
    public static final String EXTRA_TIER_KEY = "extra_tier_key";

    private TextView tvTierName;
    private TextView tvTierDesc;
    private TextView tvGroupInfo;
    private LinearLayout containerDurations;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership_tier_detail);

        tvTierName = findViewById(R.id.tv_tier_detail_name);
        tvTierDesc = findViewById(R.id.tv_tier_detail_desc);
        tvGroupInfo = findViewById(R.id.tv_tier_detail_group_info);
        containerDurations = findViewById(R.id.container_duration_buttons);

        @SuppressWarnings("unchecked")
        ArrayList<MembershipPlan> tierPlans =
                (ArrayList<MembershipPlan>) getIntent().getSerializableExtra(EXTRA_TIER_PLANS);

        String tierKey = getIntent().getStringExtra(EXTRA_TIER_KEY);
        if (tierPlans == null || tierPlans.isEmpty()) {
            Toast.makeText(this, "Не удалось загрузить варианты абонемента", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Collections.sort(tierPlans, Comparator.comparingInt(MembershipPlan::getDurationDays));
        MembershipPlan rep = tierPlans.get(0);

        String displayName = MembershipTierDetailAdapter.mapTierToDisplayName(tierKey != null ? tierKey : rep.getPlanTier());
        tvTierName.setText(displayName);

        String desc = rep.getDescription() != null ? rep.getDescription() : "";
        tvTierDesc.setText(desc);

        Integer groupVisitsPerMonth = rep.getGroupVisitsPerMonth();
        if (groupVisitsPerMonth != null) {
            tvGroupInfo.setVisibility(View.VISIBLE);
            tvGroupInfo.setText("Групповых в месяц: " + groupVisitsPerMonth);
        } else {
            tvGroupInfo.setVisibility(View.VISIBLE);
            tvGroupInfo.setText("Групповых занятий в этом тарифе нет");
        }

        createDurationButtons(tierPlans);
    }

    private void createDurationButtons(ArrayList<MembershipPlan> tierPlans) {
        containerDurations.removeAllViews();
        for (MembershipPlan plan : tierPlans) {
            if (plan == null) continue;
            String durationLabel = getDurationLabel(plan.getDurationDays());

            NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("ru", "RU"));
            format.setCurrency(Currency.getInstance("RUB"));

            BigDecimal price = plan.getPrice() != null ? plan.getPrice() : BigDecimal.ZERO;
            String buttonText = durationLabel + " — " + format.format(price);

            Button btn = new Button(this);
            btn.setText(buttonText);
            btn.setTextSize(16f);
            btn.setPadding(16, 16, 16, 16);
            btn.setOnClickListener(v -> {
                Intent i = new Intent(this, PaymentActivity.class);
                i.putExtra(PaymentActivity.EXTRA_PLAN_ID, plan.getId());
                startActivity(i);
            });

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            lp.topMargin = 12;
            btn.setLayoutParams(lp);
            containerDurations.addView(btn);
        }
    }

    private static String getDurationLabel(int durationDays) {
        if (durationDays >= 400 && durationDays <= 460) return "15 месяцев (спецпредложение)";
        if (durationDays <= 90) return "1 месяц";
        if (durationDays <= 270) return "6 месяцев";
        return "12 месяцев";
    }
    private static class MembershipTierDetailAdapter {
        static String mapTierToDisplayName(String tierKey) {
            if (tierKey == null) return "";
            String k = tierKey.trim().toLowerCase(Locale.ROOT);
            switch (k) {
                case "light":
                    return "Лайт";
                case "standard":
                    return "Стандарт";
                case "premium":
                    return "Премиум";
                default:
                    return tierKey;
            }
        }
    }
}

