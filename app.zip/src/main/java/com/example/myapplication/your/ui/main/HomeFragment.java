package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.model.MembershipPlan;
import com.example.myapplication.your.model.MembershipPurchase;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.UnifiedBooking;
import com.example.myapplication.your.viewmodel.HomeViewModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {

    public HomeFragment() {}

    private HomeViewModel viewModel;
    private TextView tvNearestTitle;
    private TextView tvNearestDetail;
    private TextView tvNearestStatus;
    private RecyclerView recyclerToday;
    private TextView tvTodayEmpty;
    private TextView tvTodayMore;

    private TextView tvMembershipStatus;
    private TextView tvMembershipDetails;
    private TextView tvMembershipGroupVisits;
    private TextView tvMembershipMore;
    private Button btnMembershipManage;

    private TodaySessionAdapter todayAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        Button btnGoSchedule = view.findViewById(R.id.btn_home_go_schedule);
        Button btnGoTrainers = view.findViewById(R.id.btn_home_go_trainers);
        Button btnGoMyClub = view.findViewById(R.id.btn_home_go_myclub);
        Button btnGoBookings = view.findViewById(R.id.btn_home_go_bookings);

        tvNearestTitle = view.findViewById(R.id.tv_nearest_title);
        tvNearestDetail = view.findViewById(R.id.tv_nearest_detail);
        tvNearestStatus = view.findViewById(R.id.tv_nearest_status);

        recyclerToday = view.findViewById(R.id.recycler_today_sessions);
        tvTodayEmpty = view.findViewById(R.id.tv_today_empty);
        tvTodayMore = view.findViewById(R.id.tv_today_more);

        tvMembershipStatus = view.findViewById(R.id.tv_membership_status);
        tvMembershipDetails = view.findViewById(R.id.tv_membership_details);
        tvMembershipGroupVisits = view.findViewById(R.id.tv_membership_group_visits);
        tvMembershipMore = view.findViewById(R.id.tv_membership_more);
        btnMembershipManage = view.findViewById(R.id.btn_membership_manage);

        recyclerToday.setLayoutManager(new LinearLayoutManager(requireContext()));
        todayAdapter = new TodaySessionAdapter();
        recyclerToday.setAdapter(todayAdapter);

        btnGoSchedule.setOnClickListener(v -> switchBottomTab(R.id.nav_schedule));
        btnGoTrainers.setOnClickListener(v -> switchBottomTab(R.id.nav_trainers));
        btnGoMyClub.setOnClickListener(v -> switchBottomTab(R.id.nav_myclub));
        btnMembershipManage.setOnClickListener(v -> switchBottomTab(R.id.nav_myclub));

        btnGoBookings.setOnClickListener(v -> {
            getParentFragmentManager()
                    .beginTransaction()
                    .replace(R.id.main_container, new MyBookingsFragment())
                    .addToBackStack("my_bookings")
                    .commit();
        });

        tvTodayMore.setOnClickListener(v -> switchBottomTab(R.id.nav_schedule));

        observeVm();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (viewModel != null) viewModel.loadDashboard();
    }

    private void observeVm() {
        viewModel.getNearestBooking().observe(getViewLifecycleOwner(), this::bindNearestBooking);
        viewModel.getTodaySessions().observe(getViewLifecycleOwner(), this::bindTodaySessions);
        viewModel.getActiveMembership().observe(getViewLifecycleOwner(), this::bindMembership);
        viewModel.getActiveMembershipExtraCount().observe(getViewLifecycleOwner(), n -> {
            if (n != null && n > 0 && tvMembershipMore != null) {
                tvMembershipMore.setVisibility(View.VISIBLE);
                tvMembershipMore.setText("Ещё активных абонементов: " + n + " (см. «Абонементы»)");
            } else if (tvMembershipMore != null) {
                tvMembershipMore.setVisibility(View.GONE);
            }
        });
    }

    private void bindNearestBooking(UnifiedBooking b) {
        if (b == null) {
            tvNearestTitle.setText("Нет ближайших записей");
            tvNearestDetail.setVisibility(View.GONE);
            tvNearestStatus.setVisibility(View.GONE);
            return;
        }
        tvNearestTitle.setText(b.getTitleLine() != null ? b.getTitleLine() : "Ближайшая запись");
        if (b.getDetailLine() != null && !b.getDetailLine().isEmpty()) {
            tvNearestDetail.setText(b.getDetailLine());
            tvNearestDetail.setVisibility(View.VISIBLE);
        } else {
            tvNearestDetail.setVisibility(View.GONE);
        }
        if (b.getStatusLine() != null && !b.getStatusLine().isEmpty()) {
            tvNearestStatus.setText(b.getStatusLine());
            tvNearestStatus.setVisibility(View.VISIBLE);
        } else {
            tvNearestStatus.setVisibility(View.GONE);
        }
    }

    private void bindTodaySessions(List<Session> sessions) {
        List<Session> list = sessions != null ? sessions : new ArrayList<>();
        todayAdapter.setItems(list);
        tvTodayEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
        recyclerToday.setVisibility(list.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void bindMembership(MembershipPurchase purchase) {
        if (purchase == null) {
            tvMembershipStatus.setText("Нет активного абонемента");
            tvMembershipDetails.setVisibility(View.GONE);
            tvMembershipGroupVisits.setVisibility(View.GONE);
            if (tvMembershipMore != null) tvMembershipMore.setVisibility(View.GONE);
            return;
        }

        boolean frozen = "frozen".equalsIgnoreCase(purchase.getStatus());
        long daysLeft = purchase.getDaysLeft();
        tvMembershipStatus.setText(frozen ? "Абонемент заморожен" : ("Дней осталось: " + daysLeft));

        DateTimeFormatter df = DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.getDefault());
        String details = "";
        if (purchase.getStartDate() != null && purchase.getEndDate() != null) {
            details = "С " + purchase.getStartDate().format(df) + " по " + purchase.getEndDate().format(df);
        } else if (purchase.getEndDate() != null) {
            details = "До " + purchase.getEndDate().format(df);
        }
        if (!details.isEmpty()) {
            tvMembershipDetails.setText(details);
            tvMembershipDetails.setVisibility(View.VISIBLE);
        } else {
            tvMembershipDetails.setVisibility(View.GONE);
        }

        MembershipPlan plan = purchase.getPlan();
        Integer monthly = plan != null ? plan.getGroupVisitsPerMonth() : null;
        Integer left = purchase.getGroupVisitsLeft();
        if (monthly != null && left != null) {
            tvMembershipGroupVisits.setText("Групповых в этом месяце: " + left + " из " + monthly);
            tvMembershipGroupVisits.setVisibility(View.VISIBLE);
        } else {
            tvMembershipGroupVisits.setVisibility(View.GONE);
        }
    }

    private void switchBottomTab(int menuId) {
        if (getActivity() == null) return;
        BottomNavigationView nav = getActivity().findViewById(R.id.bottom_nav);
        if (nav != null) {
            nav.setSelectedItemId(menuId);
        }
    }

    private class TodaySessionAdapter extends RecyclerView.Adapter<TodaySessionAdapter.Holder> {
        private List<Session> items = new ArrayList<>();

        void setItems(List<Session> list) {
            items = list != null ? list : new ArrayList<>();
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_home_today_session, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            holder.bind(items.get(position));
        }

        @Override
        public int getItemCount() {
            return items != null ? items.size() : 0;
        }

        class Holder extends RecyclerView.ViewHolder {
            final TextView tvTitle;
            final TextView tvSub;

            Holder(@NonNull View itemView) {
                super(itemView);
                tvTitle = itemView.findViewById(R.id.tv_home_today_title);
                tvSub = itemView.findViewById(R.id.tv_home_today_subtitle);
            }

            void bind(Session s) {
                tvTitle.setText(s.getTitle() != null ? s.getTitle() : "Занятие");
                String sub = s.getFormattedTimeRange();
                String extra = s.getSubtitleLine();
                if (extra != null && !extra.isEmpty()) {
                    sub = (sub != null && !sub.isEmpty()) ? (sub + " · " + extra) : extra;
                }
                tvSub.setText(sub != null ? sub : "");
                itemView.setOnClickListener(v -> {
                    Intent i = new Intent(requireContext(), SessionDetailActivity.class);
                    i.putExtra(SessionDetailActivity.EXTRA_SESSION, s);
                    startActivity(i);
                });
            }
        }
    }
}
