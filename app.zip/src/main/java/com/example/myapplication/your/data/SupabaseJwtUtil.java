package com.example.myapplication.your.data;

import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.util.Locale;

// Утилита для работы с JWT-токенами Supabase
public final class SupabaseJwtUtil {

    private SupabaseJwtUtil() {}

    public static String getSubject(String accessToken) {
        if (accessToken == null) return null;
        String t = accessToken.trim();
        if (t.isEmpty()) return null;
        String[] parts = t.split("\\.");
        if (parts.length < 2) return null;
        try {
            byte[] payload = base64UrlDecode(parts[1]);
            JSONObject o = new JSONObject(new String(payload, StandardCharsets.UTF_8));
            String sub = o.optString("sub", "");
            return sub.isEmpty() ? null : sub;
        } catch (Exception ignored) {
            return null;
        }
    }
    // Извлекает роль пользователя из JWT
    public static String getRoleClaim(String accessToken) {
        if (accessToken == null) return null;
        String t = accessToken.trim();
        if (t.isEmpty()) return null;
        String[] parts = t.split("\\.");
        if (parts.length < 2) return null;
        try {
            byte[] payload = base64UrlDecode(parts[1]);
            JSONObject o = new JSONObject(new String(payload, StandardCharsets.UTF_8));
            String r = null;
            JSONObject app = o.optJSONObject("app_metadata");
            if (app != null) {
                r = app.optString("role", "").trim();
            }
            if (r == null || r.isEmpty()) {
                JSONObject um = o.optJSONObject("user_metadata");
                if (um != null) {
                    r = um.optString("role", "").trim();
                }
            }
            if (r == null || r.isEmpty()) return null;
            r = r.toLowerCase(Locale.ROOT);
            if ("client".equals(r) || "trainer".equals(r) || "admin".equals(r)) {
                return r;
            }
        } catch (Exception ignored) {
            return null;
        }
        return null;
    }

    private static byte[] base64UrlDecode(String segment) {
        String p = segment;
        int rem = p.length() % 4;
        if (rem > 0) {
            p += "====".substring(0, 4 - rem);
        }
        return Base64.decode(p, Base64.URL_SAFE | Base64.NO_WRAP);
    }
}
