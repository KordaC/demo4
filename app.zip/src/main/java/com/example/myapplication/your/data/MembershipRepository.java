package com.example.myapplication.your.data;

import android.content.Context;
import android.util.Log;

import com.example.myapplication.your.model.MembershipPlan;
import com.example.myapplication.your.model.MembershipPurchase;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.User;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
// Репозиторий для управления абонементами и групповыми занятиями
public class MembershipRepository {
    private static final String TAG = "MembershipRepository";
    public static final String NEED_PAY_SINGLE_GROUP_SESSION = "NEED_PAY_SINGLE_GROUP_SESSION";
    private static MembershipRepository instance;
    private final Context appContext;
    private String supabaseUrl;
    private String supabaseKey;

    private MembershipRepository(Context context) {
        if (context == null) throw new IllegalArgumentException("context");
        this.appContext = context.getApplicationContext();
        supabaseUrl = SupabaseClientProvider.getSupabaseUrl();
        supabaseKey = SupabaseClientProvider.getSupabaseAnonKey();
    }
    private void setAuthHeaders(HttpURLConnection conn) {
        String token = SharedPrefManager.getInstance(appContext).getAccessToken();
        String bearer = (token != null && !token.trim().isEmpty()) ? token.trim() : supabaseKey;
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + bearer);
    }

    public static synchronized MembershipRepository getInstance(Context context) {
        if (instance == null) {
            instance = new MembershipRepository(context);
        }
        return instance;
    }

    // Получает все активные планы абонементов
    public List<MembershipPlan> getAllPlans() {
        try {
            String url = supabaseUrl + "/rest/v1/membership_plan?is_active=eq.true&select=*&order=price.asc";
            String jsonResponse = makeGetRequest(url);
            
            List<MembershipPlan> plans = new ArrayList<>();
            JSONArray jsonArray = new JSONArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                plans.add(mapToPlan(obj));
            }
            return plans;
        } catch (Exception e) {
            Log.e(TAG, "Error fetching plans", e);
            return new ArrayList<>();
        }
    }
    // Возвращает первый активный абонемент пользователя
    public MembershipPurchase getActiveMembership(String userId) {
        List<MembershipPurchase> list = getActiveMemberships(userId);
        return list.isEmpty() ? null : list.get(0);
    }
    // Получает все активные абонементы пользователя
    public List<MembershipPurchase> getActiveMemberships(String userId) {
        if (userId == null || userId.trim().isEmpty()) return new ArrayList<>();
        try {
            String today = java.time.LocalDate.now().toString();
            String sel;
            try {
                sel = URLEncoder.encode("*,membership_plan(*)", StandardCharsets.UTF_8.name());
            } catch (Exception e) {
                sel = "*";
            }
            String url = supabaseUrl
                    + "/rest/v1/membership_purchase"
                    + "?user_id=eq." + userId
                    + "&or=(status.eq.active,status.eq.frozen)"
                    + "&end_date=gte." + today
                    + "&order=end_date.desc"
                    + "&limit=50"
                    + "&select=" + sel;

            String jsonResponse;
            try {
                jsonResponse = makeGetRequest(url);
            } catch (Exception e) {
                Log.w(TAG, "getActiveMemberships embed failed, fallback", e);
                url = supabaseUrl
                        + "/rest/v1/membership_purchase"
                        + "?user_id=eq." + userId
                        + "&or=(status.eq.active,status.eq.frozen)"
                        + "&end_date=gte." + today
                        + "&order=end_date.desc"
                        + "&limit=50";
                jsonResponse = makeGetRequest(url);
            }

            UiDataCache.getInstance(appContext).putMembershipActiveJson(jsonResponse);
            return parseActiveMembershipsResponse(jsonResponse);
        } catch (Exception e) {
            Log.e(TAG, "getActiveMemberships", e);
            return new ArrayList<>();
        }
    }
    // Получает абонементы из кэша (без сети)
    public List<MembershipPurchase> getActiveMembershipsFromCache(String userId) {
        if (userId == null || userId.trim().isEmpty()) return null;
        try {
            String raw = UiDataCache.getInstance(appContext).getMembershipActiveJson();
            if (raw == null || raw.trim().isEmpty()) return null;
            return parseActiveMembershipsResponse(raw);
        } catch (Exception e) {
            Log.w(TAG, "getActiveMembershipsFromCache", e);
            return null;
        }
    }
    // Парсит ответ с активными абонементами
    private List<MembershipPurchase> parseActiveMembershipsResponse(String jsonResponse) throws Exception {
        List<MembershipPurchase> out = new ArrayList<>();
        JSONArray jsonArray = new JSONArray(jsonResponse);
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            MembershipPurchase purchase = mapToPurchase(obj);
            if (purchase.getPlan() == null) {
                String planId = obj.optString("plan_id");
                if (planId != null && !planId.isEmpty()) {
                    purchase.setPlan(getPlanById(planId));
                }
            }
            out.add(purchase);
        }
        return out;
    }
    private MembershipPurchase getActiveGroupMembership(String userId) {
        try {
            String today = java.time.LocalDate.now().toString();

            String url = supabaseUrl
                    + "/rest/v1/membership_purchase"
                    + "?user_id=eq." + userId
                    + "&or=(status.eq.active,status.eq.frozen)"
                    + "&end_date=gte." + today
                    + "&order=end_date.desc"
                    + "&limit=10";

            String jsonResponse = makeGetRequest(url);
            JSONArray jsonArray = new JSONArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                MembershipPurchase purchase = mapToPurchase(obj);

                String planId = obj.optString("plan_id");
                if (planId != null && !planId.isEmpty()) {
                    purchase.setPlan(getPlanById(planId));
                }

                MembershipPlan plan = purchase.getPlan();
                if (plan == null) continue;

                if (plan.isIncludesGroupPrograms() && plan.getGroupVisitsPerMonth() != null) {
                    return purchase;
                }
            }
            return null;
        } catch (Exception e) {
            Log.e(TAG, "getActiveGroupMembership", e);
            return null;
        }
    }

    // Получает план абонемента по ID
    public MembershipPlan getPlanById(String planId) {
        try {
            String url = supabaseUrl + "/rest/v1/membership_plan?id=eq." + planId;
            String jsonResponse = makeGetRequest(url);
            
            JSONArray jsonArray = new JSONArray(jsonResponse);
            if (jsonArray.length() == 0) return null;
            
            return mapToPlan(jsonArray.getJSONObject(0));
        } catch (Exception e) {
            Log.e(TAG, "Error fetching plan by id", e);
            return null;
        }
    }
    // Синхронизирует ID пользователя из SharedPreferences с JWT-токеном
    public User syncStoredUserIdWithJwt() {
        User u = SharedPrefManager.getInstance(appContext).getCurrentUser();
        String at = SharedPrefManager.getInstance(appContext).getAccessToken();
        if (u == null || at == null || at.trim().isEmpty()) return u;
        String sub = SupabaseJwtUtil.getSubject(at.trim());
        if (sub == null || sub.isEmpty() || u.getId() == null || sub.equalsIgnoreCase(u.getId().trim())) {
            return u;
        }
        Log.w(TAG, "syncStoredUserIdWithJwt: id в prefs не совпадает с JWT sub — исправляем для запросов к API");
        User fixed = new User();
        fixed.setId(sub);
        fixed.setEmail(u.getEmail());
        fixed.setName(u.getName());
        fixed.setPhone(u.getPhone());
        fixed.setAvatarUrl(u.getAvatarUrl());
        fixed.setRole(u.getRole());
        fixed.setSurname(u.getSurname());
        fixed.setPatronymic(u.getPatronymic());
        fixed.setBirthDate(u.getBirthDate());
        SharedPrefManager.getInstance(appContext).saveCurrentUser(fixed);
        return fixed;
    }
    // Гарантирует наличие записи пользователя в таблице app_user
    public boolean ensureAppUser(User user) {
        if (user == null || user.getEmail() == null || user.getEmail().trim().isEmpty()) return false;
        String at = SharedPrefManager.getInstance(appContext).getAccessToken();
        if (at == null || at.trim().isEmpty()) {
            Log.e(TAG, "ensureAppUser: нет access token — нужен вход или refresh сессии");
            return false;
        }
        String jwtSub = SupabaseJwtUtil.getSubject(at);
        User rowUser = user;
        if (jwtSub != null && !jwtSub.isEmpty()) {
            if (user.getId() == null || user.getId().trim().isEmpty()
                    || !jwtSub.equalsIgnoreCase(user.getId().trim())) {
                Log.w(TAG, "ensureAppUser: id сессии не совпадает с JWT sub — для RLS используем sub (auth.uid())");
                User fixed = new User();
                fixed.setId(jwtSub);
                fixed.setEmail(user.getEmail());
                fixed.setName(user.getName());
                fixed.setPhone(user.getPhone());
                fixed.setAvatarUrl(user.getAvatarUrl());
                fixed.setRole(user.getRole());
                fixed.setSurname(user.getSurname());
                fixed.setPatronymic(user.getPatronymic());
                fixed.setBirthDate(user.getBirthDate());
                SharedPrefManager.getInstance(appContext).saveCurrentUser(fixed);
                rowUser = fixed;
            }
        } else if (user.getId() == null || user.getId().trim().isEmpty()) {
            Log.e(TAG, "ensureAppUser: нет id и не удалось прочитать sub из JWT");
            return false;
        }
        try {
            JSONObject data = new JSONObject();
            data.put("id", rowUser.getId());
            data.put("email", rowUser.getEmail().trim());
            if (rowUser.getName() != null && !rowUser.getName().trim().isEmpty()) {
                data.put("name", rowUser.getName().trim());
            }
            if (rowUser.getPhone() != null && !rowUser.getPhone().trim().isEmpty()) {
                data.put("phone", rowUser.getPhone().trim());
            }
            if (rowUser.getSurname() != null && !rowUser.getSurname().trim().isEmpty()) {
                data.put("last_name", rowUser.getSurname().trim());
            }
            if (rowUser.getPatronymic() != null && !rowUser.getPatronymic().trim().isEmpty()) {
                data.put("patronymic", rowUser.getPatronymic().trim());
            }
            if (rowUser.getBirthDate() != null && !rowUser.getBirthDate().trim().isEmpty()) {
                data.put("birth_date", rowUser.getBirthDate().trim());
            }
            if (rowUser.getAvatarUrl() != null && rowUser.getAvatarUrl().startsWith("http")) {
                data.put("avatar_url", rowUser.getAvatarUrl());
            }

            String byIdJson = fetchAppUserJsonById(rowUser.getId());
            if (byIdJson != null && !byIdJson.trim().equals("[]")) {
                patchAppUserFromUser(rowUser);
                return verifyAppUserRowExists(rowUser.getId());
            }

            String otherId = findAppUserIdByEmail(rowUser.getEmail());
            if (otherId != null && !otherId.equalsIgnoreCase(rowUser.getId())) {
                if (invokeRpcEnsureAppUser(rowUser)) {
                    return verifyAppUserRowExists(rowUser.getId());
                }
                Log.e(TAG, "ensureAppUser: конфликт email; выполните SQL supabase_rpc_ensure_app_user_for_auth.sql в Supabase");
                return false;
            }

            String body = upsertAppUserWithRepresentation(data.toString());
            if (responseIndicatesRowPresent(body)) {
                return true;
            }
            if (verifyAppUserRowExists(rowUser.getId())) {
                return true;
            }
            Log.e(TAG, "ensureAppUser: no row after upsert for user " + rowUser.getId());
            return false;
        } catch (Exception e) {
            String msg = e.getMessage() != null ? e.getMessage() : "";
            if (msg.contains("23505") || msg.contains("409")) {
                if (invokeRpcEnsureAppUser(rowUser)) {
                    return verifyAppUserRowExists(rowUser.getId());
                }
            }
            Log.e(TAG, "ensureAppUser", e);
            return false;
        }
    }
    // Получает JSON записи app_user по ID
    private String fetchAppUserJsonById(String userId) throws Exception {
        if (userId == null || userId.trim().isEmpty()) return "[]";
        String url = supabaseUrl + "/rest/v1/app_user?id=eq." + userId.trim() + "&select=id&limit=1";
        return makeGetRequest(url);
    }
    // Ищет ID пользователя по email в таблице app_user
    private String findAppUserIdByEmail(String email) throws Exception {
        if (email == null || email.trim().isEmpty()) return null;
        String enc = URLEncoder.encode(email.trim(), StandardCharsets.UTF_8.name());
        String url = supabaseUrl + "/rest/v1/app_user?email=eq." + enc + "&select=id&limit=1";
        String json = makeGetRequest(url);
        JSONArray arr = new JSONArray(json);
        if (arr.length() == 0) return null;
        return arr.getJSONObject(0).optString("id", null);
    }
    // Проверяет существование записи в app_user
    private boolean verifyAppUserRowExists(String userId) {
        try {
            String j = fetchAppUserJsonById(userId);
            return j != null && !j.trim().equals("[]");
        } catch (Exception e) {
            Log.w(TAG, "verifyAppUserRowExists", e);
            return false;
        }
    }
    // Обновляет существующую запись app_user (PATCH)
    private void patchAppUserFromUser(User rowUser) throws Exception {
        JSONObject patch = new JSONObject();
        patch.put("email", rowUser.getEmail().trim());
        if (rowUser.getName() != null && !rowUser.getName().trim().isEmpty()) {
            patch.put("name", rowUser.getName().trim());
        }
        if (rowUser.getPhone() != null && !rowUser.getPhone().trim().isEmpty()) {
            patch.put("phone", rowUser.getPhone().trim());
        }
        if (rowUser.getSurname() != null && !rowUser.getSurname().trim().isEmpty()) {
            patch.put("last_name", rowUser.getSurname().trim());
        }
        if (rowUser.getPatronymic() != null && !rowUser.getPatronymic().trim().isEmpty()) {
            patch.put("patronymic", rowUser.getPatronymic().trim());
        }
        if (rowUser.getBirthDate() != null && !rowUser.getBirthDate().trim().isEmpty()) {
            patch.put("birth_date", rowUser.getBirthDate().trim());
        }
        if (rowUser.getAvatarUrl() != null && rowUser.getAvatarUrl().startsWith("http")) {
            patch.put("avatar_url", rowUser.getAvatarUrl());
        }
        String url = supabaseUrl + "/rest/v1/app_user?id=eq." + rowUser.getId();
        makePatchRequest(url, patch.toString());
    }


    private boolean invokeRpcEnsureAppUser(User rowUser) {
        try {
            JSONObject body = new JSONObject();
            body.put("p_email", rowUser.getEmail().trim());
            if (rowUser.getName() != null && !rowUser.getName().trim().isEmpty()) {
                body.put("p_name", rowUser.getName().trim());
            }
            if (rowUser.getPhone() != null && !rowUser.getPhone().trim().isEmpty()) {
                body.put("p_phone", rowUser.getPhone().trim());
            }
            if (rowUser.getAvatarUrl() != null && rowUser.getAvatarUrl().startsWith("http")) {
                body.put("p_avatar_url", rowUser.getAvatarUrl());
            }
            URL url = new URL(supabaseUrl + "/rest/v1/rpc/ensure_app_user_for_auth");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            setAuthHeaders(conn);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Prefer", "return=minimal");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = body.toString().getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }
            int code = conn.getResponseCode();
            if (code == 404) {
                Log.w(TAG, "RPC ensure_app_user_for_auth не найдена — выполните supabase_rpc_ensure_app_user_for_auth.sql");
                return false;
            }
            if (code >= 400) {
                BufferedReader err = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = err.readLine()) != null) sb.append(line);
                err.close();
                Log.e(TAG, "invokeRpcEnsureAppUser HTTP " + code + ": " + sb);
                return false;
            }
            return true;
        } catch (Exception e) {
            Log.e(TAG, "invokeRpcEnsureAppUser", e);
            return false;
        }
    }

    private static boolean responseIndicatesRowPresent(String body) {
        if (body == null) return false;
        String t = body.trim();
        if (t.isEmpty()) return false;
        try {
            if (t.startsWith("[")) {
                JSONArray arr = new JSONArray(t);
                return arr.length() > 0;
            }
            if (t.startsWith("{")) {
                JSONObject o = new JSONObject(t);
                return o.has("id") && !o.optString("id", "").isEmpty();
            }
        } catch (Exception ignored) {}
        return false;
    }
    private String upsertAppUserWithRepresentation(String jsonData) throws Exception {
        URL url = new URL(supabaseUrl + "/rest/v1/app_user");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        setAuthHeaders(conn);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "resolution=merge-duplicates,return=representation");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null && code < 400) stream = conn.getInputStream();
        BufferedReader reader = stream != null
                ? new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))
                : null;
        StringBuilder sb = new StringBuilder();
        if (reader != null) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close();
        }
        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        // 204 No Content или пустой ответ при успехе — проверка строкой ниже по GET
        return sb.toString();
    }
    // Загружает аватар пользователя в Supabase Storage
    public String uploadUserAvatarFile(File file, String userId) {
        if (file == null || !file.isFile() || userId == null || userId.trim().isEmpty()) {
            return null;
        }
        try {
            String uid = userId.trim();
            String objectPath = uid + "/avatar.jpg";
            String urlString = supabaseUrl + "/storage/v1/object/avatars/" + objectPath;
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            setAuthHeaders(conn);
            String contentType = URLConnection.guessContentTypeFromName(file.getName());
            if (contentType == null || !contentType.startsWith("image/")) {
                contentType = "image/jpeg";
            }
            conn.setRequestProperty("Content-Type", contentType);
            conn.setRequestProperty("x-upsert", "true");
            long len = file.length();
            if (len > 0) {
                conn.setFixedLengthStreamingMode(len);
            }

            try (FileInputStream fis = new FileInputStream(file);
                 OutputStream os = conn.getOutputStream()) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = fis.read(buf)) > 0) {
                    os.write(buf, 0, n);
                }
            }

            int code = conn.getResponseCode();
            if (code >= 400) {
                String errBody = "";
                if (conn.getErrorStream() != null) {
                    BufferedReader err = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = err.readLine()) != null) sb.append(line);
                    err.close();
                    errBody = sb.toString();
                }
                Log.e(TAG, "uploadUserAvatarFile HTTP " + code + ": " + errBody);
                return null;
            }
            long v = System.currentTimeMillis();
            return supabaseUrl + "/storage/v1/object/public/avatars/" + objectPath + "?v=" + v;
        } catch (Exception e) {
            Log.e(TAG, "uploadUserAvatarFile", e);
            return null;
        }
    }
    // Обновляет профиль пользователя в app_user
    public boolean updateAppUserProfile(User user) {
        if (user == null || user.getId() == null) return false;
        try {
            JSONObject data = new JSONObject();
            if (user.getName() != null) data.put("name", user.getName());
            if (user.getSurname() != null && !user.getSurname().trim().isEmpty()) {
                data.put("last_name", user.getSurname().trim());
            }
            if (user.getPatronymic() != null && !user.getPatronymic().trim().isEmpty()) {
                data.put("patronymic", user.getPatronymic().trim());
            }
            if (user.getBirthDate() != null && !user.getBirthDate().trim().isEmpty()) {
                data.put("birth_date", user.getBirthDate().trim());
            }
            if (user.getPhone() != null) data.put("phone", user.getPhone());
            if (user.getAvatarUrl() != null && user.getAvatarUrl().startsWith("http")) {
                data.put("avatar_url", user.getAvatarUrl());
            }
            String url = supabaseUrl + "/rest/v1/app_user?id=eq." + user.getId();
            makePatchRequest(url, data.toString());
            return true;
        } catch (Exception e) {
            Log.e(TAG, "updateAppUserProfile", e);
            return false;
        }
    }
    // Покупка абонемента
    public String purchaseMembership(String userId, String planId) {
        try {
            if (userId == null || userId.trim().isEmpty()) return "Пользователь не авторизован";
            if (planId == null || planId.trim().isEmpty()) return "Не выбран план абонемента";
            MembershipPlan plan = getPlanById(planId);
            if (plan == null) return "План абонемента не найден (возможно, отключен).";
            // Проверка: есть ли уже активный абонемент
            String blockMsg = validateNewMembershipPurchase(userId, plan);
            if (blockMsg != null) return blockMsg;

            LocalDate startDate = LocalDate.now();
            LocalDate endDate = startDate.plusDays(plan.getDurationDays());

            JSONObject data = new JSONObject();
            data.put("user_id", userId);
            data.put("plan_id", planId);
            data.put("start_date", startDate.format(DateTimeFormatter.ISO_DATE));
            data.put("end_date", endDate.format(DateTimeFormatter.ISO_DATE));
            data.put("visits_left", plan.getVisitLimit() != null ? plan.getVisitLimit() : 999999);
            data.put("status", "active");
            LocalDate monthStart = LocalDate.now().withDayOfMonth(1);
            if (plan.getGroupVisitsPerMonth() != null) {
                data.put("group_visits_left", plan.getGroupVisitsPerMonth());
                data.put("group_period_start", monthStart.format(DateTimeFormatter.ISO_DATE));
            }

            String url = supabaseUrl + "/rest/v1/membership_purchase";
            makePostRequest(url, data.toString());
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error purchasing membership", e);
            String raw = e.getMessage() != null ? e.getMessage() : "";
            if (raw.contains("membership_purchase_user_id_fkey") || raw.contains("membership_purchase_user_id")) {
                return "Профиль не найден в базе клуба. Выйдите из аккаунта и войдите снова, затем повторите покупку.";
            }
            String msg = raw.isEmpty() ? "Неизвестная ошибка" : raw;
            try {
                int idx = msg.indexOf('{');
                if (idx >= 0) {
                    JSONObject j = new JSONObject(msg.substring(idx));
                    if (j.has("message")) msg = j.optString("message", msg);
                    else if (j.has("msg")) msg = j.optString("msg", msg);
                    else if (j.has("details")) msg = j.optString("details", msg);
                    else if (j.has("hint")) msg = j.optString("hint", msg);
                }
            } catch (Exception ignored) {}
            if (msg.contains("membership_purchase_user_id_fkey") || msg.contains("violates foreign key constraint")) {
                return "Профиль не найден в базе клуба. Выйдите из аккаунта и войдите снова, затем повторите покупку.";
            }
            return "Не удалось купить абонемент: " + msg;
        }
    }

    // Заморозка абонемента
    public boolean freezeMembership(String purchaseId, int daysToAdd) {
        try {
            String getUrl = supabaseUrl + "/rest/v1/membership_purchase?id=eq." + purchaseId + "&select=freeze_days_used";
            String jsonResponse = makeGetRequest(getUrl);
            JSONArray arr = new JSONArray(jsonResponse);
            int currentUsed = 0;
            if (arr.length() > 0 && arr.getJSONObject(0).has("freeze_days_used")) {
                currentUsed = arr.getJSONObject(0).optInt("freeze_days_used", 0);
            }
            int newFreezeDaysUsed = currentUsed + daysToAdd;
            JSONObject data = new JSONObject();
            data.put("status", "frozen");
            data.put("freeze_days_used", newFreezeDaysUsed);

            String url = supabaseUrl + "/rest/v1/membership_purchase?id=eq." + purchaseId;
            makePatchRequest(url, data.toString());
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error freezing membership", e);
            return false;
        }
    }
    // Разморозка абонемента
    public boolean unfreezeMembership(String purchaseId) {
        try {
            JSONObject data = new JSONObject();
            data.put("status", "active");
            String url = supabaseUrl + "/rest/v1/membership_purchase?id=eq." + purchaseId;
            makePatchRequest(url, data.toString());
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error unfreezing membership", e);
            return false;
        }
    }
    public String validateGroupSignupEligibility(String userId, Session session) {
        try {
            if (userId == null || userId.trim().isEmpty()) return "Не указан пользователь.";
            if (session == null || session.getId() == null || session.getId().trim().isEmpty()) {
                return "Занятие не найдено.";
            }
            List<MembershipPurchase> active = getActiveMemberships(userId);
            if (active == null || active.isEmpty()) {
                return "Для записи на групповые занятия нужен действующий абонемент. Оформите его в разделе «Мой клуб».";
            }

            final String sid = session.getId().trim();
            final boolean paidSingle = hasPaidGroupSession(userId, sid);

            if (!session.requiresPaidGroupSticker()) {
                if (hasGymOnlyWithoutGroupCoverage(userId)) {
                    java.math.BigDecimal p = session.getPrice();
                    if (p == null || p.compareTo(java.math.BigDecimal.ZERO) <= 0) {
                        return null;
                    }
                    if (paidSingle) return null;
                    return NEED_PAY_SINGLE_GROUP_SESSION;
                }
                if (hasUnlimitedGroupAccess(userId)) {
                    return null;
                }
                MembershipPurchase gp = getActiveGroupMembership(userId);
                if (gp != null) {
                    MembershipPlan plan = gp.getPlan() != null ? gp.getPlan() : getPlanById(gp.getPlanId());
                    if (plan == null) return "Не удалось проверить абонемент.";
                    ensureGroupQuotaForCurrentMonth(gp, plan);
                    int left = gp.getGroupVisitsLeft() != null ? gp.getGroupVisitsLeft() : 0;
                    if (left <= 0) return NEED_PAY_SINGLE_GROUP_SESSION;
                    return null;
                }
                return "Ваш абонемент не включает групповые программы.";
            }

            if (paidSingle) return null;
            return NEED_PAY_SINGLE_GROUP_SESSION;
        } catch (Exception e) {
            Log.e(TAG, "validateGroupSignupEligibility", e);
            return "Ошибка: " + e.getMessage();
        }
    }
    private boolean hasUnlimitedGroupAccess(String userId) {
        List<MembershipPurchase> active = getActiveMemberships(userId);
        for (MembershipPurchase mp : active) {
            MembershipPlan pl = mp.getPlan();
            if (pl == null && mp.getPlanId() != null) pl = getPlanById(mp.getPlanId());
            if (pl == null) continue;
            if (!pl.isIncludesGroupPrograms()) continue;
            if (pl.getGroupVisitsPerMonth() == null) return true;
        }
        return false;
    }
    public void finalizeGroupSignupAfterInsert(String userId, Session session, boolean insertedNewRow, boolean usedPaidSingleMarker) {
        if (!insertedNewRow || session == null || userId == null || userId.trim().isEmpty()) return;
        if (usedPaidSingleMarker) return;
        if (hasGymOnlyWithoutGroupCoverage(userId)) return;
        if (hasUnlimitedGroupAccess(userId)) return;
        MembershipPurchase gp = getActiveGroupMembership(userId);
        if (gp == null) return;
        try {
            MembershipPlan plan = gp.getPlan() != null ? gp.getPlan() : getPlanById(gp.getPlanId());
            if (plan == null) return;
            ensureGroupQuotaForCurrentMonth(gp, plan);
            int left = gp.getGroupVisitsLeft() != null ? gp.getGroupVisitsLeft() : 0;
            if (left <= 0) return;
            int next = left - 1;
            JSONObject data = new JSONObject();
            data.put("group_visits_left", next);
            String url = supabaseUrl + "/rest/v1/membership_purchase?id=eq." + gp.getId();
            makePatchRequest(url, data.toString());
            gp.setGroupVisitsLeft(next);
        } catch (Exception e) {
            Log.e(TAG, "finalizeGroupSignupAfterInsert", e);
        }
    }
    public void clearPaidGroupSessionAfterSuccessfulSignup(String userId, String sessionId) {
        if (userId == null || sessionId == null) return;
        try {
            String url = supabaseUrl + "/rest/v1/paid_group_session?user_id=eq." + userId.trim()
                    + "&session_id=eq." + sessionId.trim();
            makeDeleteRequest(url);
        } catch (Exception e) {
            Log.w(TAG, "clearPaidGroupSessionAfterSuccessfulSignup", e);
        }
    }
    public void maybeRestorePaidGroupSessionAfterCancel(String userId, String sessionId, boolean sessionWasFree) {
        if (userId == null || sessionId == null) return;
        if (sessionWasFree) return;
        try {
            insertPaidGroupSession(userId, sessionId.trim());
        } catch (Exception e) {
            Log.w(TAG, "maybeRestorePaidGroupSessionAfterCancel", e);
        }
    }
    // Создает маркер разовой оплаты группового занятия
    public String insertPaidGroupSession(String userId, String sessionId) {
        try {
            if (userId == null || sessionId == null) return "Нет данных.";
            JSONObject data = new JSONObject();
            data.put("user_id", userId.trim());
            data.put("session_id", sessionId.trim());
            String url = supabaseUrl + "/rest/v1/paid_group_session";
            makePostRequest(url, data.toString());
            return null;
        } catch (Exception e) {
            Log.e(TAG, "insertPaidGroupSession", e);
            return e.getMessage() != null ? e.getMessage() : "Ошибка сохранения оплаты";
        }
    }

    public boolean hasPaidGroupSession(String userId, String sessionId) {
        try {
            if (userId == null || sessionId == null) return false;
            String url = supabaseUrl + "/rest/v1/paid_group_session?user_id=eq." + userId.trim()
                    + "&session_id=eq." + sessionId.trim() + "&select=user_id&limit=1";
            String json = makeGetRequest(url);
            JSONArray arr = new JSONArray(json);
            return arr.length() > 0;
        } catch (Exception e) {
            Log.w(TAG, "hasPaidGroupSession", e);
            return false;
        }
    }

    public String validateNewMembershipPurchase(String userId, MembershipPlan newPlan) {
        if (userId == null || newPlan == null) return null;
        List<MembershipPurchase> active = getActiveMemberships(userId);
        if (active.isEmpty()) return null;
        return "Пока действует текущий абонемент, новый оформить нельзя. Дождитесь окончания срока.";
    }

    public boolean hasGymOnlyWithoutGroupCoverage(String userId) {
        List<MembershipPurchase> active = getActiveMemberships(userId);
        if (active.isEmpty()) return false;
        boolean gym = false;
        boolean groupCov = false;
        for (MembershipPurchase mp : active) {
            MembershipPlan pl = mp.getPlan();
            if (pl == null && mp.getPlanId() != null) pl = getPlanById(mp.getPlanId());
            if (pl == null) continue;
            String k = normalizedPlanKind(pl);
            if ("gym_only".equals(k)) gym = true;
            if ("mixed".equals(k) || "group_only".equals(k)) groupCov = true;
        }
        return gym && !groupCov;
    }

    private static String normalizedPlanKind(MembershipPlan p) {
        if (p == null) return "mixed";
        String k = p.getPlanKind();
        if (k != null && !k.trim().isEmpty()) {
            String low = k.trim().toLowerCase(Locale.ROOT);
            if ("club".equals(low)) return "gym_only";
            return low;
        }
        if (!p.isIncludesGroupPrograms()) return "gym_only";
        return "mixed";
    }

    public void restoreGroupVisitAfterGroupCancel(String userId) {
        try {
            MembershipPurchase purchase = getActiveGroupMembership(userId);
            if (purchase == null) purchase = getActiveMembership(userId);
            if (purchase == null) return;
            MembershipPlan plan = purchase.getPlan();
            if (plan == null) {
                plan = getPlanById(purchase.getPlanId());
            }
            if (plan == null) return;
            Integer monthly = plan.getGroupVisitsPerMonth();
            if (monthly == null) return;
            ensureGroupQuotaForCurrentMonth(purchase, plan);
            int left = purchase.getGroupVisitsLeft() != null ? purchase.getGroupVisitsLeft() : 0;
            int capped = Math.min(monthly, left + 1);
            JSONObject data = new JSONObject();
            data.put("group_visits_left", capped);
            String url = supabaseUrl + "/rest/v1/membership_purchase?id=eq." + purchase.getId();
            makePatchRequest(url, data.toString());
            purchase.setGroupVisitsLeft(capped);
        } catch (Exception e) {
            Log.e(TAG, "restoreGroupVisitAfterGroupCancel", e);
        }
    }
    public String topUpGroupVisits(String userId, int count) {
        try {
            if (count <= 0) return "Некорректное количество.";
            MembershipPurchase purchase = getActiveGroupMembership(userId);
            if (purchase == null) {
                return "Нет активного абонемента. Оформите абонемент с групповыми программами.";
            }

            MembershipPlan plan = purchase.getPlan();
            if (plan == null) {
                plan = getPlanById(purchase.getPlanId());
                purchase.setPlan(plan);
            }
            if (plan == null) {
                return "Не удалось загрузить план абонемента.";
            }

            if (!plan.isIncludesGroupPrograms()) {
                return "Ваш абонемент не включает групповые занятия.";
            }

            Integer monthly = plan.getGroupVisitsPerMonth();
            if (monthly == null) {
                return "Абонемент не предусматривает лимит групповых посещений.";
            }

            ensureGroupQuotaForCurrentMonth(purchase, plan);

            int left = purchase.getGroupVisitsLeft() != null ? purchase.getGroupVisitsLeft() : 0;
            int next = left + count;

            LocalDate monthStart = LocalDate.now().withDayOfMonth(1);
            JSONObject data = new JSONObject();
            data.put("group_visits_left", next);
            data.put("group_period_start", monthStart.format(DateTimeFormatter.ISO_DATE));

            String url = supabaseUrl + "/rest/v1/membership_purchase?id=eq." + purchase.getId();
            makePatchRequest(url, data.toString());

            purchase.setGroupVisitsLeft(next);
            purchase.setGroupPeriodStart(monthStart);
            return null;
        } catch (Exception e) {
            Log.e(TAG, "topUpGroupVisits", e);
            return "Ошибка абонемента: " + e.getMessage();
        }
    }

    private void ensureGroupQuotaForCurrentMonth(MembershipPurchase purchase, MembershipPlan plan) throws Exception {
        Integer monthly = plan.getGroupVisitsPerMonth();
        if (monthly == null) return;
        LocalDate monthStart = LocalDate.now().withDayOfMonth(1);
        LocalDate period = purchase.getGroupPeriodStart();
        boolean needReset = period == null
                || period.getYear() != monthStart.getYear()
                || period.getMonth() != monthStart.getMonth();
        if (needReset) {
            JSONObject data = new JSONObject();
            data.put("group_visits_left", monthly);
            data.put("group_period_start", monthStart.format(DateTimeFormatter.ISO_DATE));
            String url = supabaseUrl + "/rest/v1/membership_purchase?id=eq." + purchase.getId();
            makePatchRequest(url, data.toString());
            purchase.setGroupVisitsLeft(monthly);
            purchase.setGroupPeriodStart(monthStart);
        }
    }
    // HTTP DELETE запрос
    private void makeDeleteRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("DELETE");
        setAuthHeaders(conn);
        conn.setRequestProperty("Content-Type", "application/json");
        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader err = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = err.readLine()) != null) sb.append(line);
            err.close();
            throw new Exception("HTTP " + code + ": " + sb);
        }
    }
    // HTTP GET запрос
    private String makeGetRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        setAuthHeaders(conn);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");

        int responseCode = conn.getResponseCode();
        if (responseCode >= 400) {
            BufferedReader errorReader = new BufferedReader(
                    new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder errorResponse = new StringBuilder();
            String line;
            while ((line = errorReader.readLine()) != null) errorResponse.append(line);
            errorReader.close();
            throw new Exception("HTTP " + responseCode + ": " + errorResponse.toString());
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        return response.toString();
    }
    // HTTP POST запрос
    private void makePostRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        setAuthHeaders(conn);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader err = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = err.readLine()) != null) sb.append(line);
            err.close();
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
    }
    // HTTP PATCH запрос
    private void makePatchRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PATCH");
        setAuthHeaders(conn);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader err = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = err.readLine()) != null) sb.append(line);
            err.close();
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
    }
    // Преобразует JSON в объект MembershipPlan
    private MembershipPlan mapToPlan(JSONObject json) {
        MembershipPlan plan = new MembershipPlan();
        plan.setId(json.optString("id"));
        plan.setName(json.optString("name"));
        plan.setDescription(json.optString("description"));
        
        if (!json.isNull("price")) {
            plan.setPrice(java.math.BigDecimal.valueOf(json.optDouble("price")));
        }
        
        plan.setDurationDays(json.optInt("duration_days", 0));
        
        if (!json.isNull("visit_limit")) {
            plan.setVisitLimit(json.optInt("visit_limit"));
        } else {
            plan.setVisitLimit(null);
        }
        
        plan.setFreezeDays(json.optInt("freeze_days", 0));
        plan.setIncludesGroupPrograms(json.optBoolean("includes_group_programs", false));
        plan.setActive(json.optBoolean("is_active", true));
        if (json.has("group_visits_per_month") && !json.isNull("group_visits_per_month")) {
            plan.setGroupVisitsPerMonth(json.optInt("group_visits_per_month"));
        } else {
            plan.setGroupVisitsPerMonth(null);
        }
        plan.setPlanTier(json.optString("plan_tier", null));
        String pk = json.optString("plan_kind", null);
        if (pk != null && pk.isEmpty()) pk = null;
        plan.setPlanKind(pk);
        
        return plan;
    }
    // Преобразует JSON в объект MembershipPurchase
    private MembershipPurchase mapToPurchase(JSONObject json) {
        MembershipPurchase purchase = new MembershipPurchase();
        purchase.setId(json.optString("id"));
        purchase.setUserId(json.optString("user_id"));
        purchase.setPlanId(json.optString("plan_id"));
        
        String startDateStr = json.optString("start_date");
        if (startDateStr != null && !startDateStr.isEmpty()) {
            purchase.setStartDate(LocalDate.parse(startDateStr));
        }
        
        String endDateStr = json.optString("end_date");
        if (endDateStr != null && !endDateStr.isEmpty()) {
            purchase.setEndDate(LocalDate.parse(endDateStr));
        }
        
        if (!json.isNull("visits_left")) {
            purchase.setVisitsLeft(json.optInt("visits_left"));
        } else {
            purchase.setVisitsLeft(null);
        }
        
        purchase.setFreezeDaysUsed(json.optInt("freeze_days_used", 0));
        purchase.setStatus(json.optString("status", "active"));
        purchase.setPurchasedAt(json.optString("purchased_at"));

        if (json.has("group_visits_left") && !json.isNull("group_visits_left")) {
            purchase.setGroupVisitsLeft(json.optInt("group_visits_left"));
        }
        String gps = json.optString("group_period_start", null);
        if (gps != null && !gps.isEmpty()) {
            try {
                purchase.setGroupPeriodStart(LocalDate.parse(gps));
            } catch (Exception ignored) {}
        }

        if (json.has("membership_plan") && !json.isNull("membership_plan")) {
            try {
                purchase.setPlan(mapToPlan(json.getJSONObject("membership_plan")));
            } catch (Exception e) {
                Log.d(TAG, "membership_plan embed", e);
            }
        }

        return purchase;
    }
}

