package com.example.myapplication.your.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import android.content.Intent;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.model.UnifiedBooking;
import com.example.myapplication.your.ui.trainer.TrainerCalendarActivity;
import com.example.myapplication.your.viewmodel.MyBookingsViewModel;

import java.util.ArrayList;
import java.util.List;

public class MyBookingsFragment extends Fragment {

    private MyBookingsViewModel viewModel;
    private RecyclerView recycler;
    private TextView tvEmpty;
    private TextView tvError;
    private ProgressBar progressBar;
    private BookingsListAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_bookings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(MyBookingsViewModel.class);

        progressBar = view.findViewById(R.id.progress_my_bookings);
        tvError = view.findViewById(R.id.tv_my_bookings_error);
        tvEmpty = view.findViewById(R.id.tv_my_bookings_empty);
        recycler = view.findViewById(R.id.recycler_my_bookings);

        view.findViewById(R.id.btn_my_bookings_back).setOnClickListener(v -> {
            if (getActivity() != null) getActivity().getOnBackPressedDispatcher().onBackPressed();
        });

        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new BookingsListAdapter();
        recycler.setAdapter(adapter);

        viewModel.getBookingsSplit().observe(getViewLifecycleOwner(), split -> {
            if (split == null) return;
            adapter.setData(split.upcoming, split.history);
            boolean empty = split.upcoming.isEmpty() && split.history.isEmpty();
            tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
            recycler.setVisibility(empty ? View.GONE : View.VISIBLE);
        });
        viewModel.getLoading().observe(getViewLifecycleOwner(), loading -> {
            progressBar.setVisibility(Boolean.TRUE.equals(loading) ? View.VISIBLE : View.GONE);
        });
        viewModel.getError().observe(getViewLifecycleOwner(), err -> {
            if (err != null) {
                tvError.setText(err);
                tvError.setVisibility(View.VISIBLE);
                Toast.makeText(requireContext(), err, Toast.LENGTH_SHORT).show();
                viewModel.clearError();
            } else {
                tvError.setVisibility(View.GONE);
            }
        });

        viewModel.getCancelSuccess().observe(getViewLifecycleOwner(), success -> {
            if (Boolean.TRUE.equals(success)) {
                Toast.makeText(requireContext(), "Запись отменена", Toast.LENGTH_SHORT).show();
                viewModel.clearCancelSuccess();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        if (viewModel != null) {
            viewModel.loadBookings();
        }
    }

    private static boolean canCancelGroup(long startMs) {
        long deadline = startMs - 2L * 60L * 60L * 1000L;
        return System.currentTimeMillis() < deadline;
    }

    private class BookingsListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private static final int TYPE_HEADER = 0;
        private static final int TYPE_BOOKING = 1;

        private final List<Object> rows = new ArrayList<>();

        void setData(List<UnifiedBooking> upcoming, List<UnifiedBooking> history) {
            rows.clear();
            if (upcoming != null && !upcoming.isEmpty()) {
                rows.add(MyBookingsFragment.this.getString(R.string.bookings_section_upcoming));
                rows.addAll(upcoming);
            }
            if (history != null && !history.isEmpty()) {
                rows.add(MyBookingsFragment.this.getString(R.string.bookings_section_history));
                rows.addAll(history);
            }
            notifyDataSetChanged();
        }

        @Override
        public int getItemViewType(int position) {
            Object o = rows.get(position);
            return o instanceof String ? TYPE_HEADER : TYPE_BOOKING;
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            if (viewType == TYPE_HEADER) {
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_booking_section_header, parent, false);
                return new HeaderHolder(v);
            }
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_booking, parent, false);
            return new BookingHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            Object o = rows.get(position);
            if (holder instanceof HeaderHolder) {
                ((HeaderHolder) holder).title.setText((String) o);
            } else if (holder instanceof BookingHolder) {
                UnifiedBooking b = (UnifiedBooking) o;
                BookingHolder h = (BookingHolder) holder;
                h.tvType.setText(b.getKindBadge());
                h.tvTrainer.setText(b.getTitleLine());
                h.tvDateTime.setText(b.getDetailLine());
                h.tvStatus.setText(b.getStatusLine());

                float alpha = b.isPast() ? 0.72f : 1f;
                h.itemView.setAlpha(alpha);

                h.btnCancel.setVisibility(View.GONE);
                h.btnCancel.setOnClickListener(null);
                if (h.tvReschedule != null) {
                    h.tvReschedule.setVisibility(View.GONE);
                    h.tvReschedule.setOnClickListener(null);
                }

                if (b.isPast()) {
                    return;
                }

                if (b.getKind() == UnifiedBooking.Kind.PERSONAL) {
                    String tid = b.getPersonalTrainerId();
                    if (h.tvReschedule != null && tid != null && !tid.isEmpty()) {
                        h.tvReschedule.setVisibility(View.VISIBLE);
                        h.tvReschedule.setOnClickListener(v -> {
                            Intent i = new Intent(v.getContext(), TrainerCalendarActivity.class);
                            i.putExtra(TrainerCalendarActivity.EXTRA_TRAINER_ID, tid);
                            i.putExtra(TrainerCalendarActivity.EXTRA_RESCHEDULE_BOOKING_ID, b.getId());
                            v.getContext().startActivity(i);
                        });
                    }
                    h.btnCancel.setVisibility(View.VISIBLE);
                    long nowMs = System.currentTimeMillis();
                    long limitMs = nowMs + 2L * 60L * 60L * 1000L;
                    boolean canCancel = b.getSortTimeMillis() > limitMs;
                    h.btnCancel.setEnabled(canCancel);
                    h.btnCancel.setText(canCancel ? MyBookingsFragment.this.getString(R.string.booking_cancel) : MyBookingsFragment.this.getString(R.string.booking_cancel_blocked));
                    h.btnCancel.setOnClickListener(v -> {
                        if (canCancel) {
                            viewModel.cancelPersonalBooking(b.getId());
                        }
                    });
                } else {
                    h.btnCancel.setVisibility(View.VISIBLE);
                    boolean canCancel = canCancelGroup(b.getSortTimeMillis());
                    h.btnCancel.setEnabled(canCancel);
                    h.btnCancel.setText(canCancel ? MyBookingsFragment.this.getString(R.string.booking_cancel) : MyBookingsFragment.this.getString(R.string.booking_cancel_blocked));
                    h.btnCancel.setOnClickListener(v -> {
                        if (canCancel) {
                            viewModel.cancelGroupBooking(b.getId());
                        }
                    });
                }
            }
        }

        @Override
        public int getItemCount() {
            return rows.size();
        }

        class HeaderHolder extends RecyclerView.ViewHolder {
            final TextView title;

            HeaderHolder(@NonNull View itemView) {
                super(itemView);
                title = itemView.findViewById(R.id.tv_section_title);
            }
        }

        class BookingHolder extends RecyclerView.ViewHolder {
            final TextView tvType;
            final TextView tvTrainer;
            final TextView tvDateTime;
            final TextView tvStatus;
            final TextView tvReschedule;
            final Button btnCancel;

            BookingHolder(@NonNull View itemView) {
                super(itemView);
                tvType = itemView.findViewById(R.id.tv_booking_type);
                tvTrainer = itemView.findViewById(R.id.tv_booking_trainer);
                tvDateTime = itemView.findViewById(R.id.tv_booking_datetime);
                tvStatus = itemView.findViewById(R.id.tv_booking_status);
                tvReschedule = itemView.findViewById(R.id.tv_booking_reschedule);
                btnCancel = itemView.findViewById(R.id.btn_booking_cancel);
            }
        }
    }
}
