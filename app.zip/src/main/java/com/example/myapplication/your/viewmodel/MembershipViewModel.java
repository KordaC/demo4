    package com.example.myapplication.your.viewmodel;

    import android.app.Application;

    import androidx.annotation.NonNull;
    import androidx.lifecycle.AndroidViewModel;
    import androidx.lifecycle.LiveData;
    import androidx.lifecycle.MutableLiveData;

    import com.example.myapplication.your.data.AuthRepository;
    import com.example.myapplication.your.data.MembershipRepository;
    import com.example.myapplication.your.data.SharedPrefManager;
    import com.example.myapplication.R;
    import com.example.myapplication.your.model.MembershipPlan;
    import com.example.myapplication.your.model.MembershipPurchase;
    import com.example.myapplication.your.model.User;

    import java.util.ArrayList;
    import java.util.List;
    import java.util.concurrent.atomic.AtomicInteger;

    public class MembershipViewModel extends AndroidViewModel {
        private MembershipRepository repository;
        private SharedPrefManager prefManager;

        private MutableLiveData<Boolean> loading = new MutableLiveData<>();
        private final AtomicInteger loadingDepth = new AtomicInteger(0);
        private MutableLiveData<MembershipPurchase> activeMembership = new MutableLiveData<>();
        private MutableLiveData<List<MembershipPurchase>> activeMemberships = new MutableLiveData<>();
        private MutableLiveData<List<MembershipPlan>> availablePlans = new MutableLiveData<>();
        private MutableLiveData<String> error = new MutableLiveData<>();
        private MutableLiveData<Boolean> purchaseSuccess = new MutableLiveData<>();
        private MutableLiveData<Boolean> topUpGroupSuccess = new MutableLiveData<>();
        private MutableLiveData<Boolean> singleGroupPaySuccess = new MutableLiveData<>();
        private MutableLiveData<Boolean> freezeSuccess = new MutableLiveData<>();
        private MutableLiveData<Boolean> unfreezeSuccess = new MutableLiveData<>();

        public MembershipViewModel(@NonNull Application application) {
            super(application);
            repository = MembershipRepository.getInstance(application);
            prefManager = SharedPrefManager.getInstance(application);
        }

        public LiveData<Boolean> getLoading() { return loading; }
        public LiveData<MembershipPurchase> getActiveMembership() { return activeMembership; }
        public LiveData<List<MembershipPurchase>> getActiveMemberships() { return activeMemberships; }
        public LiveData<List<MembershipPlan>> getAvailablePlans() { return availablePlans; }
        public LiveData<String> getError() { return error; }
        public LiveData<Boolean> getPurchaseSuccess() { return purchaseSuccess; }
        public LiveData<Boolean> getTopUpGroupSuccess() { return topUpGroupSuccess; }
        public LiveData<Boolean> getSingleGroupPaySuccess() { return singleGroupPaySuccess; }
        public LiveData<Boolean> getFreezeSuccess() { return freezeSuccess; }
        public LiveData<Boolean> getUnfreezeSuccess() { return unfreezeSuccess; }

        private void beginLoading() {
            if (loadingDepth.getAndIncrement() == 0) {
                loading.postValue(true);
            }
        }

        private void endLoading() {
            int d = loadingDepth.decrementAndGet();
            if (d <= 0) {
                loadingDepth.set(0);
                loading.postValue(false);
            }
        }
        // Загрузка активных абонементов
        public void loadActiveMembership() {
            beginLoading();
            new Thread(() -> {
                try {
                    User u0 = prefManager.getCurrentUser();
                    if (u0 != null && u0.getId() != null) {
                        List<MembershipPurchase> cached = repository.getActiveMembershipsFromCache(u0.getId());
                        if (cached != null && !cached.isEmpty()) {
                            activeMemberships.postValue(cached);
                            activeMembership.postValue(cached.get(0));
                        }
                    }
                    AuthRepository.getInstance(getApplication()).tryRefreshAccessToken();
                    User currentUser = repository.syncStoredUserIdWithJwt();
                    if (currentUser != null && currentUser.getId() != null) {
                        List<MembershipPurchase> list = repository.getActiveMemberships(currentUser.getId());
                        activeMemberships.postValue(list);
                        activeMembership.postValue(list.isEmpty() ? null : list.get(0));
                    } else {
                        activeMemberships.postValue(new ArrayList<>());
                        activeMembership.postValue(null);
                    }
                } catch (Exception e) {
                    activeMemberships.postValue(new ArrayList<>());
                    activeMembership.postValue(null);
                    error.postValue("Ошибка загрузки абонемента: " + e.getMessage());
                } finally {
                    endLoading();
                }
            }).start();
        }
        private boolean ensureSessionAndAppUserForPayment() {
            AuthRepository auth = AuthRepository.getInstance(getApplication());
            auth.tryRefreshAccessToken();
            String at = prefManager.getAccessToken();
            if (at == null || at.trim().isEmpty()) {
                auth.tryRefreshAccessToken();
            }
            User u = prefManager.getCurrentUser();
            if (u == null || u.getId() == null) {
                return false;
            }
            if (repository.ensureAppUser(u)) {
                return true;
            }
            auth.tryRefreshAccessToken();
            u = prefManager.getCurrentUser();
            return u != null && repository.ensureAppUser(u);
        }

        public void loadAvailablePlans() {
            beginLoading();
            new Thread(() -> {
                try {
                    List<MembershipPlan> plans = repository.getAllPlans();
                    availablePlans.postValue(plans);
                } catch (Exception e) {
                    error.postValue("Ошибка загрузки планов: " + e.getMessage());
                } finally {
                    endLoading();
                }
            }).start();
        }

        public void loadMembershipScreen() {
            beginLoading();
            new Thread(() -> {
                try {
                    AuthRepository.getInstance(getApplication()).tryRefreshAccessToken();
                    User currentUser = repository.syncStoredUserIdWithJwt();

                    List<MembershipPlan> plans = repository.getAllPlans();
                    availablePlans.postValue(plans);
                    if (currentUser != null && currentUser.getId() != null) {
                        List<MembershipPurchase> list = repository.getActiveMemberships(currentUser.getId());
                        activeMemberships.postValue(list);
                        activeMembership.postValue(list.isEmpty() ? null : list.get(0));
                    } else {
                        activeMemberships.postValue(new ArrayList<>());
                        activeMembership.postValue(null);
                    }
                } catch (Exception e) {
                    error.postValue("Ошибка загрузки: " + e.getMessage());
                } finally {
                    endLoading();
                }
            }).start();
        }
        // Покупка абонемента
        public void purchaseMembership(String planId) {
            loading.postValue(true);
            new Thread(() -> {
                try {
                    User currentUser = prefManager.getCurrentUser();
                    if (currentUser == null || currentUser.getId() == null) {
                        error.postValue("Пользователь не авторизован");
                        return;
                    }
                    if (planId == null || planId.trim().isEmpty()) {
                        error.postValue("Не выбран план абонемента");
                        return;
                    }
                    if (!ensureSessionAndAppUserForPayment()) {
                        error.postValue(getApplication().getString(R.string.payment_error_prepare));
                        return;
                    }
                    currentUser = prefManager.getCurrentUser();
                    String err = repository.purchaseMembership(currentUser.getId(), planId);
                    if (err == null) {
                        purchaseSuccess.postValue(true);
                        loadActiveMembership();
                    } else {
                        error.postValue(err);
                    }
                } catch (Exception e) {
                    error.postValue("Ошибка покупки: " + e.getMessage());
                } finally {
                    loading.postValue(false);
                }
            }).start();
        }

        public void freezeMembership(String purchaseId, int days) {
            loading.postValue(true);
            new Thread(() -> {
                try {
                    boolean success = repository.freezeMembership(purchaseId, days);
                    if (success) {
                        freezeSuccess.postValue(true);
                        loadActiveMembership();
                    } else {
                        error.postValue("Не удалось заморозить абонемент");
                    }
                } catch (Exception e) {
                    error.postValue("Ошибка заморозки: " + e.getMessage());
                } finally {
                    loading.postValue(false);
                }
            }).start();
        }

        public void unfreezeMembership(String purchaseId) {
            loading.postValue(true);
            new Thread(() -> {
                try {
                    boolean success = repository.unfreezeMembership(purchaseId);
                    if (success) {
                        unfreezeSuccess.postValue(true);
                        loadActiveMembership();
                    } else {
                        error.postValue("Не удалось разморозить абонемент");
                    }
                } catch (Exception e) {
                    error.postValue("Ошибка разморозки: " + e.getMessage());
                } finally {
                    loading.postValue(false);
                }
            }).start();
        }
        public void payForSingleGroupSession(String sessionId) {
            loading.postValue(true);
            new Thread(() -> {
                try {
                    User currentUser = prefManager.getCurrentUser();
                    if (currentUser == null || currentUser.getId() == null) {
                        error.postValue("Пользователь не авторизован");
                        return;
                    }
                    if (sessionId == null || sessionId.trim().isEmpty()) {
                        error.postValue("Не указано занятие");
                        return;
                    }
                    if (!ensureSessionAndAppUserForPayment()) {
                        error.postValue(getApplication().getString(R.string.payment_error_prepare));
                        return;
                    }
                    currentUser = prefManager.getCurrentUser();
                    String err = repository.insertPaidGroupSession(currentUser.getId(), sessionId.trim());
                    if (err == null) {
                        singleGroupPaySuccess.postValue(true);
                    } else {
                        error.postValue(err);
                    }
                } catch (Exception e) {
                    error.postValue("Ошибка оплаты: " + e.getMessage());
                } finally {
                    loading.postValue(false);
                }
            }).start();
        }

        public void topUpGroupVisits(int count) {
            loading.postValue(true);
            new Thread(() -> {
                try {
                    User currentUser = prefManager.getCurrentUser();
                    if (currentUser == null || currentUser.getId() == null) {
                        error.postValue("Пользователь не авторизован");
                        return;
                    }
                    if (!ensureSessionAndAppUserForPayment()) {
                        error.postValue(getApplication().getString(R.string.payment_error_prepare));
                        return;
                    }
                    currentUser = prefManager.getCurrentUser();
                    String err = repository.topUpGroupVisits(currentUser.getId(), count);
                    if (err == null) {
                        topUpGroupSuccess.postValue(true);
                        loadActiveMembership();
                    } else {
                        error.postValue(err);
                    }
                } catch (Exception e) {
                    error.postValue("Ошибка пополнения: " + e.getMessage());
                } finally {
                    loading.postValue(false);
                }
            }).start();
        }

        public void clearError() {
            error.setValue(null);
        }

        public void clearPurchaseSuccess() {
            purchaseSuccess.setValue(false);
        }

        public void clearTopUpGroupSuccess() {
            topUpGroupSuccess.setValue(false);
        }

        public void clearSingleGroupPaySuccess() {
            singleGroupPaySuccess.setValue(false);
        }

        public void clearFreezeSuccess() {
            freezeSuccess.setValue(false);
        }

        public void clearUnfreezeSuccess() {
            unfreezeSuccess.setValue(false);
        }
    }

