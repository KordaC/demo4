package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.data.FavoritesRepository;
import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.data.TrainerRepository;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.TrainerProfile;

import java.util.ArrayList;
import java.util.List;

//Список избранных тренеров и групповых занятий

public class FavoritesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        ProgressBar progress = findViewById(R.id.progress_favorites);
        RecyclerView rvTrainers = findViewById(R.id.recycler_fav_trainers);
        RecyclerView rvSessions = findViewById(R.id.recycler_fav_sessions);
        TextView tvEmpty = findViewById(R.id.tv_favorites_empty);

        findViewById(R.id.btn_favorites_back).setOnClickListener(v -> onBackPressed());

        rvTrainers.setLayoutManager(new LinearLayoutManager(this));
        rvSessions.setLayoutManager(new LinearLayoutManager(this));

        progress.setVisibility(View.VISIBLE);
        new Thread(() -> {
            try {
                FavoritesRepository fr = FavoritesRepository.getInstance(this);
                fr.syncFromServerIfLoggedIn(true);
                List<String> favTrainerIds = fr.getFavoriteTrainerIds();
                List<String> favSessionIds = fr.getFavoriteSessionIds();

                List<TrainerProfile> favT = TrainerRepository.getInstance(this).getTrainersByIds(favTrainerIds);

                List<Session> favS = new ArrayList<>();
                if (!favSessionIds.isEmpty()) {
                    favS.addAll(ScheduleRepository.getInstance(this).getSessionsByIds(favSessionIds));
                }

                List<TrainerProfile> finalTrainers = favT;
                List<Session> finalSessions = favS;
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    boolean empty = finalTrainers.isEmpty() && finalSessions.isEmpty();
                    tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);

                    rvTrainers.setAdapter(new TrainerAdapter(finalTrainers));
                    rvSessions.setAdapter(new SessionAdapter(finalSessions));
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    tvEmpty.setVisibility(View.VISIBLE);
                    tvEmpty.setText(getString(R.string.favorites_empty) + "\n" + e.getMessage());
                });
            }
        }).start();
    }

    private static class TrainerAdapter extends RecyclerView.Adapter<TrainerAdapter.H> {
        private final List<TrainerProfile> list;

        TrainerAdapter(List<TrainerProfile> list) {
            this.list = list != null ? list : new ArrayList<>();
        }

        @NonNull
        @Override
        public H onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            TextView tv = new TextView(parent.getContext());
            tv.setPadding(32, 24, 32, 24);
            tv.setBackgroundResource(R.drawable.bg_card_inner_soft);
            return new H(tv);
        }

        @Override
        public void onBindViewHolder(@NonNull H holder, int position) {
            TrainerProfile t = list.get(position);
            String name = t.getName() != null ? t.getName() : "Тренер";
            ((TextView) holder.itemView).setText(name);
            holder.itemView.setOnClickListener(v -> {
                Intent i = new Intent(v.getContext(), TrainerDetailActivity.class);
                i.putExtra(TrainerDetailActivity.EXTRA_TRAINER_ID, t.getId());
                v.getContext().startActivity(i);
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        static class H extends RecyclerView.ViewHolder {
            H(@NonNull View itemView) {
                super(itemView);
            }
        }
    }

    private static class SessionAdapter extends RecyclerView.Adapter<SessionAdapter.H> {
        private final List<Session> list;

        SessionAdapter(List<Session> list) {
            this.list = list != null ? list : new ArrayList<>();
        }

        @NonNull
        @Override
        public H onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_favorite_session, parent, false);
            return new H(v);
        }

        @Override
        public void onBindViewHolder(@NonNull H holder, int position) {
            Session s = list.get(position);
            holder.title.setText(s.getTitle() != null ? s.getTitle() : "Занятие");
            holder.time.setText(s.getFormattedDateTimeLine());
            String cover = s.getImageUrl();
            if (cover != null && cover.trim().startsWith("http")) {
                holder.ivCover.setVisibility(View.VISIBLE);
                Glide.with(holder.ivCover.getContext()).load(cover.trim()).into(holder.ivCover);
            } else {
                holder.ivCover.setVisibility(View.GONE);
            }
            holder.itemView.setOnClickListener(v -> {
                Intent i = new Intent(v.getContext(), SessionDetailActivity.class);
                i.putExtra(SessionDetailActivity.EXTRA_SESSION, s);
                v.getContext().startActivity(i);
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        static class H extends RecyclerView.ViewHolder {
            final ImageView ivCover;
            final TextView title;
            final TextView time;

            H(@NonNull View itemView) {
                super(itemView);
                ivCover = itemView.findViewById(R.id.iv_fav_session_cover);
                title = itemView.findViewById(R.id.tv_fav_session_title);
                time = itemView.findViewById(R.id.tv_fav_session_time);
            }
        }
    }
}
