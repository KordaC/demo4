package com.example.myapplication.your.model;

import java.time.ZoneId;

public class UnifiedBooking {
    public enum Kind { GROUP, PERSONAL }

    private final Kind kind;
    private final String id;
    private final String titleLine;
    private final String detailLine;
    private final String statusLine;
    private final long sortTimeMillis;
    private final boolean past;
    private final String personalTrainerId;

    public UnifiedBooking(Kind kind, String id, String titleLine, String detailLine, String statusLine, long sortTimeMillis) {
        this(kind, id, titleLine, detailLine, statusLine, sortTimeMillis, false, null);
    }

    public UnifiedBooking(Kind kind, String id, String titleLine, String detailLine, String statusLine, long sortTimeMillis, boolean past) {
        this(kind, id, titleLine, detailLine, statusLine, sortTimeMillis, past, null);
    }

    public UnifiedBooking(Kind kind, String id, String titleLine, String detailLine, String statusLine, long sortTimeMillis, boolean past, String personalTrainerId) {
        this.kind = kind;
        this.id = id;
        this.titleLine = titleLine;
        this.detailLine = detailLine;
        this.statusLine = statusLine;
        this.sortTimeMillis = sortTimeMillis;
        this.past = past;
        this.personalTrainerId = (kind == Kind.PERSONAL && personalTrainerId != null && !personalTrainerId.trim().isEmpty())
                ? personalTrainerId.trim() : null;
    }

    public Kind getKind() { return kind; }
    public String getId() { return id; }
    public String getTitleLine() { return titleLine; }
    public String getDetailLine() { return detailLine; }
    public String getStatusLine() { return statusLine; }
    public long getSortTimeMillis() { return sortTimeMillis; }
    public boolean isPast() { return past; }

    public String getPersonalTrainerId() { return personalTrainerId; }

    public String getKindBadge() {
        return kind == Kind.GROUP ? "Групповое" : "Персональное";
    }

    public static UnifiedBooking fromGroupSession(Session s) {
        return fromGroupSession(s, false);
    }

    public static UnifiedBooking fromGroupSession(Session s, boolean past) {
        long t = 0L;
        if (s.getStartTime() != null) {
            t = s.getStartTime().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        }
        String detail = s.getFormattedStartTime() != null ? s.getFormattedStartTime() : "";
        if (s.getTrainerName() != null && !s.getTrainerName().isEmpty()) {
            detail += (detail.isEmpty() ? "" : " · ") + s.getTrainerName();
        }
        if (s.getDirectionName() != null && !s.getDirectionName().isEmpty()) {
            detail += (detail.isEmpty() ? "" : " · ") + s.getDirectionName();
        }
        String status = past ? "Завершено" : "Запись на групповое занятие";
        return new UnifiedBooking(Kind.GROUP, s.getId(), s.getTitle(), detail, status, t, past, null);
    }

    public static UnifiedBooking fromPersonal(UserPersonalBooking b) {
        return fromPersonal(b, false);
    }

    public static UnifiedBooking fromPersonal(UserPersonalBooking b, boolean past) {
        String status;
        if (past) {
            String raw = b.getStatus();
            if ("done".equalsIgnoreCase(raw)) {
                status = "Проведено";
            } else if ("declined".equalsIgnoreCase(raw)) {
                status = "Отменено";
            } else {
                status = "Завершено";
            }
        } else {
            status = b.getStatusDisplay();
        }
        return new UnifiedBooking(Kind.PERSONAL, b.getId(),
                b.getTrainerName() != null ? b.getTrainerName() : "Персональная тренировка",
                b.getDateTimeFormatted() != null ? b.getDateTimeFormatted() : "",
                status, b.getSortTimeMillis(), past, b.getTrainerId());
    }
}
