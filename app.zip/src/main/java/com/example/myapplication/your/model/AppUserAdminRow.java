package com.example.myapplication.your.model;

import java.io.Serializable;

public class AppUserAdminRow implements Serializable {
    private final String id;
    private final String email;
    private final String name;
    private final String lastName;
    private final String phone;
    private final String role;

    public AppUserAdminRow(String id, String email, String name, String lastName, String phone, String role) {
        this.id = id;
        this.email = email;
        this.name = name;
        this.lastName = lastName;
        this.phone = phone;
        this.role = role;
    }

    public String getId() { return id; }
    public String getEmail() { return email; }
    public String getName() { return name; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getRole() { return role; }

    public String getDisplayName() {
        String n = name != null ? name.trim() : "";
        String ln = lastName != null ? lastName.trim() : "";
        if (!ln.isEmpty() && !n.isEmpty()) return ln + " " + n;
        if (!ln.isEmpty()) return ln;
        if (!n.isEmpty()) return n;
        return email != null ? email : "";
    }
}
