package com.example.myapplication.your.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.myapplication.your.model.User;

import org.json.JSONException;
import org.json.JSONObject;
// Менеджер SharedPreferences для хранения пользовательских данных и токенов
public class SharedPrefManager {

    private static final String PREF_NAME = "bolgarin_prefs";
    private static final String KEY_CURRENT_USER_EMAIL = "current_user_email";
    private static final String KEY_CURRENT_USER_JSON = "current_user_json";
    private static final String KEY_AUTH_ACCESS_TOKEN = "auth_access_token";
    private static final String KEY_AUTH_REFRESH_TOKEN = "auth_refresh_token";
    private static final String KEY_PREFIX_SKIP_GROUP_SIGNUP_CANCEL_WARN = "skip_group_signup_cancel_warn_v2_";

    private static SharedPrefManager instance;
    private final Context appContext;
    private final SharedPreferences prefs;

    private SharedPrefManager(Context context) {
        appContext = context.getApplicationContext();
        prefs = appContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        if (instance == null) {
            instance = new SharedPrefManager(context);
        }
        return instance;
    }
    // Сохраняет пользователя с паролем
    public void saveUser(User user, String password) {
        JSONObject json = new JSONObject();
        try {
            json.put("id", user.getId());
            json.put("name", user.getName());
            json.put("email", user.getEmail());
            json.put("phone", user.getPhone());
            if (user.getAvatarUrl() != null) {
                json.put("avatar_url", user.getAvatarUrl());
            }
            if (user.getRole() != null && !user.getRole().isEmpty()) {
                json.put("role", user.getRole());
            }
            json.put("password", password);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        prefs.edit()
                .putString("user_" + user.getEmail(), json.toString())
                .apply();
    }
    // Сохраняет текущего пользователя в JSON-формате
    public void saveCurrentUser(User user) {
        if (user == null) return;
        JSONObject json = new JSONObject();
        try {
            json.put("id", user.getId());
            json.put("name", user.getName());
            if (user.getSurname() != null && !user.getSurname().trim().isEmpty()) {
                json.put("surname", user.getSurname().trim());
            }
            if (user.getPatronymic() != null && !user.getPatronymic().trim().isEmpty()) {
                json.put("patronymic", user.getPatronymic().trim());
            }
            if (user.getBirthDate() != null && !user.getBirthDate().trim().isEmpty()) {
                json.put("birth_date", user.getBirthDate().trim());
            }
            json.put("email", user.getEmail());
            if (user.getPhone() != null && !user.getPhone().trim().isEmpty()) {
                json.put("phone", user.getPhone().trim());
            }
            if (user.getAvatarUrl() != null) {
                json.put("avatar_url", user.getAvatarUrl());
            }
            if (user.getRole() != null && !user.getRole().isEmpty()) {
                json.put("role", user.getRole());
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        prefs.edit()
                .putString(KEY_CURRENT_USER_JSON, json.toString())
                .putString(KEY_CURRENT_USER_EMAIL, user.getEmail())
                .apply();
    }
    // Сохраняет токены аутентификации
    public void saveAuthTokens(String accessToken, String refreshToken) {
        prefs.edit()
                .putString(KEY_AUTH_ACCESS_TOKEN, accessToken)
                .putString(KEY_AUTH_REFRESH_TOKEN, refreshToken)
                .apply();
    }

    public String getAccessToken() {
        return prefs.getString(KEY_AUTH_ACCESS_TOKEN, null);
    }

    public String getRefreshToken() {
        return prefs.getString(KEY_AUTH_REFRESH_TOKEN, null);
    }
    // Получает пользователя по email
    public User getUserByEmail(String email) {
        String s = prefs.getString("user_" + email, null);
        if (s == null) return null;

        try {
            JSONObject json = new JSONObject(s);
            User user = new User();
            user.setId(json.optString("id"));
            user.setName(json.optString("name"));
            user.setSurname(json.optString("surname", null));
            if (user.getSurname() != null && user.getSurname().isEmpty()) user.setSurname(null);
            user.setPatronymic(json.optString("patronymic", null));
            if (user.getPatronymic() != null && user.getPatronymic().isEmpty()) user.setPatronymic(null);
            user.setBirthDate(json.optString("birth_date", null));
            if (user.getBirthDate() != null && user.getBirthDate().isEmpty()) user.setBirthDate(null);
            user.setEmail(json.optString("email"));
            user.setPhone(json.optString("phone"));
            user.setAvatarUrl(json.optString("avatar_url", null));
            if (user.getAvatarUrl() != null && user.getAvatarUrl().isEmpty()) {
                user.setAvatarUrl(null);
            }
            if (json.has("role")) {
                user.setRole(json.optString("role", com.example.myapplication.your.model.User.ROLE_CLIENT));
            }
            return user;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void setCurrentUser(User user) {
        if (user != null && user.getEmail() != null) {
            prefs.edit()
                    .putString(KEY_CURRENT_USER_EMAIL, user.getEmail())
                    .apply();
        }
    }
    // Получает текущего пользователя
    public User getCurrentUser() {

        String jsonStr = prefs.getString(KEY_CURRENT_USER_JSON, null);
        if (jsonStr != null) {
            try {
                JSONObject json = new JSONObject(jsonStr);
                User user = new User();
                user.setId(json.optString("id"));
                user.setName(json.optString("name"));
                user.setSurname(json.optString("surname", null));
                if (user.getSurname() != null && user.getSurname().isEmpty()) user.setSurname(null);
                user.setPatronymic(json.optString("patronymic", null));
                if (user.getPatronymic() != null && user.getPatronymic().isEmpty()) user.setPatronymic(null);
                user.setBirthDate(json.optString("birth_date", null));
                if (user.getBirthDate() != null && user.getBirthDate().isEmpty()) user.setBirthDate(null);
                user.setEmail(json.optString("email"));
                String ph = json.optString("phone");
                if (ph != null && !ph.trim().isEmpty() && !"null".equalsIgnoreCase(ph.trim())) {
                    user.setPhone(ph.trim());
                } else {
                    user.setPhone(null);
                }
                user.setAvatarUrl(json.optString("avatar_url", null));
                if (user.getAvatarUrl() != null && user.getAvatarUrl().isEmpty()) {
                    user.setAvatarUrl(null);
                }
                String r = json.optString("role", com.example.myapplication.your.model.User.ROLE_CLIENT);
                user.setRole(r != null && !r.isEmpty() ? r : com.example.myapplication.your.model.User.ROLE_CLIENT);
                return user;
            } catch (JSONException ignored) {}
        }

        String email = prefs.getString(KEY_CURRENT_USER_EMAIL, null);
        if (email == null) return null;
        return getUserByEmail(email);
    }

    public void logout() {
        TrainerProfileIdCache.clear();
        UiDataCache.getInstance(appContext).clearAll();
        User u = getCurrentUser();
        SharedPreferences.Editor ed = prefs.edit()
                .remove(KEY_CURRENT_USER_EMAIL)
                .remove(KEY_CURRENT_USER_JSON)
                .remove(KEY_AUTH_ACCESS_TOKEN)
                .remove(KEY_AUTH_REFRESH_TOKEN);
        if (u != null && u.getId() != null && !u.getId().trim().isEmpty()) {
            ed.remove(KEY_PREFIX_SKIP_GROUP_SIGNUP_CANCEL_WARN + u.getId().trim());
        }
        ed.apply();
    }
    // Проверяет, пропущено ли предупреждение об отмене групповой записи
    public boolean isGroupSignupCancelWarningSkipped(String userId) {
        if (userId == null || userId.trim().isEmpty()) return false;
        return prefs.getBoolean(KEY_PREFIX_SKIP_GROUP_SIGNUP_CANCEL_WARN + userId.trim(), false);
    }
    // Устанавливает флаг пропуска предупреждения об отмене
    public void setGroupSignupCancelWarningSkipped(String userId, boolean skip) {
        if (userId == null || userId.trim().isEmpty()) return;
        prefs.edit().putBoolean(KEY_PREFIX_SKIP_GROUP_SIGNUP_CANCEL_WARN + userId.trim(), skip).apply();
    }
    // Получает пароль по email
    public String getPasswordForEmail(String email) {
        String s = prefs.getString("user_" + email, null);
        if (s == null) return null;

        try {
            JSONObject json = new JSONObject(s);
            return json.optString("password");
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void clearCurrentUser() {
    }
}