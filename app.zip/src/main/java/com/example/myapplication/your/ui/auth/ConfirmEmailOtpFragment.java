package com.example.myapplication.your.ui.auth;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.myapplication.R;
import com.example.myapplication.your.viewmodel.AuthViewModel;

//Подтверждение регистрации по коду из письма
public class ConfirmEmailOtpFragment extends Fragment {

    private static final String ARG_EMAIL = "prefill_email";

    private AuthViewModel viewModel;
    private LoginFragment.LoginListener listener;

    public static ConfirmEmailOtpFragment newInstance(@Nullable String prefilledEmail) {
        ConfirmEmailOtpFragment f = new ConfirmEmailOtpFragment();
        if (prefilledEmail != null && !prefilledEmail.trim().isEmpty()) {
            Bundle b = new Bundle();
            b.putString(ARG_EMAIL, prefilledEmail.trim());
            f.setArguments(b);
        }
        return f;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof LoginFragment.LoginListener) {
            listener = (LoginFragment.LoginListener) context;
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_confirm_email_otp, container, false);
    }

    private com.google.android.material.textfield.TextInputEditText etCode;
    private ProgressBar progressBar;
    private String confirmEmail = "";

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        etCode = view.findViewById(R.id.etOtpCode);
        progressBar = view.findViewById(R.id.progressBarOtp);
        viewModel = new ViewModelProvider(requireActivity()).get(AuthViewModel.class);

        Bundle args = getArguments();
        if (args != null) {
            String pre = args.getString(ARG_EMAIL);
            if (pre != null && !pre.isEmpty()) {
                confirmEmail = pre.trim();
            }
        }
// Кнопка подтверждения
        view.findViewById(R.id.btnConfirmOtp).setOnClickListener(v -> {
            String code = etCode.getText() != null ? etCode.getText().toString().trim() : "";
            if (TextUtils.isEmpty(confirmEmail) || TextUtils.isEmpty(code)) {
                Toast.makeText(requireContext(), R.string.fill_required_fields, Toast.LENGTH_SHORT).show();
                return;
            }
            if (code.length() < 6) {
                Toast.makeText(requireContext(), R.string.confirm_email_need_code, Toast.LENGTH_SHORT).show();
                return;
            }
            viewModel.verifySignupEmailOtp(confirmEmail, code);
        });

        view.findViewById(R.id.btnWrongEmail).setOnClickListener(v -> {
            if (!isAdded()) return;
            // Возврат к регистрации, если email был указан неверно.
            requireActivity().getSupportFragmentManager().popBackStack(null,
                    androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE);
            ((AuthActivity) requireActivity()).openFragment(new RegisterFragment(), false);
        });

        view.findViewById(R.id.btnBackToLogin).setOnClickListener(v ->
                requireActivity().getSupportFragmentManager().popBackStack());

        viewModel.getLoading().observe(getViewLifecycleOwner(), loading ->
                progressBar.setVisibility(Boolean.TRUE.equals(loading) ? View.VISIBLE : View.GONE));

        viewModel.getUser().observe(getViewLifecycleOwner(), user -> {
            if (user != null && listener != null) {
                viewModel.clearRegisterDraft();
                listener.onLoginSuccess();
            }
        });

        viewModel.getError().observe(getViewLifecycleOwner(), err -> {
            if (err != null) {
                Toast.makeText(requireContext(), err, Toast.LENGTH_LONG).show();
                viewModel.clearError();
            }
        });
    }
}
