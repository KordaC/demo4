package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.data.TrainerRepository;
import com.example.myapplication.your.model.TrainerProfile;
import com.example.myapplication.your.model.TrainerReview;
import com.example.myapplication.your.model.TrainingDirection;
import com.example.myapplication.your.model.User;

import java.util.ArrayList;
import java.util.List;

public class TrainerViewModel extends AndroidViewModel {
    private final TrainerRepository repository;
    private final SharedPrefManager prefManager;

    private MutableLiveData<Boolean> loading = new MutableLiveData<>();
    private MutableLiveData<List<TrainerProfile>> trainers = new MutableLiveData<>();
    private MutableLiveData<List<TrainingDirection>> directions = new MutableLiveData<>();
    private MutableLiveData<String> error = new MutableLiveData<>();
    private MutableLiveData<Boolean> reviewSubmitted = new MutableLiveData<>();
    private MutableLiveData<android.util.Pair<String, List<TrainerReview>>> reviews = new MutableLiveData<>();

    public TrainerViewModel(@NonNull Application application) {
        super(application);
        repository = TrainerRepository.getInstance(application);
        prefManager = SharedPrefManager.getInstance(application);
    }

    public LiveData<Boolean> getReviewSubmitted() { return reviewSubmitted; }
    public LiveData<android.util.Pair<String, List<TrainerReview>>> getReviews() { return reviews; }

    public LiveData<Boolean> getLoading() { return loading; }
    public LiveData<List<TrainerProfile>> getTrainers() { return trainers; }
    public LiveData<List<TrainingDirection>> getDirections() { return directions; }
    public LiveData<String> getError() { return error; }
    // Загрузка всех тренеров
    public void loadTrainers() {
        loading.setValue(true);
        new Thread(() -> {
            try {
                List<TrainerProfile> fromCache = repository.getAllTrainersFromCache();
                if (fromCache != null && !fromCache.isEmpty()) {
                    trainers.postValue(fromCache);
                }
                List<TrainerProfile> trainerList = repository.getAllTrainers();
                trainers.postValue(trainerList);
            } catch (Exception e) {
                error.postValue("Ошибка загрузки тренеров: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void loadDirections() {
        loading.setValue(true);
        new Thread(() -> {
            try {
                List<TrainingDirection> fromCache = repository.getAllDirectionsFromCache();
                if (fromCache != null && !fromCache.isEmpty()) {
                    directions.postValue(fromCache);
                }
                List<TrainingDirection> directionList = repository.getAllDirections();
                directions.postValue(directionList);
            } catch (Exception e) {
                error.postValue("Ошибка загрузки направлений: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void loadTrainerDirections(String trainerId) {
        loading.setValue(true);
        new Thread(() -> {
            try {
                List<TrainingDirection> directionList = repository.getTrainerDirections(trainerId);
                directions.postValue(directionList);
            } catch (Exception e) {
                error.postValue("Ошибка загрузки направлений тренера: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void clearError() {
        error.setValue(null);
    }

    //Оставить или обновить отзыв о тренере
    public void submitReview(String trainerId, int rating, String comment) {
        User user = prefManager.getCurrentUser();
        if (user == null || user.getId() == null) {
            error.postValue("Войдите в аккаунт, чтобы оставить отзыв");
            return;
        }
        new Thread(() -> {
            String err = repository.submitReview(user.getId(), trainerId, rating, comment);
            if (err != null) {
                error.postValue(err);
            } else {
                reviewSubmitted.postValue(true);
            }
        }).start();
    }

    public void clearReviewSubmitted() { reviewSubmitted.setValue(false); }
    // Загрузка отзывов о тренере
    public void loadReviews(String trainerId) {
        if (trainerId == null) return;
        new Thread(() -> {
            try {
                List<TrainerReview> list = repository.getReviews(trainerId);
                reviews.postValue(new android.util.Pair<>(trainerId, list != null ? list : new ArrayList<>()));
            } catch (Exception e) {
                reviews.postValue(new android.util.Pair<>(trainerId, new ArrayList<>()));
            }
        }).start();
    }
}

