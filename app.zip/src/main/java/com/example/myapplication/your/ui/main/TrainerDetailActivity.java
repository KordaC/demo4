package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.your.data.FavoritesRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.data.TrainerRepository;
import com.example.myapplication.your.model.TrainerProfile;
import com.example.myapplication.your.model.User;
import com.example.myapplication.your.ui.trainer.TrainerCalendarActivity;

public class TrainerDetailActivity extends AppCompatActivity {

    public static final String EXTRA_TRAINER_ID = "trainer_id";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainer_detail);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Тренер");
        }

        String trainerId = getIntent().getStringExtra(EXTRA_TRAINER_ID);
        if (trainerId == null || trainerId.isEmpty()) {
            Toast.makeText(this, "Не указан тренер", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        ImageView photo = findViewById(R.id.iv_trainer_detail_photo);
        TextView tvName = findViewById(R.id.tv_trainer_detail_name);
        TextView tvExp = findViewById(R.id.tv_trainer_detail_exp);
        TextView tvRating = findViewById(R.id.tv_trainer_detail_rating);
        TextView tvBio = findViewById(R.id.tv_trainer_detail_bio);
        TextView tvSpecs = findViewById(R.id.tv_trainer_detail_specs);
        View btnBook = findViewById(R.id.btn_trainer_detail_book);
        ImageButton btnFav = findViewById(R.id.btn_trainer_detail_favorite);

        User curUser = SharedPrefManager.getInstance(this).getCurrentUser();
        final boolean adminView = curUser != null && curUser.isAdmin();

        TrainerRepository repo = TrainerRepository.getInstance(this);
        new Thread(() -> {
            try {
                TrainerProfile t = repo.getTrainerById(trainerId);
                runOnUiThread(() -> {
                    if (t == null) {
                        Toast.makeText(this, "Тренер не найден", Toast.LENGTH_SHORT).show();
                        finish();
                        return;
                    }
                    if (adminView) {
                        btnBook.setVisibility(View.GONE);
                        if (btnFav != null) btnFav.setVisibility(View.GONE);
                    }
                    tvName.setText(t.getName() != null ? t.getName() : "Тренер");
                    tvExp.setText(t.getFormattedExperience());
                    tvRating.setText(t.getRating() != null ? t.getFormattedRating() : "Нет оценок");
                    tvBio.setText(t.getBio() != null && !t.getBio().isEmpty() ? t.getBio() : "Информация скоро появится.");
                    if (t.getSpecializations() != null && !t.getSpecializations().isEmpty()) {
                        tvSpecs.setText("Специализации: " + String.join(", ", t.getSpecializations()));
                    } else {
                        tvSpecs.setText("");
                    }
                    if (t.getPhotoUrl() != null && !t.getPhotoUrl().isEmpty()) {
                        Glide.with(this).load(t.getPhotoUrl()).centerCrop().into(photo);
                    }
                    if (!adminView && btnFav != null && t.getId() != null) {
                        FavoritesRepository fr = FavoritesRepository.getInstance(this);
                        btnFav.setImageResource(fr.isTrainerFavorite(t.getId())
                                ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                        btnFav.setOnClickListener(v -> {
                            fr.toggleTrainerFavorite(t.getId());
                            btnFav.setImageResource(fr.isTrainerFavorite(t.getId())
                                    ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                        });
                    }
                    if (!adminView) {
                        btnBook.setOnClickListener(v -> {
                            Intent i = new Intent(this, TrainerCalendarActivity.class);
                            i.putExtra(TrainerCalendarActivity.EXTRA_TRAINER_ID, t.getId());
                            startActivity(i);
                        });
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Ошибка загрузки: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    finish();
                });
            }
        }).start();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
