package com.example.myapplication.your.data;

import android.app.Application;

import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.User;

public final class TrainerProfileIdCache {
    private static volatile String cachedProfileId;
    private static volatile String cachedAppUserId;
    // Кэш ID профиля тренера
    private TrainerProfileIdCache() {}

    public static void clear() {
        cachedProfileId = null;
        cachedAppUserId = null;
    }
    // Обновляет кэш из сервера
    public static void refreshFromServer(Application app) {
        User u = SharedPrefManager.getInstance(app).getCurrentUser();
        if (u == null || u.getId() == null || !u.isTrainer()) {
            cachedProfileId = null;
            cachedAppUserId = null;
            return;
        }
        if (u.getId().equals(cachedAppUserId) && cachedProfileId != null) {
            return;
        }
        try {
            cachedProfileId = TrainerRepository.getInstance(app).getTrainerProfileIdByAppUserId(u.getId());
            cachedAppUserId = u.getId();
        } catch (Exception e) {
            cachedProfileId = null;
            cachedAppUserId = u.getId();
        }
    }
    // Проверяет, является ли тренером текущий пользовател
    public static boolean isLedByCachedTrainer(Session session) {
        if (session == null || session.getTrainerId() == null) return false;
        String tid = cachedProfileId;
        return tid != null && tid.equals(session.getTrainerId());
    }
}
