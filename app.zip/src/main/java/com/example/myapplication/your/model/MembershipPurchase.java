package com.example.myapplication.your.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class MembershipPurchase implements Serializable {
    private String id;
    private String userId;
    private String planId;
    private MembershipPlan plan;
    private LocalDate startDate;
    private LocalDate endDate;
    private Integer visitsLeft;
    private int freezeDaysUsed;
    private String status;
    private String purchasedAt;
    private Integer groupVisitsLeft;
    private LocalDate groupPeriodStart;

    public MembershipPurchase() {}

    public MembershipPurchase(String id, String userId, String planId, 
                             LocalDate startDate, LocalDate endDate, 
                             Integer visitsLeft, int freezeDaysUsed, String status) {
        this.id = id;
        this.userId = userId;
        this.planId = planId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.visitsLeft = visitsLeft;
        this.freezeDaysUsed = freezeDaysUsed;
        this.status = status;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getPlanId() { return planId; }
    public void setPlanId(String planId) { this.planId = planId; }

    public MembershipPlan getPlan() { return plan; }
    public void setPlan(MembershipPlan plan) { this.plan = plan; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public Integer getVisitsLeft() { return visitsLeft; }
    public void setVisitsLeft(Integer visitsLeft) { this.visitsLeft = visitsLeft; }

    public int getFreezeDaysUsed() { return freezeDaysUsed; }
    public void setFreezeDaysUsed(int freezeDaysUsed) { this.freezeDaysUsed = freezeDaysUsed; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getPurchasedAt() { return purchasedAt; }
    public void setPurchasedAt(String purchasedAt) { this.purchasedAt = purchasedAt; }

    public Integer getGroupVisitsLeft() { return groupVisitsLeft; }
    public void setGroupVisitsLeft(Integer groupVisitsLeft) { this.groupVisitsLeft = groupVisitsLeft; }

    public LocalDate getGroupPeriodStart() { return groupPeriodStart; }
    public void setGroupPeriodStart(LocalDate groupPeriodStart) { this.groupPeriodStart = groupPeriodStart; }

    public long getDaysLeft() {
        if (endDate == null) return 0;
        LocalDate today = LocalDate.now();
        if (today.isAfter(endDate)) return 0;
        return ChronoUnit.DAYS.between(today, endDate);
    }

    public boolean isActive() {
        return "active".equals(status) && getDaysLeft() > 0;
    }

    public boolean canFreeze() {
        if (plan == null) return false;
        return isActive() && (freezeDaysUsed < plan.getFreezeDays());
    }
}

