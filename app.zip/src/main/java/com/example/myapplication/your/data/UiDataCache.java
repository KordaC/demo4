package com.example.myapplication.your.data;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.Nullable;
// Кэш для UI-данных
public final class UiDataCache {
    private static final String PREF = "ui_data_cache_v1";
    private static final String K_SCHEDULE_UPCOMING_RAW = "schedule_upcoming_raw";
    private static final String K_TRAINERS_JSON = "trainers_all_json";
    private static final String K_MEMBERSHIP_ACTIVE_JSON = "membership_active_json";
    private static final String K_DIRECTIONS_JSON = "directions_json";

    private static UiDataCache instance;
    private final SharedPreferences prefs;

    private UiDataCache(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static synchronized UiDataCache getInstance(Context context) {
        if (instance == null) {
            instance = new UiDataCache(context);
        }
        return instance;
    }
    // Предстоящие занятия
    public void putScheduleUpcomingRaw(@Nullable String jsonResponse) {
        if (jsonResponse == null || jsonResponse.trim().isEmpty()) return;
        prefs.edit().putString(K_SCHEDULE_UPCOMING_RAW, jsonResponse).apply();
    }

    @Nullable
    public String getScheduleUpcomingRaw() {
        return prefs.getString(K_SCHEDULE_UPCOMING_RAW, null);
    }
    // Тренеры
    public void putTrainersJson(@Nullable String json) {
        if (json == null || json.trim().isEmpty()) return;
        prefs.edit().putString(K_TRAINERS_JSON, json).apply();
    }

    @Nullable
    public String getTrainersJson() {
        return prefs.getString(K_TRAINERS_JSON, null);
    }
    // Активные абонементы
    public void putMembershipActiveJson(@Nullable String json) {
        if (json == null || json.trim().isEmpty()) return;
        prefs.edit().putString(K_MEMBERSHIP_ACTIVE_JSON, json).apply();
    }

    @Nullable
    public String getMembershipActiveJson() {
        return prefs.getString(K_MEMBERSHIP_ACTIVE_JSON, null);
    }
    // Направления
    public void putDirectionsJson(@Nullable String json) {
        if (json == null || json.trim().isEmpty()) return;
        prefs.edit().putString(K_DIRECTIONS_JSON, json).apply();
    }

    @Nullable
    public String getDirectionsJson() {
        return prefs.getString(K_DIRECTIONS_JSON, null);
    }
    // Очистка всего кэша
    public void clearAll() {
        prefs.edit().clear().apply();
    }
}
