package com.example.myapplication.your.data;

import android.content.Context;
import android.util.Log;

import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.TrainerPtRow;
import com.example.myapplication.your.model.UserPersonalBooking;
import com.example.myapplication.your.util.AppUserDisplayName;
import com.example.myapplication.your.util.TimestampParseUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
// Репозиторий для управления персональными тренировками
public class PersonalTrainingRepository {
    private static final String TAG = "PersonalTrainingRepo";
    private static PersonalTrainingRepository instance;
    private final String supabaseUrl;
    private final String supabaseKey;
    private final ScheduleRepository scheduleRepository;
    // Слоты времени по умолчанию
    private static final String[] DEFAULT_TIME_SLOTS = {
            "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00",
            "17:00", "18:00", "19:00", "20:00", "21:00"
    };

    private PersonalTrainingRepository(Context context) {
        supabaseUrl = SupabaseClientProvider.getSupabaseUrl();
        supabaseKey = SupabaseClientProvider.getSupabaseAnonKey();
        scheduleRepository = ScheduleRepository.getInstance(context.getApplicationContext());
    }

    public static synchronized PersonalTrainingRepository getInstance(Context context) {
        if (instance == null) {
            instance = new PersonalTrainingRepository(context);
        }
        return instance;
    }
    // Возвращает список доступных временных слотов
    public List<String> getTimeSlots() {
        List<String> list = new ArrayList<>();
        for (String s : DEFAULT_TIME_SLOTS) {
            list.add(s);
        }
        return list;
    }

    private static final DateTimeFormatter TIME_SLOT_FORMAT = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DATE_TIME_DISPLAY = DateTimeFormatter.ofPattern("dd.MM.yyyy, HH:mm");
    // Проверяет, пересекается ли персональная тренировка с групповым занятием
    private static boolean personalSlotOverlapsGroup(LocalDateTime ptStart, LocalDateTime ptEnd, Session g) {
        if (g == null || g.getStartTime() == null) return false;
        LocalDateTime gStart = g.getStartTime();
        LocalDateTime gEnd = g.getEndTime() != null ? g.getEndTime() : gStart.plusHours(1);
        return ptStart.isBefore(gEnd) && gStart.isBefore(ptEnd);
    }
    // Проверяет конфликт с групповыми занятиями тренера
    private String groupSessionConflictIfAny(String trainerId, ZonedDateTime requestedZ) {
        if (trainerId == null || trainerId.trim().isEmpty()) return null;
        LocalDateTime ptStart = requestedZ.toLocalDateTime();
        LocalDateTime ptEnd = ptStart.plusHours(1);
        try {
            List<Session> groups = scheduleRepository.getSessionsForTrainerOnDate(trainerId.trim(), requestedZ.toLocalDate());
            for (Session s : groups) {
                if (personalSlotOverlapsGroup(ptStart, ptEnd, s)) {
                    return "В это время у тренера групповое занятие. Выберите другое время.";
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "groupSessionConflictIfAny", e);
        }
        return null;
    }
    // Получает занятые слоты для тренера на указанную дату
    public List<String> getBusySlots(String trainerId, LocalDate date) {
        if (trainerId == null || trainerId.trim().isEmpty()) {
            return new ArrayList<>();
        }
        try {
            ZoneId zone = ZoneId.systemDefault();
            ZonedDateTime dayStartZ = date.atStartOfDay(zone);
            ZonedDateTime dayEndZ = date.plusDays(1).atStartOfDay(zone);
            String dayStartUtc = dayStartZ.toInstant().toString();
            String dayEndUtc = dayEndZ.toInstant().toString();
            // Запрос существующих персональных тренировок
            String url = supabaseUrl + "/rest/v1/personal_training"
                    + "?trainer_id=eq." + trainerId
                    + "&requested_time=gte." + dayStartUtc
                    + "&requested_time=lt." + dayEndUtc
                    + "&or=(status.eq.approved,status.eq.requested)"
                    + "&select=requested_time";
            String jsonResponse = makeGetRequest(url);
            Set<String> busy = new HashSet<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) {
                return new ArrayList<>();
            }
            // Парсим занятые слоты из персональных тренировок
            JSONArray arr = new JSONArray(jsonResponse);
            for (int i = 0; i < arr.length(); i++) {
                String requestedTime = arr.getJSONObject(i).optString("requested_time");
                if (requestedTime == null || requestedTime.isEmpty()) continue;
                try {
                    Instant instant;
                    if (requestedTime.endsWith("Z") || requestedTime.contains("+") || requestedTime.lastIndexOf('-') > 10) {
                        try {
                            instant = Instant.parse(requestedTime);
                        } catch (Exception e) {
                            instant = OffsetDateTime.parse(requestedTime).toInstant();
                        }
                    } else {
                        instant = LocalDateTime.parse(requestedTime.substring(0, Math.min(19, requestedTime.length())))
                                .atZone(zone).toInstant();
                    }
                    LocalTime localTime = instant.atZone(zone).toLocalTime();
                    int h = localTime.getHour();
                    busy.add(String.format("%02d:00", h));
                } catch (Exception parseEx) {
                    if (requestedTime.length() >= 16) {
                        String timePart = requestedTime.substring(11, 16);
                        busy.add(timePart);
                    }
                }
            }
            // Добавляем слоты, занятые групповыми занятиями
            try {
                List<Session> groups = scheduleRepository.getSessionsForTrainerOnDate(trainerId.trim(), date);
                for (String slot : DEFAULT_TIME_SLOTS) {
                    LocalTime t = LocalTime.parse(slot, TIME_SLOT_FORMAT);
                    LocalDateTime slotStart = date.atTime(t);
                    LocalDateTime slotEnd = slotStart.plusHours(1);
                    for (Session g : groups) {
                        if (personalSlotOverlapsGroup(slotStart, slotEnd, g)) {
                            busy.add(slot);
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                Log.w(TAG, "getBusySlots group overlap", e);
            }
            List<String> result = new ArrayList<>(busy);
            java.util.Collections.sort(result);
            return result;
        } catch (Exception e) {
            Log.e(TAG, "Error fetching busy slots", e);
            return new ArrayList<>();
        }
    }
    // Получает список записей пользователя на персональные тренировки
    public List<UserPersonalBooking> getUserBookings(String userId) {
        if (userId == null || userId.trim().isEmpty()) {
            return new ArrayList<>();
        }
        try {
            String url = supabaseUrl + "/rest/v1/personal_training"
                    + "?user_id=eq." + userId
                    + "&order=requested_time.desc"
                    + "&select=id,trainer_id,requested_time,status";
            String jsonResponse = makeGetRequest(url);
            List<UserPersonalBooking> result = new ArrayList<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) {
                return result;
            }
            ZoneId zone = ZoneId.systemDefault();
            JSONArray arr = new JSONArray(jsonResponse);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String id = o.optString("id");
                String trainerId = o.optString("trainer_id");
                String requestedTime = o.optString("requested_time");
                String status = o.optString("status", "requested");
                String dateTimeFormatted = "";
                long sortMs = 0L;
                if (requestedTime != null && !requestedTime.isEmpty()) {
                    try {
                        Instant instant;
                        if (requestedTime.endsWith("Z") || requestedTime.contains("+") || requestedTime.lastIndexOf('-') > 10) {
                            try {
                                instant = Instant.parse(requestedTime);
                            } catch (Exception e) {
                                instant = OffsetDateTime.parse(requestedTime).toInstant();
                            }
                        } else {
                            instant = LocalDateTime.parse(requestedTime.substring(0, Math.min(19, requestedTime.length())))
                                    .atZone(zone).toInstant();
                        }
                        sortMs = instant.toEpochMilli();
                        dateTimeFormatted = instant.atZone(zone).format(DATE_TIME_DISPLAY);
                    } catch (Exception parseEx) {
                        dateTimeFormatted = requestedTime.length() >= 16 ? requestedTime.substring(0, 16) : requestedTime;
                    }
                }
                result.add(new UserPersonalBooking(id, trainerId, dateTimeFormatted, status, sortMs));
            }
            return result;
        } catch (Exception e) {
            Log.e(TAG, "Error fetching user bookings", e);
            return new ArrayList<>();
        }
    }
    // Запись на персональную тренировку
    public String bookSlot(String userId, String trainerId, LocalDate date, String timeSlot) {
        try {
            LocalTime time = LocalTime.parse(timeSlot, TIME_SLOT_FORMAT);
            ZonedDateTime requestedZ = date.atTime(time).atZone(ZoneId.systemDefault());
            String requestedTimeStr = requestedZ.toInstant().toString();
            Instant now = Instant.now();
            if (!requestedZ.toInstant().isAfter(now)) {
                return "Нельзя записаться на прошедшее время.";
            }

            String groupMsg = groupSessionConflictIfAny(trainerId, requestedZ);
            if (groupMsg != null) return groupMsg;
            ZonedDateTime hourEndZ = requestedZ.plusHours(1);
            String hourStartUtc = requestedZ.toInstant().toString();
            String hourEndUtc = hourEndZ.toInstant().toString();
            // Проверяем, не занят ли уже этот слот
            String checkUrl = supabaseUrl + "/rest/v1/personal_training"
                    + "?trainer_id=eq." + trainerId
                    + "&requested_time=gte." + hourStartUtc
                    + "&requested_time=lt." + hourEndUtc
                    + "&or=(status.eq.requested,status.eq.approved)"
                    + "&select=id"
                    + "&limit=1";
            String checkResponse = makeGetRequest(checkUrl);
            if (checkResponse != null && !checkResponse.trim().isEmpty() && !checkResponse.trim().equals("[]")) {
                JSONArray arr = new JSONArray(checkResponse);
                if (arr.length() > 0) {
                    return "Это время уже занято.";
                }
            }
            // Создаём запись
            JSONObject data = new JSONObject();
            data.put("user_id", userId);
            data.put("trainer_id", trainerId);
            data.put("requested_time", requestedTimeStr);
            data.put("status", "requested");

            String url = supabaseUrl + "/rest/v1/personal_training";
            makePostRequest(url, data.toString());
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error booking slot", e);
            String msg = e.getMessage() != null ? e.getMessage() : e.toString();
            if (msg.contains("409") || msg.contains("duplicate")) {
                return "Это время уже занято.";
            }
            return "Ошибка записи: " + msg;
        }
    }
    public String reschedulePersonalBooking(String userId, String bookingId, String trainerId, LocalDate date, String timeSlot) {
        if (userId == null || userId.trim().isEmpty()) return "Не указан пользователь.";
        if (bookingId == null || bookingId.trim().isEmpty()) return "Запись не найдена.";
        if (trainerId == null || trainerId.trim().isEmpty()) return "Не указан тренер.";
        try {
            String getUrl = supabaseUrl + "/rest/v1/personal_training?id=eq." + bookingId.trim()
                    + "&select=user_id,trainer_id,status";
            String json = makeGetRequest(getUrl);
            JSONArray arr = new JSONArray(json);
            if (arr.length() == 0) return "Запись не найдена.";
            JSONObject row = arr.getJSONObject(0);
            if (!userId.trim().equals(row.optString("user_id", "").trim())) {
                return "Нет доступа к записи.";
            }
            if (!trainerId.trim().equals(row.optString("trainer_id", "").trim())) {
                return "Несовпадение тренера.";
            }
            String st = row.optString("status", "");
            if ("cancelled".equalsIgnoreCase(st)) return "Запись отменена.";
            if ("done".equalsIgnoreCase(st)) return "Тренировка уже проведена.";

            LocalTime time = LocalTime.parse(timeSlot, TIME_SLOT_FORMAT);
            ZonedDateTime requestedZ = date.atTime(time).atZone(ZoneId.systemDefault());
            Instant now = Instant.now();
            if (!requestedZ.toInstant().isAfter(now)) {
                return "Нельзя перенести на прошедшее время.";
            }

            String groupMsg = groupSessionConflictIfAny(trainerId, requestedZ);
            if (groupMsg != null) return groupMsg;

            ZonedDateTime hourEndZ = requestedZ.plusHours(1);
            String hourStartUtc = requestedZ.toInstant().toString();
            String hourEndUtc = hourEndZ.toInstant().toString();
            String encStart = URLEncoder.encode(hourStartUtc, StandardCharsets.UTF_8.name());
            String encEnd = URLEncoder.encode(hourEndUtc, StandardCharsets.UTF_8.name());

            String checkUrl = supabaseUrl + "/rest/v1/personal_training"
                    + "?trainer_id=eq." + trainerId.trim()
                    + "&requested_time=gte." + encStart
                    + "&requested_time=lt." + encEnd
                    + "&or=(status.eq.requested,status.eq.approved)"
                    + "&id=neq." + bookingId.trim()
                    + "&select=id&limit=1";
            String checkResponse = makeGetRequest(checkUrl);
            if (checkResponse != null && !checkResponse.trim().isEmpty() && !checkResponse.trim().equals("[]")) {
                JSONArray occ = new JSONArray(checkResponse);
                if (occ.length() > 0) {
                    return "Это время уже занято.";
                }
            }

            JSONObject patch = new JSONObject();
            patch.put("requested_time", requestedZ.toInstant().toString());
            String patchUrl = supabaseUrl + "/rest/v1/personal_training?id=eq." + bookingId.trim()
                    + "&user_id=eq." + userId.trim();
            makePatchRequest(patchUrl, patch.toString());
            return null;
        } catch (Exception e) {
            Log.e(TAG, "reschedulePersonalBooking", e);
            return "Ошибка переноса: " + (e.getMessage() != null ? e.getMessage() : e.toString());
        }
    }
    // Получает предстоящие персональные тренировки для тренера
    public List<TrainerPtRow> getUpcomingPersonalForTrainer(String trainerProfileId, int limit) throws Exception {
        if (trainerProfileId == null || trainerProfileId.trim().isEmpty()) {
            return new ArrayList<>();
        }
        String nowIso = java.time.OffsetDateTime.now(java.time.ZoneOffset.UTC)
                .format(java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        String lim = limit > 0 ? String.valueOf(limit) : "100";
        String sel = "id,user_id,requested_time,status,app_user(name,last_name)";
        String encSel = URLEncoder.encode(sel, StandardCharsets.UTF_8.name());
        String url = supabaseUrl + "/rest/v1/personal_training"
                + "?trainer_id=eq." + trainerProfileId.trim()
                + "&requested_time=gte." + URLEncoder.encode(nowIso, StandardCharsets.UTF_8.name())
                + "&or=(status.eq.requested,status.eq.approved)"
                + "&order=requested_time.asc"
                + "&limit=" + lim
                + "&select=" + encSel;
        String jsonResponse;
        try {
            jsonResponse = makeGetRequest(url);
        } catch (Exception e) {
            Log.w(TAG, "personal_training embed app_user failed, fallback *", e);
            url = supabaseUrl + "/rest/v1/personal_training"
                    + "?trainer_id=eq." + trainerProfileId.trim()
                    + "&requested_time=gte." + URLEncoder.encode(nowIso, StandardCharsets.UTF_8.name())
                    + "&or=(status.eq.requested,status.eq.approved)"
                    + "&order=requested_time.asc"
                    + "&limit=" + lim
                    + "&select=*";
            jsonResponse = makeGetRequest(url);
        }
        List<TrainerPtRow> out = new ArrayList<>();
        if (jsonResponse == null || jsonResponse.trim().isEmpty()) return out;
        JSONArray arr = new JSONArray(jsonResponse);
        List<JSONObject> rows = new ArrayList<>();
        LinkedHashSet<String> userIdsForNames = new LinkedHashSet<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            String uid = o.optString("user_id", "").trim();
            if (uid.isEmpty()) {
                continue;
            }
            rows.add(o);
            boolean haveName = o.has("app_user") && !o.isNull("app_user");
            String embedded = "";
            if (haveName) {
                embedded = o.getJSONObject("app_user").optString("name", "").trim();
            }
            if (!haveName || embedded.isEmpty()) {
                userIdsForNames.add(uid);
            }
        }
        Map<String, String> idToName = fetchAppUserNamesByIds(new ArrayList<>(userIdsForNames));
        for (JSONObject o : rows) {
            String uid = o.optString("user_id", "").trim();
            String id = o.optString("id");
            String status = o.optString("status", "");
            String rt = o.optString("requested_time");
            LocalDateTime start = TimestampParseUtil.parseSupabaseTimestampToLocal(rt);
            if (start == null) continue;
            String clientName = "";
            if (o.has("app_user") && !o.isNull("app_user")) {
                clientName = AppUserDisplayName.fromAppUserJson(o.getJSONObject("app_user"));
                if ("Клиент".equals(clientName)) clientName = "";
            }
            if (clientName.isEmpty()) {
                clientName = idToName.get(uid);
            }
            if (clientName == null || clientName.isEmpty()) {
                clientName = "Клиент";
            }
            out.add(new TrainerPtRow(id, start, clientName, status));
        }
        return out;
    }
    // Получает имена пользователей по списку ID
    private Map<String, String> fetchAppUserNamesByIds(List<String> userIds) throws Exception {
        Map<String, String> out = new LinkedHashMap<>();
        if (userIds == null || userIds.isEmpty()) return out;
        final int chunk = 40;
        for (int start = 0; start < userIds.size(); start += chunk) {
            int end = Math.min(start + chunk, userIds.size());
            StringBuilder inB = new StringBuilder();
            for (int i = start; i < end; i++) {
                if (inB.length() > 0) inB.append(',');
                inB.append(userIds.get(i).trim());
            }
            String reqUrl = supabaseUrl + "/rest/v1/app_user?id=in.(" + inB + ")&select=id,name,last_name";
            String jsonResponse = makeGetRequest(reqUrl);
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) continue;
            JSONArray nameRows = new JSONArray(jsonResponse);
            for (int j = 0; j < nameRows.length(); j++) {
                JSONObject row = nameRows.getJSONObject(j);
                String aid = row.optString("id", "").trim();
                if (aid.isEmpty()) continue;
                out.put(aid, AppUserDisplayName.fromAppUserJson(row));
            }
        }
        return out;
    }

    private static String cleanUserNameField(JSONObject json, String key) {
        if (json == null || !json.has(key) || json.isNull(key)) return null;
        String s = json.optString(key, "").trim();
        if (s.isEmpty() || "null".equalsIgnoreCase(s)) return null;
        return s;
    }
    // Отмена персональной тренировки
    public String cancelPersonalBooking(String bookingId) {
        try {
            if (bookingId == null || bookingId.trim().isEmpty()) {
                return "Запись не найдена";
            }
            JSONObject data = new JSONObject();
            data.put("status", "cancelled");

            String url = supabaseUrl + "/rest/v1/personal_training?id=eq." + bookingId;
            makePatchRequest(url, data.toString());
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error canceling personal booking", e);
            String msg = e.getMessage() != null ? e.getMessage() : e.toString();
            return "Ошибка отмены: " + msg;
        }
    }
    // HTTP GET запрос с anon-ключом
    private String makeGetRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        conn.setRequestProperty("Content-Type", "application/json");

        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader err = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = err.readLine()) != null) sb.append(line);
            err.close();
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        return response.toString();
    }
    // HTTP POST запрос
    private void makePostRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonData.getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader err = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = err.readLine()) != null) sb.append(line);
            err.close();
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
    }
    // HTTP PATCH запрос
    private void makePatchRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PATCH");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonData.getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader err = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = err.readLine()) != null) sb.append(line);
            err.close();
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
    }
}
