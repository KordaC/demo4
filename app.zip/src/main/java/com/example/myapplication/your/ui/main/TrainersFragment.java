package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.data.FavoritesRepository;
import com.example.myapplication.your.model.TrainerProfile;
import com.example.myapplication.your.model.TrainerReview;
import com.example.myapplication.your.viewmodel.TrainerViewModel;
import com.example.myapplication.your.ui.trainer.TrainerCalendarActivity;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class TrainersFragment extends Fragment {

    private static final String ARG_ADMIN_MODE = "admin_mode";

    private boolean adminMode;
    private TrainerViewModel viewModel;
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private View tvEmpty;
    private android.widget.TextView tvError;
    private TrainerAdapter adapter;
    private TrainerProfile pendingReviewsTrainer;

    public static TrainersFragment newInstance(boolean adminMode) {
        TrainersFragment f = new TrainersFragment();
        Bundle args = new Bundle();
        args.putBoolean(ARG_ADMIN_MODE, adminMode);
        f.setArguments(args);
        return f;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_trainers, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adminMode = getArguments() != null && getArguments().getBoolean(ARG_ADMIN_MODE, false);

        viewModel = new ViewModelProvider(this).get(TrainerViewModel.class);

        recyclerView = view.findViewById(R.id.recycler_trainers);
        progressBar = view.findViewById(R.id.progress_bar);
        tvEmpty = view.findViewById(R.id.tv_empty_trainers);
        tvError = view.findViewById(R.id.tv_error_trainers);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        adapter = new TrainerAdapter(new ArrayList<>(), trainer -> {
            if (adminMode) return;
            Intent intent = new Intent(requireContext(), TrainerCalendarActivity.class);
            intent.putExtra("trainer_id", trainer.getId());
            startActivity(intent);
        }, this::showReviewDialog, this::showReviewsDialog, trainer -> {
            Intent i = new Intent(requireContext(), TrainerDetailActivity.class);
            i.putExtra(TrainerDetailActivity.EXTRA_TRAINER_ID, trainer.getId());
            startActivity(i);
        }, adminMode);

        recyclerView.setAdapter(adapter);

        observeViewModel();
        viewModel.loadTrainers();
    }

    private void showReviewDialog(TrainerProfile trainer) {
        if (adminMode) return;
        if (!isAdded() || getContext() == null) return;
        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_review_trainer, null);
        RatingBar ratingBar = dialogView.findViewById(R.id.rating_bar_review);
        EditText etComment = dialogView.findViewById(R.id.et_review_comment);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        dialogView.findViewById(R.id.btn_review_cancel).setOnClickListener(v -> dialog.dismiss());
        dialogView.findViewById(R.id.btn_review_submit).setOnClickListener(v -> {
            int rating = (int) ratingBar.getRating();
            if (rating < 1) rating = 1;
            String comment = etComment.getText() != null ? etComment.getText().toString().trim() : "";
            viewModel.submitReview(trainer.getId(), rating, comment);
            dialog.dismiss();
        });
        dialog.show();
    }

    private void showReviewsDialog(TrainerProfile trainer) {
        if (!isAdded() || getContext() == null) return;
        pendingReviewsTrainer = trainer;
        viewModel.loadReviews(trainer.getId());
    }

    private void openReviewsListDialog(String trainerName, List<TrainerReview> list) {
        if (!isAdded() || getContext() == null) return;
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_reviews_list, null);
        android.widget.TextView title = view.findViewById(R.id.tv_reviews_title);
        ProgressBar progress = view.findViewById(R.id.progress_reviews);
        android.widget.TextView empty = view.findViewById(R.id.tv_reviews_empty);
        RecyclerView recycler = view.findViewById(R.id.recycler_reviews);

        title.setText("Отзывы: " + (trainerName != null ? trainerName : "тренер"));
        progress.setVisibility(View.GONE);
        empty.setVisibility(list == null || list.isEmpty() ? View.VISIBLE : View.GONE);
        recycler.setVisibility(list != null && !list.isEmpty() ? View.VISIBLE : View.GONE);

        if (list != null && !list.isEmpty()) {
            recycler.setLayoutManager(new LinearLayoutManager(getContext()));
            ReviewsAdapter ad = new ReviewsAdapter(list);
            recycler.setAdapter(ad);
        }

        new AlertDialog.Builder(requireContext())
                .setView(view)
                .setPositiveButton("Закрыть", (d, w) -> d.dismiss())
                .show();
    }

    private void observeViewModel() {
        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE));

        viewModel.getTrainers().observe(getViewLifecycleOwner(), trainers -> {
            adapter.updateTrainers(trainers);
            boolean empty = trainers == null || trainers.isEmpty();
            if (tvEmpty != null) tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
            if (!empty && tvError != null) tvError.setVisibility(View.GONE);
        });

        viewModel.getError().observe(getViewLifecycleOwner(), error -> {
            if (error != null) {
                if (isAdded() && getContext() != null) {
                    Toast.makeText(getContext(), error, Toast.LENGTH_LONG).show();
                }
                if (tvError != null) {
                    tvError.setText("Ошибка: " + error);
                    tvError.setVisibility(View.VISIBLE);
                }
                viewModel.clearError();
            } else {
                if (tvError != null) tvError.setVisibility(View.GONE);
            }
        });

        viewModel.getReviewSubmitted().observe(getViewLifecycleOwner(), submitted -> {
            if (Boolean.TRUE.equals(submitted)) {
                if (isAdded() && getContext() != null) {
                    Toast.makeText(getContext(), "Спасибо! Ваш отзыв сохранён.", Toast.LENGTH_SHORT).show();
                    viewModel.loadTrainers();
                }
                viewModel.clearReviewSubmitted();
            }
        });

        viewModel.getReviews().observe(getViewLifecycleOwner(), pair -> {
            if (pair == null || pendingReviewsTrainer == null || !isAdded()) return;
            if (!pendingReviewsTrainer.getId().equals(pair.first)) return;
            List<TrainerReview> loaded = pair.second;
            if (loaded != null && !loaded.isEmpty()) {
                applyReviewStatsFromList(pendingReviewsTrainer, loaded);
                adapter.notifyTrainerItemChanged(pendingReviewsTrainer.getId());
            }
            openReviewsListDialog(pendingReviewsTrainer.getName(), loaded);
            pendingReviewsTrainer = null;
        });
    }

    /** Средняя оценка и число отзывов по уже загруженным данным (подстраховка, если батч по API не заполнил карточку). */
    private static void applyReviewStatsFromList(TrainerProfile trainer, List<TrainerReview> list) {
        if (trainer == null || list == null || list.isEmpty()) return;
        double sum = 0;
        int n = 0;
        for (TrainerReview r : list) {
            if (r == null) continue;
            int rv = r.getRating();
            if (rv > 0) {
                sum += rv;
                n++;
            }
        }
        if (n > 0) {
            trainer.setRating(sum / n);
            trainer.setReviewCount(n);
        }
    }

    private static class TrainerAdapter
            extends RecyclerView.Adapter<TrainerAdapter.ViewHolder> {

        interface OnTrainerClickListener {
            void onBookClick(TrainerProfile trainer);
        }

        interface OnReviewClickListener {
            void onReviewClick(TrainerProfile trainer);
        }

        interface OnReviewsListClickListener {
            void onReviewsListClick(TrainerProfile trainer);
        }

        private List<TrainerProfile> trainers;
        private final OnTrainerClickListener listener;
        private final OnReviewClickListener reviewListener;
        private final OnReviewsListClickListener reviewsListListener;
        private final OnCardClickListener cardListener;
        private final boolean adminMode;

        interface OnCardClickListener {
            void onCardClick(TrainerProfile trainer);
        }

        TrainerAdapter(List<TrainerProfile> trainers,
                       OnTrainerClickListener listener,
                       OnReviewClickListener reviewListener,
                       OnReviewsListClickListener reviewsListListener,
                       OnCardClickListener cardListener,
                       boolean adminMode) {
            this.trainers = trainers;
            this.listener = listener;
            this.reviewListener = reviewListener;
            this.reviewsListListener = reviewsListListener;
            this.cardListener = cardListener;
            this.adminMode = adminMode;
        }

        void updateTrainers(List<TrainerProfile> newTrainers) {
            this.trainers = newTrainers != null
                    ? newTrainers
                    : new ArrayList<>();
            notifyDataSetChanged();
        }

        void notifyTrainerItemChanged(String trainerId) {
            if (trainerId == null) return;
            for (int i = 0; i < trainers.size(); i++) {
                TrainerProfile p = trainers.get(i);
                if (p != null && trainerId.equals(p.getId())) {
                    notifyItemChanged(i);
                    return;
                }
            }
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent,
                                             int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_trainer, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder,
                                     int position) {
            holder.bind(trainers.get(position), listener, reviewListener, reviewsListListener, cardListener, adminMode);
        }

        @Override
        public int getItemCount() {
            return trainers.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {

            android.widget.TextView tvName;
            android.widget.TextView tvExperience;
            android.widget.TextView tvRating;
            android.widget.TextView tvReviewsLink;
            android.widget.TextView tvBio;
            android.widget.TextView tvSpecializations;
            android.widget.Button btnBook;
            View btnReview;
            android.widget.ImageView ivPhoto;
            ImageButton btnFavorite;

            ViewHolder(@NonNull View itemView) {
                super(itemView);
                ivPhoto = itemView.findViewById(R.id.iv_trainer_photo);
                btnFavorite = itemView.findViewById(R.id.btn_trainer_favorite);
                tvName = itemView.findViewById(R.id.tv_trainer_name);
                tvExperience = itemView.findViewById(R.id.tv_trainer_experience);
                tvRating = itemView.findViewById(R.id.tv_trainer_rating);
                tvReviewsLink = itemView.findViewById(R.id.tv_trainer_reviews_link);
                tvBio = itemView.findViewById(R.id.tv_trainer_bio);
                tvSpecializations = itemView.findViewById(R.id.tv_trainer_specializations);
                btnBook = itemView.findViewById(R.id.btn_book_trainer);
                btnReview = itemView.findViewById(R.id.btn_review_trainer);
            }

            void bind(TrainerProfile trainer,
                     OnTrainerClickListener listener,
                     OnReviewClickListener reviewListener,
                     OnReviewsListClickListener reviewsListListener,
                     OnCardClickListener cardListener,
                     boolean adminMode) {

                if (ivPhoto != null) {
                    if (trainer.getPhotoUrl() != null && !trainer.getPhotoUrl().isEmpty()) {
                        Glide.with(itemView.getContext()).load(trainer.getPhotoUrl()).centerCrop().into(ivPhoto);
                    } else {
                        ivPhoto.setImageResource(R.drawable.ic_user);
                    }
                }
                itemView.setOnClickListener(v -> {
                    if (cardListener != null) cardListener.onCardClick(trainer);
                });

                if (adminMode) {
                    btnBook.setVisibility(View.GONE);
                    if (btnFavorite != null) btnFavorite.setVisibility(View.GONE);
                    if (btnReview != null) btnReview.setVisibility(View.GONE);
                } else {
                    btnBook.setVisibility(View.VISIBLE);
                    if (btnFavorite != null) btnFavorite.setVisibility(View.VISIBLE);
                    if (btnReview != null) btnReview.setVisibility(View.VISIBLE);
                }

                tvName.setText(trainer.getName() != null ? trainer.getName() : "Тренер");
                tvExperience.setText(trainer.getFormattedExperience());
                tvRating.setText(trainer.getRating() != null ? trainer.getFormattedRating() : "Нет оценок");

                int count = trainer.getReviewCount() != null ? trainer.getReviewCount() : 0;
                if (tvReviewsLink != null) {
                    tvReviewsLink.setText(count > 0 ? "Отзывы (" + count + ")" : "Отзывы");
                    tvReviewsLink.setOnClickListener(v -> {
                        if (reviewsListListener != null) reviewsListListener.onReviewsListClick(trainer);
                    });
                }

                tvBio.setText(trainer.getBio() != null ? trainer.getBio() : "Информация отсутствует");
                if (trainer.getSpecializations() != null && !trainer.getSpecializations().isEmpty()) {
                    tvSpecializations.setText("Специализации: " + String.join(", ", trainer.getSpecializations()));
                } else {
                    tvSpecializations.setText("Специализации не указаны");
                }

                btnBook.setOnClickListener(v -> {
                    if (!adminMode && listener != null) listener.onBookClick(trainer);
                });
                if (btnReview != null) {
                    btnReview.setOnClickListener(v -> {
                        if (!adminMode && reviewListener != null) reviewListener.onReviewClick(trainer);
                    });
                }

                if (btnFavorite != null && trainer.getId() != null) {
                    if (adminMode) {
                        btnFavorite.setVisibility(View.GONE);
                    } else {
                        btnFavorite.setVisibility(View.VISIBLE);
                        FavoritesRepository fr = FavoritesRepository.getInstance(itemView.getContext());
                        btnFavorite.setImageResource(fr.isTrainerFavorite(trainer.getId())
                                ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                        btnFavorite.setOnClickListener(v -> {
                            fr.toggleTrainerFavorite(trainer.getId());
                            boolean on = fr.isTrainerFavorite(trainer.getId());
                            btnFavorite.setImageResource(on ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                        });
                    }
                }
            }
        }
    }

    private static class ReviewsAdapter extends RecyclerView.Adapter<ReviewsAdapter.Holder> {
        private final List<TrainerReview> items;

        ReviewsAdapter(List<TrainerReview> items) {
            this.items = items != null ? items : new ArrayList<>();
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_review, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            TrainerReview r = items.get(position);
            holder.tvAuthor.setText(r.getUserName() != null ? r.getUserName() : "Гость");
            holder.ratingBar.setRating(r.getRating());
            holder.tvDate.setText(r.getCreatedAtFormatted() != null ? r.getCreatedAtFormatted() : "");
            if (r.getComment() != null && !r.getComment().isEmpty()) {
                holder.tvComment.setText(r.getComment());
                holder.tvComment.setVisibility(View.VISIBLE);
            } else {
                holder.tvComment.setVisibility(View.GONE);
            }
        }

        @Override
        public int getItemCount() { return items.size(); }

        static class Holder extends RecyclerView.ViewHolder {
            final android.widget.TextView tvAuthor;
            final RatingBar ratingBar;
            final android.widget.TextView tvComment;
            final android.widget.TextView tvDate;

            Holder(@NonNull View itemView) {
                super(itemView);
                tvAuthor = itemView.findViewById(R.id.tv_review_author);
                ratingBar = itemView.findViewById(R.id.tv_review_rating);
                tvComment = itemView.findViewById(R.id.tv_review_comment);
                tvDate = itemView.findViewById(R.id.tv_review_date);
            }
        }
    }
}