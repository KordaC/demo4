package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.PersonalTrainingRepository;
import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.data.TrainerRepository;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.TrainerPtRow;
import com.example.myapplication.your.model.TrainerWorkbenchListItem;
import com.example.myapplication.your.model.User;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class TrainerWorkbenchViewModel extends AndroidViewModel {
    private final ScheduleRepository scheduleRepository;
    private final PersonalTrainingRepository personalTrainingRepository;
    private final TrainerRepository trainerRepository;
    private final SharedPrefManager prefManager;
    private final MutableLiveData<Boolean> loading = new MutableLiveData<>();
    private final MutableLiveData<List<TrainerWorkbenchListItem>> itemsUi = new MutableLiveData<>();
    private final MutableLiveData<String> error = new MutableLiveData<>();

    public TrainerWorkbenchViewModel(@NonNull Application application) {
        super(application);
        scheduleRepository = ScheduleRepository.getInstance(application);
        personalTrainingRepository = PersonalTrainingRepository.getInstance(application);
        trainerRepository = TrainerRepository.getInstance(application);
        prefManager = SharedPrefManager.getInstance(application);
    }

    public LiveData<Boolean> getLoading() {
        return loading;
    }

    public LiveData<List<TrainerWorkbenchListItem>> getItemsUi() {
        return itemsUi;
    }

    public LiveData<String> getError() {
        return error;
    }

    public void clearError() {
        error.setValue(null);
    }

    public void loadMyUpcomingSessions() {
        User u = prefManager.getCurrentUser();
        if (u == null || u.getId() == null || u.getId().trim().isEmpty()) {
            error.postValue("Войдите в аккаунт.");
            return;
        }
        loading.postValue(true);
        new Thread(() -> {
            try {
                String trainerId = trainerRepository.getTrainerProfileIdByAppUserId(u.getId());
                if (trainerId == null || trainerId.isEmpty()) {
                    error.postValue("Для вашего аккаунта нет строки в trainer_profile");
                    itemsUi.postValue(null);
                    return;
                }
                List<Session> groupList = scheduleRepository.getUpcomingSessionsForTrainer(trainerId, 100);
                List<String> ids = new ArrayList<>();
                for (Session s : groupList) {
                    if (s.getId() != null) ids.add(s.getId());
                }
                Map<String, List<String>> namesBySession = scheduleRepository.getSignupDisplayNamesBySessionIds(ids);

                List<TrainerWorkbenchListItem> merged = new ArrayList<>();
                for (Session s : groupList) {
                    List<String> names = namesBySession != null ? namesBySession.get(s.getId()) : null;
                    String line;
                    if (names == null || names.isEmpty()) {
                        line = "Записей пока нет.";
                    } else {
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < names.size(); i++) {
                            if (i > 0) sb.append(", ");
                            sb.append(names.get(i));
                        }
                        line = "Записаны: " + sb;
                    }
                    merged.add(TrainerWorkbenchListItem.group(s, line));
                }

                // Персональные карточки
                List<TrainerPtRow> ptList = personalTrainingRepository.getUpcomingPersonalForTrainer(trainerId, 100);
                for (TrainerPtRow row : ptList) {
                    merged.add(TrainerWorkbenchListItem.personal(row));
                }

                Collections.sort(merged, Comparator.comparingLong(TrainerWorkbenchListItem::getSortTimeMillis));
                itemsUi.postValue(merged);
            } catch (Exception e) {
                error.postValue("Не удалось загрузить записи: " + (e.getMessage() != null ? e.getMessage() : e.toString()));
            } finally {
                loading.postValue(false);
            }
        }).start();
    }
}
