package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.data.TrainerProfileIdCache;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.User;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class ScheduleViewModel extends AndroidViewModel {
    private ScheduleRepository repository;
    private SharedPrefManager prefManager;
    private Set<String> userSignedUpSessions = new HashSet<>();
    private MutableLiveData<Boolean> loading = new MutableLiveData<>();
    private MutableLiveData<List<Session>> upcomingSessions = new MutableLiveData<>();
    private MutableLiveData<List<Session>> userSessions = new MutableLiveData<>();
    private MutableLiveData<String> error = new MutableLiveData<>();
    private MutableLiveData<Boolean> signupSuccess = new MutableLiveData<>();
    private MutableLiveData<String> sessionStatusChanged = new MutableLiveData<>();
    private final AtomicInteger upcomingSessionsLoadGeneration = new AtomicInteger(0);

    public ScheduleViewModel(@NonNull Application application) {
        super(application);
        repository = ScheduleRepository.getInstance(application);
        prefManager = SharedPrefManager.getInstance(application);
    }

    public LiveData<Boolean> getLoading() { return loading; }
    public LiveData<List<Session>> getUpcomingSessions() { return upcomingSessions; }
    public LiveData<List<Session>> getUserSessions() { return userSessions; }
    public LiveData<String> getError() { return error; }
    public LiveData<Boolean> getSignupSuccess() { return signupSuccess; }
    public LiveData<String> getSessionStatusChanged() { return sessionStatusChanged; }

    public boolean isTrainerAccount() {
        User u = prefManager.getCurrentUser();
        return u != null && u.isTrainer();
    }

    public void loadUpcomingSessions() {
        final int gen = upcomingSessionsLoadGeneration.incrementAndGet();
        loading.postValue(true);
        new Thread(() -> {
            try {
                List<Session> cached = repository.getUpcomingSessionsFromCache();
                if (cached != null && !cached.isEmpty() && gen == upcomingSessionsLoadGeneration.get()) {
                    User cu = prefManager.getCurrentUser();
                    if (cu != null && cu.getId() != null) {
                        try {
                            userSignedUpSessions.clear();
                            userSignedUpSessions.addAll(repository.getUserSignedUpSessionIds(cu.getId()));
                        } catch (Exception ignored) {
                            userSignedUpSessions.clear();
                        }
                    } else {
                        userSignedUpSessions.clear();
                    }
                    upcomingSessions.postValue(cached);
                }
                TrainerProfileIdCache.refreshFromServer(getApplication());
                User currentUser = prefManager.getCurrentUser();
                List<Session> sessions;
                if (currentUser != null && currentUser.getId() != null) {
                    ExecutorService ex = Executors.newFixedThreadPool(2);
                    try {
                        Future<List<Session>> fSess = ex.submit(() -> repository.getUpcomingSessions());
                        Future<Set<String>> fSign = ex.submit(() -> repository.getUserSignedUpSessionIds(currentUser.getId()));
                        sessions = fSess.get();
                        userSignedUpSessions.clear();
                        userSignedUpSessions.addAll(fSign.get());
                    } finally {
                        ex.shutdown();
                    }
                } else {
                    sessions = repository.getUpcomingSessions();
                    userSignedUpSessions.clear();
                }
                if (gen != upcomingSessionsLoadGeneration.get()) return;
                upcomingSessions.postValue(sessions);
            } catch (Exception e) {
                if (gen != upcomingSessionsLoadGeneration.get()) return;
                error.postValue("Ошибка загрузки расписания: " + e.getMessage());
            } finally {
                if (gen == upcomingSessionsLoadGeneration.get()) {
                    loading.postValue(false);
                }
            }
        }).start();
    }
    public void loadUserSessions() {
        new Thread(() -> {
            try {
                User currentUser = prefManager.getCurrentUser();
                if (currentUser != null && currentUser.getId() != null) {
                    List<Session> sessions = repository.getUserSessions(currentUser.getId());
                    userSessions.postValue(sessions);
                } else {
                    userSessions.postValue(new java.util.ArrayList<>());
                }
            } catch (Exception e) {
                error.postValue("Ошибка загрузки записей: " + e.getMessage());
            }
        }).start();
    }

    public void signUpForSession(String sessionId) {
        userSignedUpSessions.add(sessionId);
        optimisticallyUpdateSignupStatus(sessionId, true);
        loading.postValue(true);
        new Thread(() -> {
            boolean reloadAfter = false;
            try {
                User currentUser = prefManager.getCurrentUser();
                if (currentUser == null || currentUser.getId() == null) {
                    userSignedUpSessions.remove(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, false);
                    error.postValue("Пользователь не авторизован");
                    return;
                }

                if (currentUser.isTrainer()) {
                    userSignedUpSessions.remove(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, false);
                    error.postValue("Тренерам запись на групповые занятия недоступна.");
                    return;
                }

                TrainerProfileIdCache.refreshFromServer(getApplication());
                Session target = repository.getSessionById(sessionId);
                if (target != null && TrainerProfileIdCache.isLedByCachedTrainer(target)) {
                    userSignedUpSessions.remove(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, false);
                    error.postValue("Это ваше занятие — запись на него как клиент недоступна.");
                    return;
                }

                String err = repository.signUpForSession(currentUser.getId(), sessionId);
                if (err != null) {
                    userSignedUpSessions.remove(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, false);
                    error.postValue(err);
                } else {
                    reloadAfter = true;
                    loadUpcomingSessions();
                    signupSuccess.postValue(true);
                }
            } catch (Exception e) {
                userSignedUpSessions.remove(sessionId);
                optimisticallyUpdateSignupStatus(sessionId, false);
                error.postValue("Ошибка записи: " + e.getMessage());
            } finally {
                if (!reloadAfter) {
                    loading.postValue(false);
                }
            }
        }).start();
    }

    public void cancelSession(String sessionId) {
        userSignedUpSessions.remove(sessionId);
        optimisticallyUpdateSignupStatus(sessionId, false);
        loading.postValue(true);
        new Thread(() -> {
            boolean reloadAfter = false;
            try {
                User currentUser = prefManager.getCurrentUser();
                if (currentUser == null || currentUser.getId() == null) {
                    userSignedUpSessions.add(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, true);
                    error.postValue("Пользователь не авторизован");
                    return;
                }

                String err = repository.cancelSession(currentUser.getId(), sessionId);
                if (err != null) {
                    userSignedUpSessions.add(sessionId);
                    optimisticallyUpdateSignupStatus(sessionId, true);
                    error.postValue(err);
                } else {
                    reloadAfter = true;
                    loadUpcomingSessions();
                    signupSuccess.postValue(true);
                }
            } catch (Exception e) {
                userSignedUpSessions.add(sessionId);
                optimisticallyUpdateSignupStatus(sessionId, true);
                error.postValue("Ошибка отмены: " + e.getMessage());
            } finally {
                if (!reloadAfter) {
                    loading.postValue(false);
                }
            }
        }).start();
    }

    public boolean isUserSignedUp(String sessionId) {
        return userSignedUpSessions.contains(sessionId);
    }

    public boolean isLedByCurrentTrainer(Session session) {
        return TrainerProfileIdCache.isLedByCachedTrainer(session);
    }
    
    public void optimisticallyUpdateSignupStatus(String sessionId, boolean signUp) {
        boolean changed = false;
        if (signUp) {
            changed = userSignedUpSessions.add(sessionId);
        } else {
            changed = userSignedUpSessions.remove(sessionId);
        }
        if (changed) {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                sessionStatusChanged.setValue(sessionId + "_" + System.currentTimeMillis());
            });
        }
    }

    public void clearError() {
        error.postValue(null);
    }

    public void clearSignupSuccess() {
        signupSuccess.postValue(false);
    }
}

