package com.example.myapplication.your.ui.main;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.your.data.FavoritesRepository;
import com.example.myapplication.your.data.MembershipRepository;
import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.data.TrainerProfileIdCache;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.util.GroupSignupUiHelper;
import com.example.myapplication.your.viewmodel.ScheduleViewModel;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class SessionDetailActivity extends AppCompatActivity {

    public static final String EXTRA_SESSION = "session";
    public static final String EXTRA_ADMIN_MODE = "extra_admin_mode";

    private boolean adminMode;
    private String pendingGroupPaymentSessionId;
    private boolean waitingForGroupPayment = false;
    private ActivityResultLauncher<Intent> paymentLauncher;

    private Session detailSession;
    private ScheduleViewModel viewModel;
    private com.google.android.material.button.MaterialButton btnDetailAction;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_session_detail);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Занятие");
        }

        detailSession = (Session) getIntent().getSerializableExtra(EXTRA_SESSION);
        if (detailSession == null) {
            Toast.makeText(this, "Нет данных о занятии", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        adminMode = getIntent().getBooleanExtra(EXTRA_ADMIN_MODE, false);

        viewModel = new ViewModelProvider(this).get(ScheduleViewModel.class);

        LinearProgressIndicator progressTop = findViewById(R.id.progress_session_detail);
        if (progressTop != null) {
            progressTop.setIndeterminate(true);
        }

        btnDetailAction = findViewById(R.id.btn_detail_action);
        if (adminMode) {
            btnDetailAction.setVisibility(View.GONE);
        } else if (viewModel.isTrainerAccount()) {
            btnDetailAction.setVisibility(View.GONE);
        } else {
            btnDetailAction.setText(R.string.session_action_loading);
            btnDetailAction.setEnabled(false);
        }

        bindSessionToUi();

        paymentLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    waitingForGroupPayment = false;
                    if (result.getResultCode() == Activity.RESULT_OK && pendingGroupPaymentSessionId != null) {
                        viewModel.signUpForSession(pendingGroupPaymentSessionId);
                    }
                }
        );

        viewModel.getLoading().observe(this, loading -> {
            if (progressTop != null) {
                progressTop.setVisibility(Boolean.TRUE.equals(loading) ? View.VISIBLE : View.GONE);
            }
        });

        viewModel.loadUpcomingSessions();
        viewModel.getUpcomingSessions().observe(this, list -> bindButton());

        viewModel.getError().observe(this, err -> {
            if (err != null) {
                boolean isLimitExhausted = err.contains("Исчерпан лимит групповых посещений");
                boolean needSingleGroup = MembershipRepository.NEED_PAY_SINGLE_GROUP_SESSION.equals(err);
                if ((isLimitExhausted || needSingleGroup) && pendingGroupPaymentSessionId != null && !waitingForGroupPayment) {
                    waitingForGroupPayment = true;
                    Intent pi = new Intent(this, PaymentActivity.class);
                    if (needSingleGroup) {
                        pi.putExtra(PaymentActivity.EXTRA_PAY_SINGLE_GROUP_SESSION_ID, pendingGroupPaymentSessionId);
                    } else {
                        pi.putExtra(PaymentActivity.EXTRA_GROUP_TOPUP, true);
                        pi.putExtra(PaymentActivity.EXTRA_GROUP_TOPUP_COUNT, 1);
                    }
                    paymentLauncher.launch(pi);
                    viewModel.clearError();
                    return;
                }
                Toast.makeText(this, err, Toast.LENGTH_LONG).show();
                viewModel.clearError();
            }
        });

        viewModel.getSignupSuccess().observe(this, ok -> {
            if (Boolean.TRUE.equals(ok)) {
                Toast.makeText(this, "Готово", Toast.LENGTH_SHORT).show();
                viewModel.clearSignupSuccess();
                pendingGroupPaymentSessionId = null;
                waitingForGroupPayment = false;
                bindButton();
            }
        });

        viewModel.getSessionStatusChanged().observe(this, x -> bindButton());

        ScheduleRepository repo = ScheduleRepository.getInstance(this);
        View rowClients = findViewById(R.id.row_detail_clients);
        TextView tvClients = findViewById(R.id.tv_detail_clients);
        rowClients.setVisibility(View.GONE);

        new Thread(() -> {
            try {
                TrainerProfileIdCache.refreshFromServer(getApplication());
                Session fresh = repo.getSessionById(detailSession.getId());
                Map<String, List<String>> map =
                        repo.getSignupDisplayNamesBySessionIds(Collections.singletonList(detailSession.getId()));
                List<String> names = map != null ? map.get(detailSession.getId()) : null;
                runOnUiThread(() -> {
                    if (fresh != null) {
                        detailSession = fresh;
                        bindSessionToUi();
                    }
                    if (TrainerProfileIdCache.isLedByCachedTrainer(detailSession)) {
                        rowClients.setVisibility(View.VISIBLE);
                        if (names != null && !names.isEmpty()) {
                            tvClients.setText(TextUtils.join(", ", names.toArray(new String[0])));
                        } else {
                            tvClients.setText(R.string.session_detail_clients_empty);
                        }
                    } else {
                        rowClients.setVisibility(View.GONE);
                    }
                    bindButton();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (TrainerProfileIdCache.isLedByCachedTrainer(detailSession)) {
                        rowClients.setVisibility(View.VISIBLE);
                        tvClients.setText(R.string.session_detail_clients_empty);
                    }
                    bindButton();
                });
            }
        }).start();
    }

    private void bindSessionToUi() {
        Session session = detailSession;

        ImageView ivCover = findViewById(R.id.iv_detail_cover);
        if (ivCover != null) {
            String cover = session.getImageUrl();
            if (cover != null && cover.startsWith("http")) {
                ivCover.setVisibility(View.VISIBLE);
                Glide.with(this).load(cover).centerCrop().into(ivCover);
            } else {
                ivCover.setVisibility(View.GONE);
            }
        }

        TextView tvTitle = findViewById(R.id.tv_detail_title);
        TextView tvTime = findViewById(R.id.tv_detail_time);
        View rowDirection = findViewById(R.id.row_detail_direction);
        TextView tvDirection = findViewById(R.id.tv_detail_direction);
        View rowLevel = findViewById(R.id.row_detail_level);
        TextView tvLevel = findViewById(R.id.tv_detail_level);
        TextView tvTrainer = findViewById(R.id.tv_detail_trainer);
        View rowPrice = findViewById(R.id.row_detail_price);
        TextView tvPrice = findViewById(R.id.tv_detail_price);
        View rowHall = findViewById(R.id.row_detail_hall);
        TextView tvHall = findViewById(R.id.tv_detail_hall);
        TextView tvDesc = findViewById(R.id.tv_detail_description);
        TextView tvSpots = findViewById(R.id.tv_detail_spots);

        tvTitle.setText(Session.isPresentableText(session.getTitle()) ? session.getTitle() : getString(R.string.session_default_title));
        tvTime.setText(session.getFormattedDateTimeLine());

        if (Session.isPresentableText(session.getDirectionName())) {
            tvDirection.setText("Тип: " + session.getDirectionName());
            rowDirection.setVisibility(View.VISIBLE);
        } else {
            rowDirection.setVisibility(View.GONE);
        }

        if (Session.isPresentableText(session.getLevel())) {
            tvLevel.setText("Уровень: " + session.getLevel());
            rowLevel.setVisibility(View.VISIBLE);
        } else {
            rowLevel.setVisibility(View.GONE);
        }

        if (Session.isPresentableText(session.getTrainerName())) {
            tvTrainer.setText("Тренер: " + session.getTrainerName());
        } else {
            tvTrainer.setText(R.string.session_detail_trainer_unknown);
        }

        if (rowPrice != null && tvPrice != null) {
            String priceLine = buildPriceLine(session);
            if (priceLine.isEmpty()) {
                rowPrice.setVisibility(View.GONE);
            } else {
                tvPrice.setText(priceLine);
                rowPrice.setVisibility(View.VISIBLE);
            }
        }

        String hallLine = buildHallLine(session);
        if (hallLine.isEmpty()) {
            rowHall.setVisibility(View.GONE);
        } else {
            tvHall.setText(hallLine);
            rowHall.setVisibility(View.VISIBLE);
        }

        String desc = session.getDescription();
        if (!Session.isPresentableText(desc)) {
            tvDesc.setText("Описание появится после обновления данных в клубе.");
        } else {
            tvDesc.setText(desc);
        }

        tvSpots.setText("Мест: " + session.getSpotsTaken() + " / " + session.getCapacity());

        ImageButton btnFav = findViewById(R.id.btn_detail_favorite);
        if (btnFav != null) {
            if (adminMode || viewModel.isTrainerAccount()) {
                btnFav.setVisibility(View.GONE);
            } else if (session.getId() != null) {
                FavoritesRepository fr = FavoritesRepository.getInstance(this);
                btnFav.setImageResource(fr.isSessionFavorite(session.getId())
                        ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                btnFav.setOnClickListener(v -> {
                    fr.toggleSessionFavorite(session.getId());
                    btnFav.setImageResource(fr.isSessionFavorite(session.getId())
                            ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                });
            }
        }
    }

    private static String buildPriceLine(Session session) {
        if (session == null) return "";
        return "Разовое посещение: " + session.getPriceLabelForCard();
    }

    private static String buildHallLine(Session session) {
        boolean hasNum = Session.isPresentableText(session.getHallNumber());
        boolean hasName = Session.isPresentableText(session.getHallName());
        boolean hasAddr = Session.isPresentableText(session.getHallAddress());
        if (!hasNum && !hasName && !hasAddr) return "";
        StringBuilder sb = new StringBuilder();
        if (hasNum) {
            sb.append("Зал № ").append(session.getHallNumber().trim());
        }
        if (hasName) {
            if (sb.length() > 0) sb.append(" · ");
            sb.append(session.getHallName().trim());
        }
        if (hasAddr) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(session.getHallAddress().trim());
        }
        return sb.toString();
    }

    private void bindButton() {
        if (detailSession == null || btnDetailAction == null) return;
        if (adminMode) {
            btnDetailAction.setVisibility(View.GONE);
            return;
        }
        if (viewModel.isTrainerAccount()) {
            btnDetailAction.setVisibility(View.GONE);
            return;
        }
        btnDetailAction.setVisibility(View.VISIBLE);
        if (viewModel.isLedByCurrentTrainer(detailSession)) {
            btnDetailAction.setText("Ваше занятие");
            btnDetailAction.setEnabled(false);
            btnDetailAction.setOnClickListener(null);
            return;
        }

        boolean signed = viewModel.isUserSignedUp(detailSession.getId());
        boolean full = detailSession.isFull() && !signed;
        boolean canCancel = ScheduleRepository.canCancelGroupSession(detailSession.getStartTime());
        boolean ended = detailSession.isGroupSessionEndedNow();
        boolean started = detailSession.hasGroupSessionStartedNow();

        if (ended) {
            btnDetailAction.setText(R.string.session_status_completed);
            btnDetailAction.setEnabled(false);
            btnDetailAction.setOnClickListener(null);
            return;
        }
        if (signed && started) {
            btnDetailAction.setText(R.string.session_status_in_progress);
            btnDetailAction.setEnabled(false);
            btnDetailAction.setOnClickListener(null);
            return;
        }
        if (!signed && started) {
            btnDetailAction.setText(R.string.session_signup_closed);
            btnDetailAction.setEnabled(false);
            btnDetailAction.setOnClickListener(null);
            return;
        }

        if (full) {
            btnDetailAction.setText("Мест нет");
            btnDetailAction.setEnabled(false);
            btnDetailAction.setOnClickListener(null);
        } else if (signed && !canCancel) {
            btnDetailAction.setText("Отмена недоступна (<2 ч до начала)");
            btnDetailAction.setEnabled(false);
            btnDetailAction.setOnClickListener(null);
        } else if (signed) {
            btnDetailAction.setText("Отменить запись");
            btnDetailAction.setEnabled(true);
            btnDetailAction.setOnClickListener(v -> viewModel.cancelSession(detailSession.getId()));
        } else {
            btnDetailAction.setText("Записаться");
            btnDetailAction.setEnabled(true);
            btnDetailAction.setOnClickListener(v ->
                    GroupSignupUiHelper.showSignupWarningThen(SessionDetailActivity.this, () -> {
                        pendingGroupPaymentSessionId = detailSession.getId();
                        viewModel.signUpForSession(detailSession.getId());
                    }));
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
