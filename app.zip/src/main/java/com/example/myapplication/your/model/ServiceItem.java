package com.example.myapplication.your.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class ServiceItem implements Serializable {
    private String id;
    private String name;
    private String description;
    private BigDecimal price;
    private String category;
    private Boolean isActive;

    public ServiceItem() {}

    public ServiceItem(String id, String name, String description, BigDecimal price) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
    }


    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    public String getFormattedPrice() {
        if (price == null) return "Цена не указана";
        return String.format("%.2f ₽", price.doubleValue());
    }
}

