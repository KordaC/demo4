package com.example.myapplication.your.ui.auth;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.myapplication.your.data.AuthRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.model.User;
import com.example.myapplication.your.ui.main.MainActivity;
import com.example.myapplication.R;

public class  AuthActivity extends AppCompatActivity implements LoginFragment.LoginListener, RegisterFragment.RegisterListener {

    private ProgressBar progressRedirect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);
        progressRedirect = findViewById(R.id.progress_auth_redirect);
// 1. Проверяем, не пришли ли мы по deep link из письма подтверждения
        if (consumeAuthRedirectIntent(getIntent())) {
            return;
        }
// 2. Если пользователь уже авторизован — сразу в главный экран
        User currentUser = SharedPrefManager.getInstance(this).getCurrentUser();
        if (currentUser != null) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }
// 3. Показываем экран входа
        if (savedInstanceState == null) {
            openFragment(new LoginFragment(), false);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (consumeAuthRedirectIntent(intent)) {
            return;
        }
    }

    //Ссылка из письма Supabase
    private boolean consumeAuthRedirectIntent(Intent intent) {
        if (intent == null) return false;
        Uri data = intent.getData();
        if (data == null) return false;
        if (!"myapp15".equalsIgnoreCase(data.getScheme())) return false;
        if (!"auth-callback".equalsIgnoreCase(data.getHost())) return false;

        String fullLink = intent.getDataString();
        intent.setData(null);

        if (progressRedirect != null) progressRedirect.setVisibility(View.VISIBLE);

        new Thread(() -> {
            AuthRepository.AuthResult res = AuthRepository.getInstance(this).completeSessionFromOAuthRedirect(data, fullLink);
            runOnUiThread(() -> {
                if (progressRedirect != null) progressRedirect.setVisibility(View.GONE);
                if (res != null && res.isSuccess()) {
                    Toast.makeText(this, R.string.auth_email_confirmed_ok, Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                } else {
                    String msg = res != null && res.error != null ? res.error : getString(R.string.auth_deep_link_failed);
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                    if (getSupportFragmentManager().findFragmentById(R.id.auth_fragment_container) == null) {
                        openFragment(new LoginFragment(), false);
                    }
                }
            });
        }).start();
        return true;
    }

    public void openFragment(Fragment fragment, boolean addToBackStack) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.auth_fragment_container, fragment);
        if (addToBackStack) ft.addToBackStack(null);
        ft.commit();
    }


    @Override
    public void onLoginSuccess() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onRegisterSuccess() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
