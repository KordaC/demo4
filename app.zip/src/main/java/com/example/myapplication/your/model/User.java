package com.example.myapplication.your.model;
// package your.package.name.model;


import java.io.Serializable;
import java.util.Arrays;
import java.util.Locale;

public class User implements Serializable {
    public static final String ROLE_CLIENT = "client";
    public static final String ROLE_TRAINER = "trainer";
    public static final String ROLE_ADMIN = "admin";

    private String id;
    private String name;
    private String surname;
    private String patronymic;
    private String birthDate;
    private String email;
    private String phone;
    private String avatarUrl;
    private String role;

    public User() {}

    public User(String id, String name, String email, String phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }


    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getSurname() { return surname; }
    public void setSurname(String surname) { this.surname = surname; }

    public String getPatronymic() { return patronymic; }
    public void setPatronymic(String patronymic) { this.patronymic = patronymic; }

    public String getFullNameOfficial() {
        String sur = nz(surname);
        String n = nz(name);
        String p = nz(patronymic);
        StringBuilder sb = new StringBuilder();
        if (!sur.isEmpty()) sb.append(sur);
        if (!n.isEmpty()) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(n);
        }
        if (!p.isEmpty()) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(p);
        }
        return sb.toString();
    }

    public String getShortDisplayName() {
        String n = nz(name);
        String sur = nz(surname);
        StringBuilder sb = new StringBuilder();
        if (!n.isEmpty()) sb.append(n);
        if (!sur.isEmpty()) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(sur);
        }
        return sb.toString();
    }

    public void applyFullNameLineFromPayment(String line) {
        if (line == null) return;
        String t = line.trim();
        if (t.isEmpty()) return;
        String[] parts = t.split("\\s+");
        if (parts.length >= 3) {
            setSurname(parts[0]);
            setName(parts[1]);
            setPatronymic(String.join(" ", Arrays.copyOfRange(parts, 2, parts.length)));
        } else if (parts.length == 2) {
            setName(parts[0]);
            setSurname(parts[1]);
            setPatronymic(null);
        } else {
            setName(parts[0]);
        }
    }

    private static String nz(String s) {
        if (s == null) return "";
        String x = s.trim();
        return "null".equalsIgnoreCase(x) ? "" : x;
    }

    public String getBirthDate() { return birthDate; }
    public void setBirthDate(String birthDate) { this.birthDate = birthDate; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAvatarUrl() { return avatarUrl; }
    public void setAvatarUrl(String avatarUrl) { this.avatarUrl = avatarUrl; }

    public String getRole() {
        return role != null && !role.trim().isEmpty() ? role.trim().toLowerCase(Locale.ROOT) : ROLE_CLIENT;
    }

    public boolean hasExplicitRole() {
        return role != null && !role.trim().isEmpty();
    }

    public void setRole(String role) { this.role = role; }

    public boolean isTrainer() {
        return ROLE_TRAINER.equals(getRole());
    }

    public boolean isAdmin() {
        return ROLE_ADMIN.equals(getRole());
    }
}