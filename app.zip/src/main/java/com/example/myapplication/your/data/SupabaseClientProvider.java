package com.example.myapplication.your.data;
import com.example.myapplication.BuildConfig;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
// Провайдер клиента Supabase для Retrofit
public class SupabaseClientProvider {

    private static Retrofit retrofit;

    // Возвращает экземпляр Retrofit
    public static synchronized Retrofit getInstance() {

        if (retrofit == null) {


            Interceptor headerInterceptor = new Interceptor() {
                @Override
                public Response intercept(Chain chain) throws IOException {
                    Request newRequest = chain.request()
                            .newBuilder()
                            .addHeader("apikey", BuildConfig.SUPABASE_ANON_KEY)
                            .addHeader("Authorization", "Bearer " + BuildConfig.SUPABASE_ANON_KEY)
                            .addHeader("Content-Type", "application/json")
                            .build();
                    return chain.proceed(newRequest);
                }
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(headerInterceptor)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(BuildConfig.SUPABASE_URL + "/rest/v1/")
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }

        return retrofit;
    }


    public static String getSupabaseUrl() {
        return BuildConfig.SUPABASE_URL;
    }

    public static String getSupabaseAnonKey() {
        return BuildConfig.SUPABASE_ANON_KEY;
    }
}

