package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ConcatAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.model.MembershipPlan;
import com.example.myapplication.your.model.MembershipPurchase;
import com.example.myapplication.your.viewmodel.MembershipViewModel;

import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MyClubFragment extends Fragment {
    private MembershipViewModel viewModel;

    // Кэш для фильтрации каталога по текущим активным абонементам
    private final List<MembershipPurchase> activePurchasesCache = new ArrayList<>();
    private final List<MembershipPlan> availablePlansCache = new ArrayList<>();

    private TextView tvNoActive;
    private RecyclerView recyclerActiveMemberships;
    private ActiveMembershipsAdapter activeAdapter;
    private ProgressBar progressBar;
    private RecyclerView recyclerViewPlans;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_club, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        
        viewModel = new ViewModelProvider(this).get(MembershipViewModel.class);
        
        tvNoActive = view.findViewById(R.id.tv_no_active_membership);
        recyclerActiveMemberships = view.findViewById(R.id.recycler_active_memberships);
        progressBar = view.findViewById(R.id.progress_bar);
        recyclerViewPlans = view.findViewById(R.id.recycler_plans);

        recyclerActiveMemberships.setLayoutManager(new LinearLayoutManager(requireContext()));
        activeAdapter = new ActiveMembershipsAdapter();
        recyclerActiveMemberships.setAdapter(activeAdapter);

        recyclerViewPlans.setLayoutManager(new LinearLayoutManager(requireContext()));

        observeViewModel();
        viewModel.loadMembershipScreen();
    }

    @Override
    public void onResume() {
        super.onResume();
        viewModel.loadMembershipScreen();
    }
    
    private void observeViewModel() {
        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        });
        
        viewModel.getActiveMemberships().observe(getViewLifecycleOwner(), this::bindActiveMemberships);
        
        viewModel.getAvailablePlans().observe(getViewLifecycleOwner(), this::bindMembershipCatalog);
        
        viewModel.getError().observe(getViewLifecycleOwner(), error -> {
            if (error != null) {
                Toast.makeText(requireContext(), error, Toast.LENGTH_SHORT).show();
                viewModel.clearError();
            }
        });
        
        viewModel.getPurchaseSuccess().observe(getViewLifecycleOwner(), success -> {
            if (success != null && success) {
                Toast.makeText(requireContext(), "Абонемент успешно куплен!", Toast.LENGTH_SHORT).show();
                viewModel.clearPurchaseSuccess();
                viewModel.loadMembershipScreen();
            }
        });

        viewModel.getFreezeSuccess().observe(getViewLifecycleOwner(), success -> {
            if (success != null && success) {
                Toast.makeText(requireContext(), "Абонемент заморожен", Toast.LENGTH_SHORT).show();
                viewModel.clearFreezeSuccess();
                viewModel.loadMembershipScreen();
            }
        });

        viewModel.getUnfreezeSuccess().observe(getViewLifecycleOwner(), success -> {
            if (success != null && success) {
                Toast.makeText(requireContext(), "Абонемент разморожен", Toast.LENGTH_SHORT).show();
                viewModel.clearUnfreezeSuccess();
                viewModel.loadMembershipScreen();
            }
        });
    }

    private void bindActiveMemberships(List<MembershipPurchase> list) {
        List<MembershipPurchase> items = list != null ? list : new ArrayList<>();
        activePurchasesCache.clear();
        activePurchasesCache.addAll(items);
        if (items.isEmpty()) {
            tvNoActive.setVisibility(View.VISIBLE);
            recyclerActiveMemberships.setVisibility(View.GONE);
            activeAdapter.submit(new ArrayList<>());
        } else {
            tvNoActive.setVisibility(View.GONE);
            recyclerActiveMemberships.setVisibility(View.VISIBLE);
            activeAdapter.submit(new ArrayList<>(items));
        }
        List<MembershipPlan> plansForCatalog = viewModel.getAvailablePlans().getValue();
        if (plansForCatalog == null) {
            plansForCatalog = new ArrayList<>(availablePlansCache);
        }
        bindMembershipCatalog(plansForCatalog);
    }

    private final class ActiveMembershipsAdapter extends RecyclerView.Adapter<ActiveMembershipsAdapter.Holder> {
        private final List<MembershipPurchase> items = new ArrayList<>();

        void submit(List<MembershipPurchase> next) {
            items.clear();
            items.addAll(next);
            notifyDataSetChanged();
        }

        @NonNull @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_active_membership, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder h, int position) {
            MembershipPurchase p = items.get(position);
            DateTimeFormatter df = DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.getDefault());
            MembershipPlan pl = p.getPlan();
            String title = pl != null && pl.getName() != null && !pl.getName().isEmpty()
                    ? pl.getName()
                    : "Абонемент";
            h.tvTitle.setText(title);
            if (p.getStartDate() != null && p.getEndDate() != null) {
                h.tvPeriod.setVisibility(View.VISIBLE);
                h.tvPeriod.setText("С " + p.getStartDate().format(df) + " по " + p.getEndDate().format(df));
            } else {
                h.tvPeriod.setVisibility(View.GONE);
            }
            boolean frozen = "frozen".equalsIgnoreCase(p.getStatus());
            if (frozen) {
                h.tvDays.setText("Статус: заморожен");
            } else {
                h.tvDays.setText(p.getDaysLeft() + " " + getDaysLeftLabel(p.getDaysLeft()));
            }
            Integer monthly = pl != null ? pl.getGroupVisitsPerMonth() : null;
            Integer left = p.getGroupVisitsLeft();
            if (monthly != null && left != null) {
                h.tvGroup.setVisibility(View.VISIBLE);
                h.tvGroup.setText("Групповых в этом месяце: " + left + " из " + monthly);
            } else {
                h.tvGroup.setVisibility(View.GONE);
            }
            h.btnFreeze.setVisibility(View.VISIBLE);
            if (frozen) {
                h.btnFreeze.setText("Разморозить");
                h.btnFreeze.setEnabled(true);
                h.btnFreeze.setOnClickListener(v -> viewModel.unfreezeMembership(p.getId()));
            } else if (p.canFreeze()) {
                h.btnFreeze.setText("Заморозить");
                h.btnFreeze.setEnabled(true);
                h.btnFreeze.setOnClickListener(v -> showFreezeDaysDialog(p));
            } else {
                h.btnFreeze.setText("Лимит заморозки исчерпан");
                h.btnFreeze.setEnabled(false);
                h.btnFreeze.setOnClickListener(null);
            }
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class Holder extends RecyclerView.ViewHolder {
            final TextView tvTitle;
            final TextView tvPeriod;
            final TextView tvDays;
            final TextView tvGroup;
            final Button btnFreeze;

            Holder(@NonNull View itemView) {
                super(itemView);
                tvTitle = itemView.findViewById(R.id.tv_item_plan_title);
                tvPeriod = itemView.findViewById(R.id.tv_item_period);
                tvDays = itemView.findViewById(R.id.tv_item_days);
                tvGroup = itemView.findViewById(R.id.tv_item_group_visits);
                btnFreeze = itemView.findViewById(R.id.btn_item_freeze);
            }
        }
    }

    private void showFreezeDaysDialog(MembershipPurchase active) {
        if (active.getPlan() == null) {
            Toast.makeText(requireContext(), "План абонемента не найден", Toast.LENGTH_SHORT).show();
            return;
        }
        int remainingDays = active.getPlan().getFreezeDays() - active.getFreezeDaysUsed();
        if (remainingDays <= 0) {
            Toast.makeText(requireContext(), "Лимит дней заморозки исчерпан", Toast.LENGTH_SHORT).show();
            return;
        }

        CharSequence[] options = new CharSequence[remainingDays];
        for (int i = 1; i <= remainingDays; i++) {
            options[i - 1] = i + " дн.";
        }

        final int[] selected = {1};
        new AlertDialog.Builder(requireContext())
                .setTitle("Заморозить абонемент")
                .setSingleChoiceItems(options, 0, (dialog, which) -> selected[0] = which + 1)
                .setPositiveButton("Подтвердить", (dialog, which) ->
                        viewModel.freezeMembership(active.getId(), selected[0]))
                .setNegativeButton("Отмена", null)
                .show();
    }

    private String getDaysLeftLabel(long days) {
        if (days == 1) return "день осталось";
        if (days >= 2 && days <= 4) return "дня осталось";
        return "дней осталось";
    }

    private void bindMembershipCatalog(List<MembershipPlan> plans) {
        availablePlansCache.clear();
        if (plans != null) availablePlansCache.addAll(plans);
        List<MembershipPlan> safe = availablePlansCache;

        boolean hasActive = !activePurchasesCache.isEmpty();

        List<MembershipPlan> clubPlans = new ArrayList<>();
        for (MembershipPlan p : safe) {
            if (p == null || !p.isActive()) continue;
            String k = p.getPlanKind();
            if (k != null) {
                String kl = k.trim().toLowerCase(Locale.ROOT);
                if ("club".equals(kl) || "gym_only".equals(kl)) {
                    clubPlans.add(p);
                }
            }
        }
        if (clubPlans.isEmpty()) {
            for (MembershipPlan p : safe) {
                if (p == null || !p.isActive()) continue;
                int d = p.getDurationDays();
                if (d == 30 || d == 180 || d == 365 || d == 450) {
                    clubPlans.add(p);
                }
            }
        }
        if (clubPlans.isEmpty()) {
            for (MembershipPlan p : safe) {
                if (p != null && p.isActive()) {
                    clubPlans.add(p);
                }
            }
        }
        Collections.sort(clubPlans, Comparator.comparingInt(MembershipPlan::getDurationDays));

        ConcatAdapter concat = new ConcatAdapter();
        if (!clubPlans.isEmpty()) {
            concat.addAdapter(new OneLineHeaderAdapter(getString(R.string.catalog_section_club_cards)));
            concat.addAdapter(new ClubPlanRowsAdapter(clubPlans, plan -> {
                Intent i = new Intent(requireContext(), MembershipPlanDetailActivity.class);
                i.putExtra(MembershipPlanDetailActivity.EXTRA_PLAN, plan);
                i.putExtra(MembershipPlanDetailActivity.EXTRA_CAN_PURCHASE, !hasActive);
                startActivity(i);
            }));
        }
        recyclerViewPlans.setAdapter(concat);
        recyclerViewPlans.setVisibility(clubPlans.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private interface OnClubPlanAction {
        void onChoose(MembershipPlan plan);
    }

    private static class OneLineHeaderAdapter extends RecyclerView.Adapter<OneLineHeaderAdapter.Holder> {
        private final String title;

        OneLineHeaderAdapter(String title) {
            this.title = title;
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_catalog_section_header, parent, false);
            return new Holder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            holder.tv.setText(title);
        }

        @Override
        public int getItemCount() {
            return 1;
        }

        static class Holder extends RecyclerView.ViewHolder {
            final TextView tv;

            Holder(@NonNull View itemView) {
                super(itemView);
                tv = itemView.findViewById(R.id.tv_catalog_section_title);
            }
        }
    }

    private static class ClubPlanRowsAdapter extends RecyclerView.Adapter<ClubPlanRowsAdapter.Holder> {
        private final List<MembershipPlan> items;
        private final OnClubPlanAction action;

        ClubPlanRowsAdapter(List<MembershipPlan> items, OnClubPlanAction action) {
            this.items = items != null ? items : new ArrayList<>();
            this.action = action;
        }

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_membership_plan, parent, false);
            return new Holder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull Holder holder, int position) {
            holder.bind(items.get(position), action);
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        static class Holder extends RecyclerView.ViewHolder {
            final TextView tvName;
            final TextView tvDescription;
            final TextView tvPrice;
            final Button btnBuy;

            Holder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tv_plan_name);
                tvDescription = itemView.findViewById(R.id.tv_plan_description);
                tvPrice = itemView.findViewById(R.id.tv_plan_price);
                btnBuy = itemView.findViewById(R.id.btn_buy_plan);
            }

            void bind(MembershipPlan plan, OnClubPlanAction action) {
                String title = plan.getName() != null && !plan.getName().isEmpty() ? plan.getName() : "Клубная карта";
                tvName.setText(title);
                String desc = plan.getDescription() != null ? plan.getDescription() : "";
                int days = plan.getDurationDays();
                String dur = "Срок: " + days + " дн.";
                tvDescription.setText(desc.isEmpty() ? dur : desc + "\n\n" + dur);

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("ru", "RU"));
                format.setCurrency(java.util.Currency.getInstance("RUB"));
                if (plan.getPrice() != null) {
                    tvPrice.setText(format.format(plan.getPrice()));
                } else {
                    tvPrice.setText("");
                }
                btnBuy.setText(itemView.getContext().getString(R.string.catalog_plan_more));
                View.OnClickListener l = v -> {
                    if (action != null) action.onChoose(plan);
                };
                itemView.setOnClickListener(l);
                btnBuy.setOnClickListener(l);
            }
        }
    }
}
