package com.example.myapplication.your.util;

import org.json.JSONObject;


public final class AppUserDisplayName {
    private AppUserDisplayName() {}

    public static String fromAppUserJson(JSONObject row) {
        if (row == null) return "Клиент";
        String last = nz(row.optString("last_name", null));
        String first = nz(row.optString("name", null));
        if (!last.isEmpty() && !first.isEmpty()) return last + " " + first;
        if (!first.isEmpty()) return first;
        if (!last.isEmpty()) return last;
        return "Клиент";
    }

    private static String nz(String s) {
        if (s == null) return "";
        String t = s.trim();
        return "null".equalsIgnoreCase(t) ? "" : t;
    }
}
