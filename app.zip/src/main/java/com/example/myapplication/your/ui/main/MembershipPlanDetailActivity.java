package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.your.model.MembershipPlan;
import com.google.android.material.button.MaterialButton;

import java.text.NumberFormat;
import java.util.Locale;

public class MembershipPlanDetailActivity extends AppCompatActivity {

    public static final String EXTRA_PLAN = "extra_membership_plan";
    public static final String EXTRA_CAN_PURCHASE = "extra_can_purchase";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_membership_plan_detail);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.membership_plan_detail_title);
        }

        MembershipPlan plan = (MembershipPlan) getIntent().getSerializableExtra(EXTRA_PLAN);
        if (plan == null) {
            finish();
            return;
        }

        TextView tvTitle = findViewById(R.id.tv_plan_detail_title);
        TextView tvPrice = findViewById(R.id.tv_plan_detail_price);
        TextView tvMeta = findViewById(R.id.tv_plan_detail_meta);
        TextView tvDesc = findViewById(R.id.tv_plan_detail_desc);
        MaterialButton btnBuy = findViewById(R.id.btn_plan_detail_buy);
        boolean canPurchase = getIntent().getBooleanExtra(EXTRA_CAN_PURCHASE, true);
        btnBuy.setEnabled(canPurchase);
        btnBuy.setAlpha(canPurchase ? 1f : 0.55f);
        btnBuy.setOnClickListener(v -> {
            if (!canPurchase) {
                Toast.makeText(this, R.string.membership_blocked_active, Toast.LENGTH_LONG).show();
                return;
            }
            Intent i = new Intent(this, PaymentActivity.class);
            i.putExtra(PaymentActivity.EXTRA_PLAN_ID, plan.getId());
            startActivity(i);
        });

        tvTitle.setText(plan.getName() != null ? plan.getName() : getString(R.string.membership_plan_default_name));

        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("ru", "RU"));
        format.setCurrency(java.util.Currency.getInstance("RUB"));
        if (plan.getPrice() != null) {
            tvPrice.setText(format.format(plan.getPrice()));
        } else {
            tvPrice.setText("");
        }

        int days = plan.getDurationDays();
        String dur;
        if (days >= 400 && days <= 460) dur = "Срок: ~15 месяцев (" + days + " дн.)";
        else if (days <= 40) dur = "Срок: 1 месяц (" + days + " дн.)";
        else if (days <= 200) dur = "Срок: 6 месяцев (" + days + " дн.)";
        else dur = "Срок: 12 месяцев (" + days + " дн.)";

        String freeze = "Заморозка: " + plan.getFreezeDays() + " дн.";
        String visits = plan.getVisitLimit() != null
                ? "Посещения: лимит " + plan.getVisitLimit()
                : "Посещения зала: безлимит";

        tvMeta.setText(dur + "\n" + freeze + "\n" + visits);

        String desc = plan.getDescription();
        tvDesc.setText(desc != null && !desc.trim().isEmpty() ? desc : getString(R.string.membership_plan_no_desc));
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
