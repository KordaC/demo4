package com.example.myapplication.your.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.example.myapplication.your.model.User;
import com.example.myapplication.your.util.JsonResponseUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
// Репозиторий для управления избранным (тренеры и тренировки)
// Поддерживает локальное хранение (SharedPreferences) и синхронизацию с сервером
public class FavoritesRepository {
    private static final String TAG = "FavoritesRepository";
    private static final String PREFS = "favorites_prefs";
    private static final String KEY_TRAINERS_PREFIX = "trainer_ids_";
    private static final String KEY_SESSIONS_PREFIX = "session_ids_";
    private static final String KEY_CLOUD_MIGRATED_PREFIX = "fav_cloud_migrated_";

    private static final long MIN_SYNC_INTERVAL_MS = 12_000L;
    private static long lastSyncAttemptMs;

    private static FavoritesRepository instance;
    private final Context appContext;
    private final String supabaseUrl;
    private final String supabaseKey;

    private FavoritesRepository(Context context) {
        this.appContext = context.getApplicationContext();
        supabaseUrl = SupabaseClientProvider.getSupabaseUrl();
        supabaseKey = SupabaseClientProvider.getSupabaseAnonKey();
    }

    public static synchronized FavoritesRepository getInstance(Context context) {
        if (instance == null) {
            instance = new FavoritesRepository(context);
        }
        return instance;
    }

    private SharedPreferences prefs() {
        return appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private String userSuffix() {
        User u = SharedPrefManager.getInstance(appContext).getCurrentUser();
        String id = u != null ? u.getId() : null;
        if (id == null || id.trim().isEmpty()) return "anon";
        return id.trim();
    }
    // Проверяет, есть ли JWT-токен у пользователя
    private boolean hasUserJwt() {
        String t = SharedPrefManager.getInstance(appContext).getAccessToken();
        return t != null && !t.trim().isEmpty();
    }
    // Устанавливает заголовки авторизации для HTTP-запросов
    private void setAuthHeaders(HttpURLConnection conn) {
        String token = SharedPrefManager.getInstance(appContext).getAccessToken();
        String bearer = (token != null && !token.trim().isEmpty()) ? token.trim() : supabaseKey;
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + bearer);
        conn.setRequestProperty("Content-Type", "application/json");
    }
    // Сохраняет список избранных тренеров локально
    private void replaceLocalTrainers(Set<String> ids) {
        Set<String> copy = new HashSet<>(ids != null ? ids : Collections.emptySet());
        prefs().edit().putStringSet(KEY_TRAINERS_PREFIX + userSuffix(), copy).apply();
    }
    // Сохраняет список избранных тренировок локально
    private void replaceLocalSessions(Set<String> ids) {
        Set<String> copy = new HashSet<>(ids != null ? ids : Collections.emptySet());
        prefs().edit().putStringSet(KEY_SESSIONS_PREFIX + userSuffix(), copy).apply();
    }
    // Проверяет, были ли локальные избранные перенесены в облако
    private boolean isCloudMigratedForCurrentUser() {
        return prefs().getBoolean(KEY_CLOUD_MIGRATED_PREFIX + userSuffix(), false);
    }
    // Синхронизирует избранное с сервером (один раз мигрирует локальные данные)
    private void setCloudMigratedForCurrentUser(boolean v) {
        prefs().edit().putBoolean(KEY_CLOUD_MIGRATED_PREFIX + userSuffix(), v).apply();
    }


    public void syncFromServerIfLoggedIn(boolean force) {
        if (!hasUserJwt()) return;
        User u = SharedPrefManager.getInstance(appContext).getCurrentUser();
        if (u == null || u.getId() == null || u.getId().trim().isEmpty()) return;
        final String uid = u.getId().trim();
        long now = System.currentTimeMillis();
        if (!force && now - lastSyncAttemptMs < MIN_SYNC_INTERVAL_MS) return;
        lastSyncAttemptMs = now;
        try {
            List<String> remoteT = fetchTrainerFavoriteIds(uid);
            List<String> remoteS = fetchSessionFavoriteIds(uid);
            if (remoteT.isEmpty() && remoteS.isEmpty() && !isCloudMigratedForCurrentUser()) {
                List<String> localT = new ArrayList<>(getFavoriteTrainerIds());
                List<String> localS = new ArrayList<>(getFavoriteSessionIds());
                if (!localT.isEmpty() || !localS.isEmpty()) {
                    for (String tid : localT) {
                        if (tid == null || tid.trim().isEmpty()) continue;
                        try {
                            insertTrainerFavoriteRemote(uid, tid.trim());
                        } catch (Exception e) {
                            Log.w(TAG, "migrate trainer " + tid, e);
                        }
                    }
                    for (String sid : localS) {
                        if (sid == null || sid.trim().isEmpty()) continue;
                        try {
                            insertSessionFavoriteRemote(uid, sid.trim());
                        } catch (Exception e) {
                            Log.w(TAG, "migrate session " + sid, e);
                        }
                    }
                    remoteT = fetchTrainerFavoriteIds(uid);
                    remoteS = fetchSessionFavoriteIds(uid);
                }
                setCloudMigratedForCurrentUser(true);
            }
            // Обновляем локальные данные из облака
            replaceLocalTrainers(new HashSet<>(remoteT));
            replaceLocalSessions(new HashSet<>(remoteS));
        } catch (Exception e) {
            Log.w(TAG, "syncFromServerIfLoggedIn", e);
        }
    }

    public void syncFromServerIfLoggedIn() {
        syncFromServerIfLoggedIn(false);
    }
    // Запрашивает с сервера ID избранных тренеров
    private List<String> fetchTrainerFavoriteIds(String userId) throws Exception {
        String url = supabaseUrl + "/rest/v1/favorite_trainer?user_id=eq." + userId
                + "&select=trainer_id";
        String json = makeGetAuthed(url);
        return parseIdColumn(json, "trainer_id");
    }
    // Запрашивает с сервера ID избранных тренировок
    private List<String> fetchSessionFavoriteIds(String userId) throws Exception {
        String url = supabaseUrl + "/rest/v1/favorite_session?user_id=eq." + userId
                + "&select=session_id";
        String json = makeGetAuthed(url);
        return parseIdColumn(json, "session_id");
    }
    // Парсит JSON-ответ и извлекает ID из указанного поля
    private static List<String> parseIdColumn(String json, String key) throws Exception {
        List<String> out = new ArrayList<>();
        if (json == null || json.trim().isEmpty() || "[]".equals(json.trim())) return out;
        JSONArray arr = JsonResponseUtil.requireArray(json);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            String id = o.optString(key, null);
            if (id != null && !id.trim().isEmpty()) out.add(id.trim());
        }
        return out;
    }
    // Выполняет GET-запрос с авторизацией
    private String makeGetAuthed(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        setAuthHeaders(conn);
        int code = conn.getResponseCode();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                code >= 400 ? conn.getErrorStream() : conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }
    private void insertTrainerFavoriteRemote(String userId, String trainerId) throws Exception {
        JSONObject body = new JSONObject();
        body.put("user_id", userId);
        body.put("trainer_id", trainerId);
        postJson(supabaseUrl + "/rest/v1/favorite_trainer", body.toString());
    }
    private void insertSessionFavoriteRemote(String userId, String sessionId) throws Exception {
        JSONObject body = new JSONObject();
        body.put("user_id", userId);
        body.put("session_id", sessionId);
        postJson(supabaseUrl + "/rest/v1/favorite_session", body.toString());
    }
    private void deleteTrainerFavoriteRemote(String userId, String trainerId) throws Exception {
        String url = supabaseUrl + "/rest/v1/favorite_trainer?user_id=eq." + userId
                + "&trainer_id=eq." + trainerId;
        deleteUrl(url);
    }
    private void deleteSessionFavoriteRemote(String userId, String sessionId) throws Exception {
        String url = supabaseUrl + "/rest/v1/favorite_session?user_id=eq." + userId
                + "&session_id=eq." + sessionId;
        deleteUrl(url);
    }
    // POST-запрос к Supabase
    private void postJson(String urlString, String json) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        setAuthHeaders(conn);
        conn.setRequestProperty("Prefer", "return=minimal");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(json.getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        if (code == 409) return;
        if (code >= 400) {
            String err = readError(conn);
            throw new Exception("HTTP " + code + ": " + err);
        }
    }
    // DELETE-запрос к Supabase
    private void deleteUrl(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("DELETE");
        setAuthHeaders(conn);
        int code = conn.getResponseCode();
        if (code >= 400 && code != 404) {
            String err = readError(conn);
            throw new Exception("HTTP " + code + ": " + err);
        }
    }

    private static String readError(HttpURLConnection conn) {
        try {
            if (conn.getErrorStream() == null) return "";
            BufferedReader er = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = er.readLine()) != null) sb.append(line);
            er.close();
            return sb.toString();
        } catch (Exception e) {
            return e.getMessage() != null ? e.getMessage() : "";
        }
    }
    // Проверяет, находится ли тренер в избранном (из локального кэша)
    public boolean isTrainerFavorite(String trainerId) {
        if (trainerId == null) return false;
        Set<String> s = prefs().getStringSet(KEY_TRAINERS_PREFIX + userSuffix(), Collections.emptySet());
        return s.contains(trainerId);
    }
    // Устанавливает статус избранного для тренера
    public void setTrainerFavorite(String trainerId, boolean favorite) {
        if (trainerId == null) return;
        if (!hasUserJwt()) {
            setTrainerFavoriteLocalOnly(trainerId, favorite);
            return;
        }
        User u = SharedPrefManager.getInstance(appContext).getCurrentUser();
        if (u == null || u.getId() == null || u.getId().trim().isEmpty()) {
            setTrainerFavoriteLocalOnly(trainerId, favorite);
            return;
        }
        final String uid = u.getId().trim();
        final String tid = trainerId.trim();
        boolean wasBefore = isTrainerFavorite(tid);
        setTrainerFavoriteLocalOnly(tid, favorite);
        new Thread(() -> {
            try {
                if (favorite) insertTrainerFavoriteRemote(uid, tid);
                else deleteTrainerFavoriteRemote(uid, tid);
            } catch (Exception e) {
                Log.e(TAG, "setTrainerFavorite remote", e);
                setTrainerFavoriteLocalOnly(tid, wasBefore);
            }
        }).start();
    }

    private void setTrainerFavoriteLocalOnly(String trainerId, boolean favorite) {
        Set<String> copy = new HashSet<>(prefs().getStringSet(KEY_TRAINERS_PREFIX + userSuffix(), Collections.emptySet()));
        if (favorite) copy.add(trainerId);
        else copy.remove(trainerId);
        prefs().edit().putStringSet(KEY_TRAINERS_PREFIX + userSuffix(), copy).apply();
    }
    // Переключает статус избранного для тренера
    public void toggleTrainerFavorite(String trainerId) {
        setTrainerFavorite(trainerId, !isTrainerFavorite(trainerId));
    }
    // Проверяет, находится ли тренировка в избранном
    public boolean isSessionFavorite(String sessionId) {
        if (sessionId == null) return false;
        Set<String> s = prefs().getStringSet(KEY_SESSIONS_PREFIX + userSuffix(), Collections.emptySet());
        return s.contains(sessionId);
    }
    // Устанавливает статус избранного для тренировки
    public void setSessionFavorite(String sessionId, boolean favorite) {
        if (sessionId == null) return;
        if (!hasUserJwt()) {
            setSessionFavoriteLocalOnly(sessionId, favorite);
            return;
        }
        User u = SharedPrefManager.getInstance(appContext).getCurrentUser();
        if (u == null || u.getId() == null || u.getId().trim().isEmpty()) {
            setSessionFavoriteLocalOnly(sessionId, favorite);
            return;
        }
        final String uid = u.getId().trim();
        final String sid = sessionId.trim();
        boolean wasBefore = isSessionFavorite(sid);
        setSessionFavoriteLocalOnly(sid, favorite);
        new Thread(() -> {
            try {
                if (favorite) insertSessionFavoriteRemote(uid, sid);
                else deleteSessionFavoriteRemote(uid, sid);
            } catch (Exception e) {
                Log.e(TAG, "setSessionFavorite remote", e);
                setSessionFavoriteLocalOnly(sid, wasBefore);
            }
        }).start();
    }
    // Локальное изменение статуса для тренировки
    private void setSessionFavoriteLocalOnly(String sessionId, boolean favorite) {
        Set<String> copy = new HashSet<>(prefs().getStringSet(KEY_SESSIONS_PREFIX + userSuffix(), Collections.emptySet()));
        if (favorite) copy.add(sessionId);
        else copy.remove(sessionId);
        prefs().edit().putStringSet(KEY_SESSIONS_PREFIX + userSuffix(), copy).apply();
    }
    // Переключает статус избранного для тренировки
    public void toggleSessionFavorite(String sessionId) {
        setSessionFavorite(sessionId, !isSessionFavorite(sessionId));
    }
    // Возвращает список ID избранных тренеров
    public List<String> getFavoriteTrainerIds() {
        Set<String> s = prefs().getStringSet(KEY_TRAINERS_PREFIX + userSuffix(), Collections.emptySet());
        return new ArrayList<>(s);
    }
    // Возвращает список ID избранных тренировок
    public List<String> getFavoriteSessionIds() {
        Set<String> s = prefs().getStringSet(KEY_SESSIONS_PREFIX + userSuffix(), Collections.emptySet());
        return new ArrayList<>(s);
    }
}
