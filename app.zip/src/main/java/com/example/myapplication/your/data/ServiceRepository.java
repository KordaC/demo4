package com.example.myapplication.your.data;

import android.content.Context;
import android.util.Log;

import com.example.myapplication.your.model.ServiceItem;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ServiceRepository {
    private static final String TAG = "ServiceRepository";
    private static ServiceRepository instance;
    private String supabaseUrl;
    private String supabaseKey;

    private ServiceRepository(Context context) {
        supabaseUrl = SupabaseClientProvider.getSupabaseUrl();
        supabaseKey = SupabaseClientProvider.getSupabaseAnonKey();
    }

    public static synchronized ServiceRepository getInstance(Context context) {
        if (instance == null) {
            instance = new ServiceRepository(context);
        }
        return instance;
    }


    public List<ServiceItem> getAllServices() {
        try {
            String url = supabaseUrl + "/rest/v1/service_item?is_active=eq.true";
            String jsonResponse = makeGetRequest(url);
            
            List<ServiceItem> services = new ArrayList<>();
            JSONArray jsonArray = new JSONArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                services.add(mapToService(obj));
            }
            return services;
        } catch (Exception e) {
            Log.e(TAG, "Error fetching services", e);
            return new ArrayList<>();
        }
    }


    public List<ServiceItem> getServicesByCategory(String category) {
        try {
            String url = supabaseUrl + "/rest/v1/service_item?is_active=eq.true&category=eq." + category;
            String jsonResponse = makeGetRequest(url);
            
            List<ServiceItem> services = new ArrayList<>();
            JSONArray jsonArray = new JSONArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                services.add(mapToService(obj));
            }
            return services;
        } catch (Exception e) {
            Log.e(TAG, "Error fetching services by category", e);
            return new ArrayList<>();
        }
    }


    public boolean purchaseService(String userId, String serviceId, String note) {
        try {
            JSONObject data = new JSONObject();
            data.put("user_id", userId);
            data.put("service_id", serviceId);
            data.put("status", "new");
            if (note != null && !note.isEmpty()) {
                data.put("note", note);
            }

            String url = supabaseUrl + "/rest/v1/service_purchase";
            makePostRequest(url, data.toString());
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error purchasing service", e);
            return false;
        }
    }


    public List<ServiceItem> getUserPurchases(String userId) {
        try {
            String url = supabaseUrl + "/rest/v1/service_purchase?user_id=eq." + userId + "&select=*,service_item(*)";
            String jsonResponse = makeGetRequest(url);
            
            List<ServiceItem> services = new ArrayList<>();
            JSONArray jsonArray = new JSONArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                if (obj.has("service_item") && !obj.isNull("service_item")) {
                    JSONObject serviceObj = obj.getJSONObject("service_item");
                    services.add(mapToService(serviceObj));
                }
            }
            return services;
        } catch (Exception e) {
            Log.e(TAG, "Error fetching user purchases", e);
            return new ArrayList<>();
        }
    }

    private ServiceItem mapToService(JSONObject json) {
        ServiceItem service = new ServiceItem();
        service.setId(json.optString("id"));
        service.setName(json.optString("name"));
        service.setDescription(json.optString("description"));
        service.setCategory(json.optString("category"));
        
        if (!json.isNull("price")) {
            try {
                double price = json.optDouble("price", 0);
                service.setPrice(BigDecimal.valueOf(price));
            } catch (Exception e) {
                Log.e(TAG, "Error parsing price", e);
            }
        }
        
        service.setIsActive(json.optBoolean("is_active", true));
        return service;
    }

    private String makeGetRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        return response.toString();
    }

    private void makePostRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        conn.getResponseCode();
    }
}

