package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.myapplication.R;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.model.User;
import com.example.myapplication.your.ui.auth.AuthActivity;
import com.example.myapplication.your.viewmodel.ProfileViewModel;
import com.example.myapplication.your.ui.profile.EditProfileActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class ProfileFragment extends Fragment {
    private ProfileViewModel viewModel;
    private TextView tvGreeting;
    private TextView tvName;
    private TextView tvEmail;
    private TextView tvPhone;
    private Button btnLogout;
    private ImageView ivAvatar;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(ProfileViewModel.class);

        tvGreeting = view.findViewById(R.id.tv_profile_greeting);
        tvName = view.findViewById(R.id.tv_name);
        tvEmail = view.findViewById(R.id.tv_email);
        tvPhone = view.findViewById(R.id.tv_phone);
        btnLogout = view.findViewById(R.id.btn_logout);
        ivAvatar = view.findViewById(R.id.iv_profile_avatar);
        View cardHeader = view.findViewById(R.id.card_profile_header);
        View btnFavorites = view.findViewById(R.id.btn_favorites);
        View btnBookings = view.findViewById(R.id.btn_my_bookings);
        User cur = SharedPrefManager.getInstance(requireContext()).getCurrentUser();
        boolean isTrainer = cur != null && cur.isTrainer();
        boolean isAdmin = cur != null && cur.isAdmin();
        if (isTrainer || isAdmin) {
            if (btnBookings != null) btnBookings.setVisibility(View.GONE);
            if (btnFavorites != null) btnFavorites.setVisibility(View.GONE);
        } else {
            if (btnBookings != null) {
                btnBookings.setVisibility(View.VISIBLE);
                btnBookings.setOnClickListener(v -> getParentFragmentManager().beginTransaction()
                        .replace(R.id.main_container, new MyBookingsFragment())
                        .addToBackStack(null)
                        .commit());
            }
            if (btnFavorites != null) {
                btnFavorites.setVisibility(View.VISIBLE);
                btnFavorites.setOnClickListener(v -> startActivity(new Intent(requireContext(), FavoritesActivity.class)));
            }
        }

        btnLogout.setOnClickListener(v -> {
            viewModel.logout();
            Intent intent = new Intent(requireContext(), AuthActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            requireActivity().finish();
        });
        if (cardHeader != null) {
            cardHeader.setOnClickListener(v -> startActivity(new Intent(requireContext(), EditProfileActivity.class)));
        }
        observeViewModel();
    }

    @Override
    public void onResume() {
        super.onResume();
        viewModel.refreshUser();
    }

    private void observeViewModel() {
        viewModel.getCurrentUser().observe(getViewLifecycleOwner(), user -> {
            if (user != null) {
                String shortName = user.getShortDisplayName();
                if (shortName == null || shortName.trim().isEmpty()) {
                    if (user.getEmail() != null) shortName = user.getEmail();
                    else shortName = "Гость";
                }
                if (tvGreeting != null) {
                    if (user.isAdmin()) {
                        tvGreeting.setText("Администратор");
                    } else {
                        tvGreeting.setText(user.isTrainer() ? "Тренер" : "Клиент клуба");
                    }
                }
                if (tvName != null) tvName.setText(shortName);
                if (tvEmail != null) tvEmail.setText(user.getEmail() != null ? user.getEmail() : "Не указано");
                if (tvPhone != null) tvPhone.setText(user.getPhone() != null && !user.getPhone().isEmpty() ? user.getPhone() : "Не указан");
                if (ivAvatar != null) {
                    if (user.getAvatarUrl() != null && !user.getAvatarUrl().isEmpty()) {
                        ivAvatar.setPadding(0, 0, 0, 0);
                        ivAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
                        ivAvatar.setImageTintList(null);
                        Glide.with(requireContext())
                                .load(user.getAvatarUrl())
                                .apply(RequestOptions.centerCropTransform())
                                .into(ivAvatar);
                    } else {
                        applyProfileAvatarPlaceholder(ivAvatar);
                    }
                }
            } else {
                if (tvGreeting != null) tvGreeting.setText("");
                if (tvName != null) tvName.setText("");
                if (tvEmail != null) tvEmail.setText("Не авторизован");
                if (tvPhone != null) tvPhone.setText("");
                if (ivAvatar != null) {
                    applyProfileAvatarPlaceholder(ivAvatar);
                }
            }
        });
    }

    private void applyProfileAvatarPlaceholder(ImageView iv) {
        int pad = (int) (12 * getResources().getDisplayMetrics().density + 0.5f);
        iv.setPadding(pad, pad, pad, pad);
        iv.setScaleType(ImageView.ScaleType.CENTER);
        iv.setImageResource(R.drawable.ic_user);
        iv.setImageTintList(android.content.res.ColorStateList.valueOf(
                ContextCompat.getColor(requireContext(), R.color.white)));
    }
}
