package com.example.myapplication.your.ui.trainer;

import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.R;
import com.example.myapplication.your.data.BookingRepository;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TrainerBookingFragment extends Fragment {

    private CalendarView calendarView;
    private RecyclerView recyclerTimes;

    private BookingRepository repository;

    private String trainerId = "trainer1";
    private String selectedDate;

    public TrainerBookingFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_trainer_booking, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        calendarView = view.findViewById(R.id.calendarView);
        recyclerTimes = view.findViewById(R.id.recyclerTimes);

        repository = new BookingRepository(requireContext());

        recyclerTimes.setLayoutManager(new GridLayoutManager(getContext(),3));

        selectedDate = getDate(calendarView.getDate());

        loadTimes();

        calendarView.setOnDateChangeListener((view1, year, month, dayOfMonth) -> {

            selectedDate = dayOfMonth+"-"+(month+1)+"-"+year;

            loadTimes();

        });
    }

    private void loadTimes(){

        List<String> times = repository.getTimeSlots();

        List<String> busy = repository.getBusyTimes(trainerId, selectedDate);

        TimeAdapter adapter = new TimeAdapter(times, busy, time -> {

            repository.addBooking(
                    trainerId,
                    "user1",
                    selectedDate,
                    time
            );

            Toast.makeText(getContext(),"Вы записались на "+time,Toast.LENGTH_SHORT).show();

            loadTimes();

        });

        recyclerTimes.setAdapter(adapter);
    }

    private String getDate(long millis){

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

        return sdf.format(new Date(millis));
    }
}