package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.PersonalTrainingRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.model.User;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TrainerBookingViewModel extends AndroidViewModel {
    private final PersonalTrainingRepository repository;
    private final SharedPrefManager prefManager;
    private final MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private final MutableLiveData<List<String>> timeSlots = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<List<String>> busySlots = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<String> error = new MutableLiveData<>();
    private final MutableLiveData<Boolean> bookingSuccess = new MutableLiveData<>();
    private final MutableLiveData<Boolean> rescheduleSuccess = new MutableLiveData<>();

    public TrainerBookingViewModel(@NonNull Application application) {
        super(application);
        repository = PersonalTrainingRepository.getInstance(application);
        prefManager = SharedPrefManager.getInstance(application);
        timeSlots.setValue(repository.getTimeSlots());
    }

    public LiveData<Boolean> getLoading() { return loading; }
    public LiveData<List<String>> getTimeSlots() { return timeSlots; }
    public LiveData<List<String>> getBusySlots() { return busySlots; }
    public LiveData<String> getError() { return error; }
    public LiveData<Boolean> getBookingSuccess() { return bookingSuccess; }
    public LiveData<Boolean> getRescheduleSuccess() { return rescheduleSuccess; }
    // Загрузка занятых слотов для выбранной даты
    public void loadBusySlots(String trainerId, LocalDate date) {
        loading.postValue(true);
        new Thread(() -> {
            try {
                List<String> busy = repository.getBusySlots(trainerId, date);
                busySlots.postValue(busy);
            } catch (Exception e) {
                error.postValue("Ошибка загрузки: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }
    // Запись на персональную тренировку
    public void bookSlot(String trainerId, LocalDate date, String timeSlot) {
        User user = prefManager.getCurrentUser();
        if (user == null || user.getId() == null) {
            error.postValue("Войдите в аккаунт");
            return;
        }
        loading.setValue(true);
        error.postValue(null);
        new Thread(() -> {
            try {
                String err = repository.bookSlot(user.getId(), trainerId, date, timeSlot);
                if (err == null) {
                    bookingSuccess.postValue(true);
                    loadBusySlots(trainerId, date);
                } else {
                    error.postValue(err);
                }
            } catch (Exception e) {
                error.postValue("Ошибка: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }
    public void rescheduleBooking(String bookingId, String trainerId, LocalDate date, String timeSlot) {
        User user = prefManager.getCurrentUser();
        if (user == null || user.getId() == null) {
            error.postValue("Войдите в аккаунт");
            return;
        }
        loading.setValue(true);
        error.postValue(null);
        new Thread(() -> {
            try {
                String err = repository.reschedulePersonalBooking(user.getId(), bookingId, trainerId, date, timeSlot);
                if (err == null) {
                    rescheduleSuccess.postValue(true);
                    loadBusySlots(trainerId, date);
                } else {
                    error.postValue(err);
                }
            } catch (Exception e) {
                error.postValue("Ошибка: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void clearError() { error.setValue(null); }
    public void clearBookingSuccess() { bookingSuccess.setValue(false); }
    public void clearRescheduleSuccess() { rescheduleSuccess.setValue(false); }
}
