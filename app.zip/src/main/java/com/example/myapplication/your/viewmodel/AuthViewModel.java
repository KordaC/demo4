package com.example.myapplication.your.viewmodel;



import android.app.Application;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.R;
import com.example.myapplication.your.data.AuthRepository;
import com.example.myapplication.your.model.User;

public class AuthViewModel extends AndroidViewModel {
    private AuthRepository repository;

    private MutableLiveData<Boolean> loading = new MutableLiveData<>();
    private MutableLiveData<User> userLiveData = new MutableLiveData<>();
    private MutableLiveData<String> error = new MutableLiveData<>();
    private MutableLiveData<String> pendingConfirmEmail = new MutableLiveData<>();
    // Черновик формы регистрации
    public static class RegisterDraft {
        public String name;
        public String surname;
        public String patronymic;
        public String birthDateIso;
        public String email;
        public String phone;
        public String password;
        public String passwordConfirm;
    }

    private RegisterDraft registerDraft;

    public void setRegisterDraft(RegisterDraft d) {
        this.registerDraft = d;
    }

    @Nullable
    public RegisterDraft getRegisterDraft() {
        return registerDraft;
    }

    public void clearRegisterDraft() {
        registerDraft = null;
    }

    public AuthViewModel(@NonNull Application application) {
        super(application);
        repository = AuthRepository.getInstance(application);
    }

    public LiveData<Boolean> getLoading(){ return loading; }
    public LiveData<User> getUser(){ return userLiveData; }
    public LiveData<String> getError(){ return error; }
    public LiveData<String> getPendingConfirmEmail() { return pendingConfirmEmail; }

    public void login(String email, String password) {
        userLiveData.setValue(null);
        loading.setValue(true);
        new Thread(() -> {
            try {
                AuthRepository.AuthResult res = repository.login(email.trim(), password);
                if (res != null && res.isSuccess()) {
                    userLiveData.postValue(res.user);
                } else {
                    error.postValue(res != null && res.error != null
                            ? res.error
                            : getApplication().getString(R.string.invalid_credentials));
                }
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void register(String name, String surname, String patronymic, String birthDateIso, String email, String phone, String password) {
        userLiveData.setValue(null);
        loading.setValue(true);
        new Thread(() -> {
            try {
                AuthRepository.AuthResult res = repository.register(
                        name.trim(),
                        surname != null ? surname.trim() : "",
                        patronymic != null ? patronymic.trim() : "",
                        birthDateIso != null ? birthDateIso.trim() : "",
                        email.trim(), phone.trim(), password);
                if (res != null && res.isSuccess()) {
                    userLiveData.postValue(res.user);
                } else if (res != null && res.emailConfirmationPending) {
                    pendingConfirmEmail.postValue(
                            res.confirmationEmail != null ? res.confirmationEmail : "");
                } else {
                    error.postValue(res != null && res.error != null
                            ? res.error
                            : getApplication().getString(R.string.user_exists));
                }
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void clearPendingConfirmEmail() {
        pendingConfirmEmail.setValue(null);
    }

    public void verifySignupEmailOtp(String email, String otpCode) {
        userLiveData.setValue(null);
        loading.setValue(true);
        new Thread(() -> {
            try {
                AuthRepository.AuthResult res = repository.verifySignupEmailOtp(email, otpCode);
                if (res != null && res.isSuccess()) {
                    userLiveData.postValue(res.user);
                } else {
                    error.postValue(res != null && res.error != null
                            ? res.error
                            : getApplication().getString(R.string.auth_otp_invalid));
                }
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void clearError(){ error.setValue(null); }
}
