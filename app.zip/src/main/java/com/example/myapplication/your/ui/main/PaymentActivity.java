package com.example.myapplication.your.ui.main;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.myapplication.R;
import com.example.myapplication.your.data.MembershipRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.util.ValidationUtils;
import com.example.myapplication.your.model.User;
import com.example.myapplication.your.viewmodel.MembershipViewModel;

public class PaymentActivity extends AppCompatActivity {

    public static final String EXTRA_PLAN_ID = "plan_id";
    public static final String EXTRA_GROUP_TOPUP = "extra_group_topup";
    public static final String EXTRA_GROUP_TOPUP_COUNT = "extra_group_topup_count";
    public static final String EXTRA_PAY_SINGLE_GROUP_SESSION_ID = "extra_pay_single_group_session_id";
    public static final String EXTRA_PT_TRAINER_ID = "extra_pt_trainer_id";
    public static final String EXTRA_PT_DATE_ISO = "extra_pt_date_iso";
    public static final String EXTRA_PT_TIME = "extra_pt_time";

    private MembershipViewModel viewModel;
    private String planId;
    private boolean groupTopup;
    private int groupTopupCount;
    private String singleGroupSessionId;
    private EditText etName, etEmail, etPhone;
    private Button btnPay;
    private ProgressBar progressBar;
    private TextView tvError;
    private TextView tvPaymentTitle;
    private TextView tvPaymentSubtitle;
    private RadioGroup rgPaymentMethod;
    private boolean personalTrainingPaymentMode;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        viewModel = new ViewModelProvider(this).get(MembershipViewModel.class);
        planId = getIntent().getStringExtra(EXTRA_PLAN_ID);
        groupTopup = getIntent().getBooleanExtra(EXTRA_GROUP_TOPUP, false);
        groupTopupCount = getIntent().getIntExtra(EXTRA_GROUP_TOPUP_COUNT, 1);
        singleGroupSessionId = getIntent().getStringExtra(EXTRA_PAY_SINGLE_GROUP_SESSION_ID);
        String ptTrainer = getIntent().getStringExtra(EXTRA_PT_TRAINER_ID);
        String ptDate = getIntent().getStringExtra(EXTRA_PT_DATE_ISO);
        String ptTime = getIntent().getStringExtra(EXTRA_PT_TIME);
        personalTrainingPaymentMode = ptTrainer != null && !ptTrainer.trim().isEmpty()
                && ptDate != null && !ptDate.trim().isEmpty()
                && ptTime != null && !ptTime.trim().isEmpty();

        etName = findViewById(R.id.et_payment_name);
        etEmail = findViewById(R.id.et_payment_email);
        etPhone = findViewById(R.id.et_payment_phone);
        etName.setInputType(InputType.TYPE_CLASS_TEXT);
        btnPay = findViewById(R.id.btn_pay);
        progressBar = findViewById(R.id.progress_payment);
        tvError = findViewById(R.id.tv_payment_error);
        tvPaymentTitle = findViewById(R.id.tv_payment_title);
        tvPaymentSubtitle = findViewById(R.id.tv_payment_subtitle);
        rgPaymentMethod = findViewById(R.id.rg_payment_method);

        if (personalTrainingPaymentMode) {
            tvPaymentTitle.setText("Оплата персональной тренировки");
            tvPaymentSubtitle.setText("Разовая услуга. После оплаты будет создана запись.");
        } else if (singleGroupSessionId != null && !singleGroupSessionId.trim().isEmpty()) {
            tvPaymentTitle.setText("Оплата группового занятия");
            tvPaymentSubtitle.setText("Разовый визит. После оплаты вернитесь и нажмите «Записаться» ещё раз.");
        } else if (groupTopup) {
            tvPaymentTitle.setText("Оплатить тренировку");
            tvPaymentSubtitle.setText("Заполните данные, чтобы пополнить 1 групповое посещение.");
        } else {
            tvPaymentTitle.setText("Оплата абонемента");
            tvPaymentSubtitle.setText("Заполните данные для оформления");
        }

        User user = SharedPrefManager.getInstance(this).getCurrentUser();
        if (user != null) {
            String fio = user.getFullNameOfficial();
            if (fio != null && !fio.trim().isEmpty()) {
                etName.setText(fio);
            } else if (user.getName() != null) {
                etName.setText(user.getName());
            }
            if (user.getEmail() != null) etEmail.setText(user.getEmail());
            if (user.getPhone() != null) etPhone.setText(user.getPhone());
        }

        btnPay.setOnClickListener(v -> {
            String name = etName.getText() != null ? etName.getText().toString().trim() : "";
            String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
            String phone = etPhone.getText() != null ? etPhone.getText().toString().trim() : "";
            tvError.setVisibility(View.GONE);
            if (name.isEmpty()) {
                tvError.setText("Введите ФИО");
                tvError.setVisibility(View.VISIBLE);
                return;
            }
            if (email.isEmpty()) {
                tvError.setText("Введите email");
                tvError.setVisibility(View.VISIBLE);
                return;
            }
            if (phone.isEmpty()) {
                tvError.setText("Введите телефон");
                tvError.setVisibility(View.VISIBLE);
                return;
            }
            if (!ValidationUtils.isValidRussianPhone(phone)) {
                tvError.setText(getString(R.string.invalid_phone_format));
                tvError.setVisibility(View.VISIBLE);
                return;
            }
            if (rgPaymentMethod != null && rgPaymentMethod.getCheckedRadioButtonId() == -1) {
                tvError.setText(R.string.payment_method_required);
                tvError.setVisibility(View.VISIBLE);
                return;
            }
            User toSave = SharedPrefManager.getInstance(this).getCurrentUser();
            if (toSave != null) {
                toSave.applyFullNameLineFromPayment(name);
                toSave.setEmail(email);
                toSave.setPhone(phone);
                SharedPrefManager.getInstance(this).saveCurrentUser(toSave);
                final User synced = SharedPrefManager.getInstance(this).getCurrentUser();
                new Thread(() -> {
                    if (synced != null) {
                        MembershipRepository.getInstance(PaymentActivity.this).ensureAppUser(synced);
                        MembershipRepository.getInstance(PaymentActivity.this).updateAppUserProfile(synced);
                    }
                }).start();
            }
            if (personalTrainingPaymentMode) {
                Toast.makeText(this, "Оплата зарегистрирована", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
                return;
            }
            if (singleGroupSessionId != null && !singleGroupSessionId.trim().isEmpty()) {
                viewModel.payForSingleGroupSession(singleGroupSessionId.trim());
            } else if (groupTopup) {
                viewModel.topUpGroupVisits(groupTopupCount);
            } else {
                viewModel.purchaseMembership(planId);
            }
        });

        viewModel.getLoading().observe(this, loading -> {
            progressBar.setVisibility(Boolean.TRUE.equals(loading) ? View.VISIBLE : View.GONE);
            btnPay.setEnabled(!Boolean.TRUE.equals(loading));
        });
        viewModel.getError().observe(this, error -> {
            if (error != null) {
                tvError.setText(error);
                tvError.setVisibility(View.VISIBLE);
                viewModel.clearError();
            }
        });
        viewModel.getPurchaseSuccess().observe(this, success -> {
            boolean single = singleGroupSessionId != null && !singleGroupSessionId.trim().isEmpty();
            if (!personalTrainingPaymentMode && !groupTopup && !single && success != null && success) {
                Toast.makeText(this, "Абонемент успешно оформлен!", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            }
        });

        viewModel.getTopUpGroupSuccess().observe(this, success -> {
            if (groupTopup && success != null && success) {
                Toast.makeText(this, "Групповая тренировка успешно оплачена!", Toast.LENGTH_SHORT).show();
                viewModel.clearTopUpGroupSuccess();
                setResult(RESULT_OK);
                finish();
            }
        });

        viewModel.getSingleGroupPaySuccess().observe(this, success -> {
            if (singleGroupSessionId != null && !singleGroupSessionId.trim().isEmpty()
                    && success != null && success) {
                Toast.makeText(this, "Оплата занятия зарегистрирована", Toast.LENGTH_SHORT).show();
                viewModel.clearSingleGroupPaySuccess();
                setResult(RESULT_OK);
                finish();
            }
        });
    }
}