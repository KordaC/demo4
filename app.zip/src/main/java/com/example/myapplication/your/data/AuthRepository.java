package com.example.myapplication.your.data;



import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.example.myapplication.BuildConfig;
import com.example.myapplication.your.model.User;

import org.json.JSONArray;
import org.json.JSONTokener;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AuthRepository {
    private static AuthRepository instance;
    private static final String TAG = "AuthRepository";
    public static final String EMAIL_CONFIRM_REDIRECT = "myapp15://auth-callback";
    // Формирует ссылку для подтверждения email с редиректом обратно в приложение
    public static String buildConfirmSignupEmailHrefTemplate() {
        String base = BuildConfig.SUPABASE_URL != null ? BuildConfig.SUPABASE_URL.trim() : "";
        while (base.endsWith("/")) {
            base = base.substring(0, base.length() - 1);
        }
        if (base.isEmpty()) {
            base = "https://wqgwfwhcasewgopcnezd.supabase.co";
        }
        String encRedirect;
        try {
            encRedirect = URLEncoder.encode(EMAIL_CONFIRM_REDIRECT, StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            encRedirect = "myapp15%3A%2F%2Fauth-callback";
        }
        return base + "/auth/v1/verify?token={{ .TokenHash }}&type=signup&redirect_to=" + encRedirect;
    }
    // Генерирует HTML-ссылку для вставки в письмо подтверждения
    public static String buildConfirmSignupEmailHtmlSnippet() {
        String href = buildConfirmSignupEmailHrefTemplate().replace("&", "&amp;");
        return "<p><a href=\"" + href + "\">Подтвердить регистрацию</a></p>";
    }
    private final SharedPrefManager prefManager;
    private final MembershipRepository membershipRepository;
    private final String supabaseUrl;
    private final String supabaseKey;

    private AuthRepository(Context context) {
        prefManager = SharedPrefManager.getInstance(context);
        membershipRepository = MembershipRepository.getInstance(context);
        supabaseUrl = SupabaseClientProvider.getSupabaseUrl();
        supabaseKey = SupabaseClientProvider.getSupabaseAnonKey();
    }

    public static synchronized AuthRepository getInstance(Context context) {
        if (instance == null) {
            instance = new AuthRepository(context);
        }
        return instance;
    }
    // Результат аутентификации
    public static class AuthResult {
        public final User user;
        public final String error;
        public final boolean emailConfirmationPending;
        public final String confirmationEmail;

        public AuthResult(User user, String error) {
            this(user, error, false, null);
        }

        public AuthResult(User user, String error, boolean emailConfirmationPending, String confirmationEmail) {
            this.user = user;
            this.error = error;
            this.emailConfirmationPending = emailConfirmationPending;
            this.confirmationEmail = confirmationEmail;
        }

        public boolean isSuccess() {
            return user != null && error == null;
        }
    }

    public interface OnProfileSyncedListener {
        void onProfileSynced(User updated);
    }
    // Синхронизирует профиль из БД в фоне
    public void syncCurrentUserProfileFromServer(OnProfileSyncedListener listener) {
        new Thread(() -> {
            User result = null;
            try {
                User cur = prefManager.getCurrentUser();
                String token = prefManager.getAccessToken();
                if (cur == null || cur.getId() == null || cur.getId().trim().isEmpty()
                        || token == null || token.trim().isEmpty()) {
                    postProfileSync(listener, null);
                    return;
                }
                User profile = fetchAppUserProfile(cur.getId(), token.trim());
                if (profile != null) {
                    User merged = mergeFetchedProfile(cur, profile);
                    resolveRoleAfterAppUserFetch(merged, token.trim());
                    prefManager.saveCurrentUser(merged);
                    result = merged;
                    if (BuildConfig.DEBUG) {
                        Log.d(TAG, "syncProfile: role=" + merged.getRole() + " id=" + merged.getId());
                    }
                }
            } catch (Exception e) {
                Log.w(TAG, "syncCurrentUserProfileFromServer", e);
            }
            postProfileSync(listener, result);
        }).start();
    }

    private void postProfileSync(OnProfileSyncedListener listener, User user) {
        if (listener == null) return;
        new Handler(Looper.getMainLooper()).post(() -> listener.onProfileSynced(user));
    }
    // Объединяет данные из сессии и из app_user (приоритет у app_user)
    private static User mergeFetchedProfile(User sessionUser, User profile) {
        if (profile == null) return sessionUser;
        if (profile.getEmail() == null || profile.getEmail().isEmpty()) {
            profile.setEmail(sessionUser.getEmail());
        }
        if (profile.getId() == null || profile.getId().isEmpty()) {
            profile.setId(sessionUser.getId());
        }
        if ((profile.getPhone() == null || profile.getPhone().trim().isEmpty())
                && sessionUser.getPhone() != null && !sessionUser.getPhone().trim().isEmpty()) {
            profile.setPhone(sessionUser.getPhone());
        }
        if ((profile.getName() == null || profile.getName().trim().isEmpty())
                && sessionUser.getName() != null && !sessionUser.getName().trim().isEmpty()) {
            profile.setName(sessionUser.getName());
        }
        if ((profile.getSurname() == null || profile.getSurname().trim().isEmpty())
                && sessionUser.getSurname() != null && !sessionUser.getSurname().trim().isEmpty()) {
            profile.setSurname(sessionUser.getSurname());
        }
        if ((profile.getPatronymic() == null || profile.getPatronymic().trim().isEmpty())
                && sessionUser.getPatronymic() != null && !sessionUser.getPatronymic().trim().isEmpty()) {
            profile.setPatronymic(sessionUser.getPatronymic());
        }
        if ((profile.getBirthDate() == null || profile.getBirthDate().trim().isEmpty())
                && sessionUser.getBirthDate() != null && !sessionUser.getBirthDate().trim().isEmpty()) {
            profile.setBirthDate(sessionUser.getBirthDate());
        }
        return profile;
    }

    private void maybePromoteRoleFromAuthMetadata(JSONObject authUser, User user, String accessToken) {
        if (authUser == null || user == null || user.getId() == null || accessToken == null) return;
        String metaRole = resolveRoleFromAuthUserJson(authUser);
        if (metaRole == null) {
            metaRole = SupabaseJwtUtil.getRoleClaim(accessToken);
        }
        promoteTrainerOrAdminFromResolvedMeta(metaRole, user, accessToken);
    }
    // Определяет роль после получения профиля из app_user
    private void resolveRoleAfterAppUserFetch(User user, String accessToken) {
        if (user == null || accessToken == null) return;
        String jwtRole = SupabaseJwtUtil.getRoleClaim(accessToken);
        promoteTrainerOrAdminFromResolvedMeta(jwtRole, user, accessToken);
        applyAppUserRoleFromRpcIfStillClient(user, accessToken);
    }

    private void promoteTrainerOrAdminFromResolvedMeta(String metaRole, User user, String accessToken) {
        if (user == null || user.getId() == null || accessToken == null) return;
        if (metaRole == null) return;
        if (!User.ROLE_TRAINER.equals(metaRole) && !User.ROLE_ADMIN.equals(metaRole)) return;
        String cur = user.getRole();
        if (cur != null && !cur.trim().isEmpty()
                && !User.ROLE_CLIENT.equals(cur)) {
            return;
        }
        try {
            patchAppUserRoleAsUser(user.getId(), metaRole, accessToken.trim());
            user.setRole(metaRole);
        } catch (Exception e) {
            Log.w(TAG, "promoteTrainerOrAdminFromResolvedMeta: PATCH role не удался (RLS). Роль из JWT остаётся в сессии.", e);
            user.setRole(metaRole);
        }
    }

    private void applyAppUserRoleFromRpcIfStillClient(User user, String accessToken) {
        if (user == null || accessToken == null) return;
        if (!User.ROLE_CLIENT.equals(user.getRole())) return;
        String r = fetchMyAppRoleViaRpc(accessToken.trim());
        if (r == null) return;
        user.setRole(r);
    }

    private String fetchMyAppRoleViaRpc(String accessToken) {
        try {
            URL url = new URL(supabaseUrl + "/rest/v1/rpc/get_my_app_role");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("apikey", supabaseKey);
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Prefer", "return=representation");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                os.write("{}".getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (stream == null) {
                if (code == 404 && BuildConfig.DEBUG) {
                    Log.d(TAG, "get_my_app_role");
                }
                return null;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close();
            if (code >= 400) {
                if (BuildConfig.DEBUG) Log.d(TAG, "get_my_app_role HTTP " + code + ": " + sb);
                return null;
            }
            String t = sb.toString().trim();
            if (t.isEmpty()) return null;
            Object parsed = new JSONTokener(t).nextValue();
            if (parsed == null) return null;
            String raw = parsed.toString().trim();
            if (raw.isEmpty() || "null".equalsIgnoreCase(raw)) return null;
            raw = raw.toLowerCase(Locale.ROOT);
            if (User.ROLE_CLIENT.equals(raw) || User.ROLE_TRAINER.equals(raw) || User.ROLE_ADMIN.equals(raw)) {
                return raw;
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) Log.d(TAG, "fetchMyAppRoleViaRpc", e);
        }
        return null;
    }
    private static void ensureRoleFromJwtWhenMissing(JSONObject authUser, User user, String accessToken) {
        if (user == null) return;
        if (user.hasExplicitRole()) return;
        String r = authUser != null ? resolveRoleFromAuthUserJson(authUser) : null;
        if (r == null) {
            r = SupabaseJwtUtil.getRoleClaim(accessToken);
        }
        if (r != null) user.setRole(r);
    }
    // Извлекает роль из JSON-объекта пользователя Supabase
    private static String resolveRoleFromAuthUserJson(JSONObject userObj) {
        if (userObj == null) return null;
        String r = null;
        JSONObject appMeta = userObj.optJSONObject("app_metadata");
        if (appMeta != null) {
            r = appMeta.optString("role", "").trim();
        }
        if (r == null || r.isEmpty()) {
            JSONObject um = userObj.optJSONObject("user_metadata");
            if (um != null) {
                r = um.optString("role", "").trim();
            }
        }
        if (r == null || r.isEmpty()) return null;
        r = r.toLowerCase(Locale.ROOT);
        if (User.ROLE_CLIENT.equals(r) || User.ROLE_TRAINER.equals(r) || User.ROLE_ADMIN.equals(r)) {
            return r;
        }
        return null;
    }
    // PATCH-запрос для обновления роли в app_user
    private void patchAppUserRoleAsUser(String userId, String role, String accessToken) throws Exception {
        JSONObject body = new JSONObject();
        body.put("role", role);
        URL url = new URL(supabaseUrl + "/rest/v1/app_user?id=eq." + userId.trim());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PATCH");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=minimal");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = body.toString().getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }
        int code = conn.getResponseCode();
        if (code >= 400) {
            BufferedReader er = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = er.readLine()) != null) sb.append(line);
            er.close();
            throw new Exception("HTTP " + code + ": " + sb);
        }
    }
    // Вход с email и паролем
    public AuthResult login(String email, String password) {
        try {
            JSONObject data = new JSONObject();
            data.put("email", email);
            data.put("password", password);

            String url = supabaseUrl + "/auth/v1/token?grant_type=password";
            String jsonResponse = makePostRequest(url, data.toString());
            JSONObject json = new JSONObject(jsonResponse);
            return completeAuthFromTokenResponse(json);
        } catch (Exception e) {
            Log.e(TAG, "login", e);
            return new AuthResult(null, normalizeAuthError(e));
        }
    }
    // Завершает аутентификацию из ответа с токенами
    private AuthResult completeAuthFromTokenResponse(JSONObject json) {
        try {
            TrainerProfileIdCache.clear();
            String accessToken = json.optString("access_token", null);
            String refreshToken = json.optString("refresh_token", null);
            JSONObject userObj = json.optJSONObject("user");
            if (userObj == null) return new AuthResult(null, "Не удалось получить пользователя из ответа Supabase.");
            if (accessToken == null || accessToken.isEmpty()) {
                return new AuthResult(null, "Подтвердите email в письме, затем войдите через экран «Вход».");
            }

            User user = new User();
            user.setId(userObj.optString("id"));
            user.setEmail(userObj.optString("email"));
            JSONObject meta = userObj.optJSONObject("user_metadata");
            if (meta != null) {
                user.setName(meta.optString("name", ""));
                String sur = meta.optString("surname", "");
                if (sur == null || sur.isEmpty()) sur = meta.optString("last_name", "");
                if (sur != null && !sur.trim().isEmpty()) {
                    user.setSurname(sur.trim());
                }
                String pat = meta.optString("patronymic", "");
                if (pat == null || pat.isEmpty()) pat = meta.optString("middle_name", "");
                if (pat != null && !pat.trim().isEmpty()) {
                    user.setPatronymic(pat.trim());
                }
                String bd = meta.optString("birth_date", "");
                if (bd != null && !bd.trim().isEmpty() && !"null".equalsIgnoreCase(bd.trim())) {
                    user.setBirthDate(bd.trim());
                }
                String metaPhone = meta.optString("phone", "");
                if (metaPhone != null) {
                    metaPhone = metaPhone.trim();
                    if (!metaPhone.isEmpty() && !"null".equalsIgnoreCase(metaPhone)) {
                        user.setPhone(metaPhone);
                    }
                }
            } else {
                user.setName("");
            }
            prefManager.saveAuthTokens(accessToken, refreshToken != null ? refreshToken : "");
// Создаём запись в app_user, если её нет
            if (!membershipRepository.ensureAppUser(user)) {
                membershipRepository.ensureAppUser(user);
            }
            User profile = fetchAppUserProfile(user.getId(), accessToken);
            if (profile != null) {
                user = mergeFetchedProfile(user, profile);
            }

            maybePromoteRoleFromAuthMetadata(userObj, user, accessToken);
            ensureRoleFromJwtWhenMissing(userObj, user, accessToken);
            applyAppUserRoleFromRpcIfStillClient(user, accessToken);

            if (!user.hasExplicitRole()) {
                user.setRole(User.ROLE_CLIENT);
            }

            prefManager.saveCurrentUser(user);
            return new AuthResult(user, null);
        } catch (Exception e) {
            Log.e(TAG, "completeAuthFromTokenResponse", e);
            return new AuthResult(null, normalizeAuthError(e));
        }
    }
    // Обновляет access-токен по refresh-токену
    public boolean tryRefreshAccessToken() {
        String refresh = prefManager.getRefreshToken();
        if (refresh == null || refresh.trim().isEmpty()) return false;
        try {
            JSONObject body = new JSONObject();
            body.put("refresh_token", refresh.trim());
            String resp = makePostRequest(supabaseUrl + "/auth/v1/token?grant_type=refresh_token", body.toString());
            JSONObject j = new JSONObject(resp);
            AuthResult r = completeAuthFromTokenResponse(j);
            return r.isSuccess();
        } catch (Exception e) {
            Log.w(TAG, "tryRefreshAccessToken", e);
            return false;
        }
    }
    // Обрабатывает deep link после OAuth/подтверждения email
    public AuthResult completeSessionFromOAuthRedirect(Uri uri, String fullUriString) {
        if (uri == null) return new AuthResult(null, "Пустая ссылка.");
        Map<String, String> p = new HashMap<>();
        String frag = uri.getFragment();
        if (frag == null || frag.isEmpty()) {
            if (fullUriString != null) {
                int hash = fullUriString.indexOf('#');
                if (hash >= 0 && hash < fullUriString.length() - 1) {
                    frag = fullUriString.substring(hash + 1);
                }
            }
        }
        if (frag != null && !frag.isEmpty()) {
            p.putAll(parseFormStyleParams(frag));
        }
        String query = uri.getQuery();
        if (query != null && !query.isEmpty()) {
            p.putAll(parseFormStyleParams(query));
        }
        for (String name : uri.getQueryParameterNames()) {
            String v = uri.getQueryParameter(name);
            if (v != null) p.put(name, v);
        }
        String err = p.get("error");
        if (err != null && !err.isEmpty()) {
            String desc = p.get("error_description");
            return new AuthResult(null, desc != null && !desc.isEmpty() ? desc : err);
        }
        String access = p.get("access_token");
        String refresh = p.get("refresh_token");
        if (access != null && !access.isEmpty()) {
            return completeSessionFromAccessToken(access, refresh != null ? refresh : "");
        }

        String tokenHash = p.get("token_hash");
        if (tokenHash == null || tokenHash.isEmpty()) {
            String t = p.get("token");
            if (t != null && !t.isEmpty()) {
                tokenHash = t;
            }
        }
        String type = p.get("type");
        if (tokenHash != null && !tokenHash.isEmpty() && type != null && !type.isEmpty()) {
            return verifySessionWithTokenHash(tokenHash, type);
        }

        String code = p.get("code");
        if (code != null && !code.isEmpty()) {
            AuthResult pkce = tryExchangePkceCode(code);
            if (pkce != null && pkce.isSuccess()) {
                return pkce;
            }
            if (pkce != null && pkce.error != null && !pkce.error.isEmpty()) {
                return pkce;
            }
        }

        return new AuthResult(null,
                "В ссылке нет данных для входа. В Supabase добавьте Redirect URL: " + EMAIL_CONFIRM_REDIRECT
                        + " и в шаблоне письма подтверждения используйте ссылку с token_hash (см. комментарий к EMAIL_CONFIRM_REDIRECT).");
    }

    public AuthResult completeSessionFromOAuthRedirect(Uri uri) {
        return completeSessionFromOAuthRedirect(uri, null);
    }
    // Подтверждение регистрации по OTP-коду из письма
    public AuthResult verifySignupEmailOtp(String email, String otpToken) {
        if (email == null || email.trim().isEmpty()) {
            return new AuthResult(null, "Укажите email.");
        }
        if (otpToken == null || otpToken.trim().isEmpty()) {
            return new AuthResult(null, "Введите код из письма.");
        }
        try {
            JSONObject body = new JSONObject();
            body.put("type", "signup");
            body.put("email", email.trim());
            body.put("token", otpToken.trim());
            String url = supabaseUrl + "/auth/v1/verify";
            String jsonResponse = makePostRequest(url, body.toString());
            JSONObject json = new JSONObject(jsonResponse);
            return completeAuthFromTokenResponse(json);
        } catch (Exception e) {
            Log.e(TAG, "verifySignupEmailOtp", e);
            return new AuthResult(null, normalizeAuthError(e));
        }
    }
    public AuthResult verifySessionWithTokenHash(String tokenHash, String type) {
        if (tokenHash == null || tokenHash.trim().isEmpty()) {
            return new AuthResult(null, "Пустой token_hash.");
        }
        if (type == null || type.trim().isEmpty()) {
            return new AuthResult(null, "Не указан type подтверждения.");
        }
        try {
            JSONObject body = new JSONObject();
            body.put("type", type.trim());
            body.put("token_hash", tokenHash.trim());
            String url = supabaseUrl + "/auth/v1/verify";
            String jsonResponse = makePostRequest(url, body.toString());
            JSONObject json = new JSONObject(jsonResponse);
            return completeAuthFromTokenResponse(json);
        } catch (Exception e) {
            Log.e(TAG, "verifySessionWithTokenHash", e);
            return new AuthResult(null, normalizeAuthError(e));
        }
    }

    private AuthResult tryExchangePkceCode(String code) {
        try {
            JSONObject body = new JSONObject();
            body.put("auth_code", code.trim());
            String url = supabaseUrl + "/auth/v1/token?grant_type=pkce";
            String jsonResponse = makePostRequest(url, body.toString());
            JSONObject json = new JSONObject(jsonResponse);
            return completeAuthFromTokenResponse(json);
        } catch (Exception e) {
            Log.w(TAG, "tryExchangePkceCode", e);
            String msg = e.getMessage() != null ? e.getMessage() : "";
            if (msg.toLowerCase(Locale.ROOT).contains("verifier")) {
                return new AuthResult(null,
                        "Нужен полный PKCE-обмен. Используйте ссылку с token_hash в приложении или войдите вручную.");
            }
            return new AuthResult(null, normalizeAuthError(e));
        }
    }

    public AuthResult completeSessionFromAccessToken(String accessToken, String refreshToken) {
        try {
            JSONObject userObj = fetchAuthUserJson(accessToken);
            JSONObject envelope = new JSONObject();
            envelope.put("access_token", accessToken);
            envelope.put("refresh_token", refreshToken != null ? refreshToken : "");
            envelope.put("user", userObj);
            return completeAuthFromTokenResponse(envelope);
        } catch (Exception e) {
            Log.e(TAG, "completeSessionFromAccessToken", e);
            return new AuthResult(null, normalizeAuthError(e));
        }
    }

    private static Map<String, String> parseFormStyleParams(String form) {
        Map<String, String> m = new HashMap<>();
        if (form == null || form.isEmpty()) return m;
        for (String part : form.split("&")) {
            int eq = part.indexOf('=');
            if (eq <= 0) continue;
            try {
                String k = URLDecoder.decode(part.substring(0, eq), StandardCharsets.UTF_8.name());
                String v = URLDecoder.decode(part.substring(eq + 1), StandardCharsets.UTF_8.name());
                m.put(k, v);
            } catch (Exception ignored) {}
        }
        return m;
    }
    // Получает данные пользователя из Supabase Auth по токену
    private JSONObject fetchAuthUserJson(String accessToken) throws Exception {
        URL url = new URL(supabaseUrl + "/auth/v1/user");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + accessToken.trim());
        conn.setRequestProperty("Accept", "application/json");

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null) stream = conn.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return new JSONObject(sb.toString());
    }

    // Регистрация нового пользователя
    public AuthResult register(String name, String surname,
                               String patronymic, String birthDateIso,
                               String email, String phone, String password) {
        try {
            JSONObject data = new JSONObject();
            data.put("email", email);
            data.put("password", password);
            JSONObject meta = new JSONObject();
            meta.put("name", name != null ? name : "");
            if (surname != null && !surname.trim().isEmpty()) {
                meta.put("surname", surname.trim());
            }
            if (patronymic != null && !patronymic.trim().isEmpty()) {
                meta.put("patronymic", patronymic.trim());
            }
            if (birthDateIso != null && !birthDateIso.trim().isEmpty()) {
                meta.put("birth_date", birthDateIso.trim());
            }
            if (phone != null && !phone.trim().isEmpty()) meta.put("phone", phone);
            data.put("data", meta);

            JSONObject options = new JSONObject();
            options.put("email_redirect_to", EMAIL_CONFIRM_REDIRECT);
            data.put("options", options);
            String url = supabaseUrl + "/auth/v1/signup";
            String jsonResponse = makePostRequest(url, data.toString());
            JSONObject json = new JSONObject(jsonResponse);
            // Проверка на уже существующий аккаунт
            if (json.has("error_code")) {
                String ec = json.optString("error_code", "");
                if ("user_already_exists".equalsIgnoreCase(ec) || "email_exists".equalsIgnoreCase(ec)) {
                    return new AuthResult(null, "Аккаунт с таким email уже существует. Войдите через экран «Вход».");
                }
            }
            String topMsg = json.optString("msg", "");
            if (looksLikeDuplicateSignupMessage(topMsg)) {
                return new AuthResult(null, "Аккаунт с таким email уже существует. Войдите через экран «Вход».");
            }

            JSONObject userObj = json.optJSONObject("user");
            if (userObj == null) {
                if (json.has("id") || json.has("email")) {
                    userObj = json;
                }
            }
            if (userObj == null) return new AuthResult(null, "Не удалось создать пользователя в Supabase.");
            // Если сразу вернулся access_token — вход выполнен
            String accessToken = json.optString("access_token", "");
            if (!accessToken.isEmpty()) {
                return completeAuthFromTokenResponse(json);
            }
            // Иначе пользователь создан, но требует подтверждения email
            User user = new User();
            user.setId(userObj.optString("id"));
            user.setEmail(userObj.optString("email"));
            JSONObject um = userObj.optJSONObject("user_metadata");
            if (um != null) {
                user.setName(um.optString("name", name != null ? name : ""));
                String sur = um.optString("surname", surname != null ? surname : "");
                if (sur == null || sur.isEmpty()) sur = um.optString("last_name", "");
                if (sur != null && !sur.trim().isEmpty()) user.setSurname(sur.trim());
                String pat = um.optString("patronymic", "");
                if (pat == null || pat.isEmpty()) pat = um.optString("middle_name", "");
                if (pat != null && !pat.trim().isEmpty()) user.setPatronymic(pat.trim());
                String bd = um.optString("birth_date", birthDateIso != null ? birthDateIso : "");
                if (bd != null && !bd.trim().isEmpty()) user.setBirthDate(bd.trim());
            } else {
                user.setName(name != null ? name : "");
                if (surname != null && !surname.trim().isEmpty()) user.setSurname(surname.trim());
                if (patronymic != null && !patronymic.trim().isEmpty()) user.setPatronymic(patronymic.trim());
                if (birthDateIso != null && !birthDateIso.trim().isEmpty()) user.setBirthDate(birthDateIso.trim());
            }
            user.setPhone(phone != null ? phone : "");
            membershipRepository.ensureAppUser(user);

            if (BuildConfig.DEBUG) {
                Log.d(TAG, "Шаблон письма"
                        + buildConfirmSignupEmailHtmlSnippet());
            }
            return new AuthResult(null,
                    null,
                    true,
                    email != null ? email.trim() : "");
        } catch (Exception e) {
            Log.e(TAG, "register", e);
            return new AuthResult(null, normalizeAuthError(e));
        }
    }
    // HTTP POST-запрос к Supabase
    private String makePostRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int code = conn.getResponseCode();
        BufferedReader reader;
        if (code >= 400) {
            reader = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
        } else {
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
        return sb.toString();
    }
    // Получает профиль из таблицы app_user
    private User fetchAppUserProfile(String userId, String accessToken) {
        if (userId == null || userId.trim().isEmpty()) return null;
        try {
            String url = supabaseUrl + "/rest/v1/app_user?id=eq." + userId + "&select=id,email,name,last_name,patronymic,birth_date,phone,avatar_url,role";
            String jsonResponse = makeGetRequestAsUser(url, accessToken);
            if (jsonResponse == null || jsonResponse.trim().isEmpty() || jsonResponse.trim().equals("[]")) return null;
            JSONArray arr = new JSONArray(jsonResponse);
            if (arr.length() == 0) return null;
            JSONObject j = arr.getJSONObject(0);

            User u = new User();
            u.setId(j.optString("id"));
            u.setEmail(j.optString("email"));
            u.setName(j.optString("name"));
            String ln = j.optString("last_name", "");
            if (ln != null && !ln.trim().isEmpty() && !"null".equalsIgnoreCase(ln.trim())) {
                u.setSurname(ln.trim());
            }
            String pat = j.optString("patronymic", "");
            if (pat != null && !pat.trim().isEmpty() && !"null".equalsIgnoreCase(pat.trim())) {
                u.setPatronymic(pat.trim());
            }
            String bd = j.optString("birth_date", "");
            if (bd != null && !bd.trim().isEmpty() && !"null".equalsIgnoreCase(bd.trim())) {
                String t = bd.trim();
                if (t.length() >= 10) u.setBirthDate(t.substring(0, 10));
                else u.setBirthDate(t);
            }
            String ph = j.optString("phone");
            if (ph != null && !ph.trim().isEmpty() && !"null".equalsIgnoreCase(ph.trim())) {
                u.setPhone(ph.trim());
            } else {
                u.setPhone(null);
            }
            u.setAvatarUrl(j.optString("avatar_url", null));
            if (u.getAvatarUrl() != null && u.getAvatarUrl().isEmpty()) u.setAvatarUrl(null);
            String roleRaw = j.optString("role", "");
            if (roleRaw != null) roleRaw = roleRaw.trim();
            if (roleRaw == null || roleRaw.isEmpty() || "null".equalsIgnoreCase(roleRaw)) {
                u.setRole(null);
            } else {
                String rl = roleRaw.toLowerCase(Locale.ROOT);
                if (User.ROLE_CLIENT.equals(rl) || User.ROLE_TRAINER.equals(rl) || User.ROLE_ADMIN.equals(rl)) {
                    u.setRole(rl);
                } else {
                    u.setRole(null);
                }
            }
            return u;
        } catch (Exception e) {
            Log.w(TAG, "fetchAppUserProfile", e);
            return null;
        }
    }
    // HTTP GET-запрос с авторизацией пользователя
    private String makeGetRequestAsUser(String urlString, String accessToken) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("apikey", supabaseKey);
        String bearer = (accessToken != null && !accessToken.trim().isEmpty()) ? accessToken.trim() : supabaseKey;
        conn.setRequestProperty("Authorization", "Bearer " + bearer);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json");

        int code = conn.getResponseCode();
        BufferedReader reader;
        if (code >= 400) {
            reader = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
        } else {
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb.toString());
        }
        return sb.toString();
    }

    private static boolean looksLikeDuplicateSignupMessage(String msg) {
        if (msg == null || msg.trim().isEmpty()) return false;
        String lower = msg.toLowerCase();
        return lower.contains("already registered")
                || lower.contains("already exists")
                || lower.contains("user already")
                || lower.contains("email already");
    }

    private static String normalizeAuthError(Exception e) {
        if (e == null || e.getMessage() == null) return "Ошибка авторизации.";
        String msg = e.getMessage();
        String lower = msg.toLowerCase();
        if (lower.contains("user already registered") || lower.contains("already registered")
                || lower.contains("email address is already registered")
                || lower.contains("email already registered")
                || lower.contains("user_already_exists")) {
            return "Аккаунт с таким email уже существует. Войдите через экран «Вход».";
        }
        if (lower.contains("invalid login credentials")) {
            return "Неверный e-mail или пароль";
        }
        if (lower.contains("password") && lower.contains("should be at least")) {
            return "Пароль слишком короткий";
        }
        if (lower.contains("email") && lower.contains("not") && lower.contains("valid")) {
            return "Некорректный формат e-mail";
        }
        if (lower.contains("email not confirmed") || lower.contains("confirm")) {
            return "Подтвердите email в письме от Supabase и попробуйте снова.";
        }
        try {
            int idx = msg.indexOf('{');
            if (idx >= 0) {
                String jsonStr = msg.substring(idx);
                JSONObject j = new JSONObject(jsonStr);
                if (j.has("msg")) return j.optString("msg");
                if (j.has("message")) return j.optString("message");
                if (j.has("error_description")) return j.optString("error_description");
                if (j.has("error")) return j.optString("error");
                if (j.has("details")) return j.optString("details");
                if (j.has("errors")) {
                    Object errs = j.get("errors");
                    if (errs instanceof JSONArray) {
                        JSONArray arr = (JSONArray) errs;
                        if (arr.length() > 0) return arr.getJSONObject(0).optString("message", msg);
                    }
                }
            }
        } catch (Exception ignored) {}

        return msg;
    }
}
