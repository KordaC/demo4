package com.example.myapplication.your.ui.auth;



import android.content.Context;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.your.util.ValidationUtils;
import com.example.myapplication.your.viewmodel.AuthViewModel;
// Экран входа в приложение
public class LoginFragment extends Fragment {
    private AuthViewModel viewModel;
    private LoginListener listener;

    public interface LoginListener {
        void onLoginSuccess();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof LoginListener) {
            listener = (LoginListener) context;
        }
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,@Nullable ViewGroup container,@Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    private com.google.android.material.textfield.TextInputEditText etEmail, etPassword;
    private ProgressBar progressBar;

    @Override
    public void onViewCreated(@NonNull View view,@Nullable Bundle savedInstanceState) {
        etEmail = view.findViewById(R.id.etEmail);
        etPassword = view.findViewById(R.id.etPassword);
        progressBar = view.findViewById(R.id.progressBar);
        viewModel = new ViewModelProvider(requireActivity()).get(AuthViewModel.class);
// Кнопка входа
        view.findViewById(R.id.btnLogin).setOnClickListener(v -> {
            String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
            String pass = etPassword.getText() != null ? etPassword.getText().toString() : "";
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
                Toast.makeText(requireContext(), getString(R.string.empty_fields_error), Toast.LENGTH_SHORT).show();
                return;
            }
            if (ValidationUtils.looksLikePhone(email)) {
                Toast.makeText(requireContext(), "Вход по телефону пока не поддерживается. Используйте email.", Toast.LENGTH_SHORT).show();
                return;
            } else {
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    Toast.makeText(requireContext(), getString(R.string.invalid_email_format), Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            viewModel.login(email, pass);
        });
// Переход на экран регистрации
        view.findViewById(R.id.btnToRegister).setOnClickListener(v -> {

            ((AuthActivity) requireActivity()).openFragment(new RegisterFragment(), true);
        });
// Наблюдатели LiveData
        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            progressBar.setVisibility(Boolean.TRUE.equals(isLoading) ? View.VISIBLE : View.GONE);
        });

        viewModel.getUser().observe(getViewLifecycleOwner(), user -> {
            if (user != null) {

                if (listener != null) listener.onLoginSuccess();
            }
        });

        viewModel.getError().observe(getViewLifecycleOwner(), err -> {
            if (err != null) {
                Toast.makeText(requireContext(), err, Toast.LENGTH_SHORT).show();
                viewModel.clearError();
            }
        });
    }
}