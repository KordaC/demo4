package com.example.myapplication.your.ui.main;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.data.FavoritesRepository;
import com.example.myapplication.your.data.MembershipRepository;
import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.util.GroupSignupUiHelper;
import com.example.myapplication.your.viewmodel.CalendarViewModel;
import com.example.myapplication.your.ui.trainer.CreateSessionActivity;

import java.util.Calendar;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

public class CalendarActivity extends AppCompatActivity {

    public static final String EXTRA_ADMIN_MODE = "extra_admin_mode";

    private boolean adminMode;
    private String pendingGroupPaymentSessionId;
    private boolean waitingForGroupPayment;
    private ActivityResultLauncher<Intent> paymentLauncher;

    private CalendarViewModel viewModel;
    private CalendarView calendarView;
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView tvSelectedDate;
    private TextView tvNoSessions;
    private SessionAdapter adapter;
    private LocalDate selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
        adminMode = getIntent().getBooleanExtra(EXTRA_ADMIN_MODE, false);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Календарь занятий");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        viewModel = new ViewModelProvider(this).get(CalendarViewModel.class);

        View fabCreate = findViewById(R.id.fab_calendar_create_session);
        if (fabCreate != null) {
            fabCreate.setVisibility(adminMode ? View.VISIBLE : View.GONE);
            fabCreate.setOnClickListener(v -> {
                Intent i = new Intent(this, CreateSessionActivity.class);
                i.putExtra(CreateSessionActivity.EXTRA_ADMIN_MODE, true);
                startActivity(i);
            });
        }
        
        calendarView = findViewById(R.id.calendar_view);
        recyclerView = findViewById(R.id.recycler_sessions);
        progressBar = findViewById(R.id.progress_bar);
        tvSelectedDate = findViewById(R.id.tv_selected_date);
        tvNoSessions = findViewById(R.id.tv_no_sessions);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SessionAdapter(this, new ArrayList<>(), viewModel, adminMode);
        recyclerView.setAdapter(adapter);
        paymentLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    waitingForGroupPayment = false;
                    if (result.getResultCode() == Activity.RESULT_OK && pendingGroupPaymentSessionId != null) {
                        viewModel.signUpForSession(pendingGroupPaymentSessionId);
                    }
                }
        );
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        calendarView.setMinDate(cal.getTimeInMillis());

        selectedDate = LocalDate.now();
        updateSelectedDateDisplay();
        loadSessionsForDate(selectedDate);
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = LocalDate.of(year, month + 1, dayOfMonth);
            updateSelectedDateDisplay();
            loadSessionsForDate(selectedDate);
        });
        observeViewModel();
        viewModel.loadAllSessions();
    }

    private void updateSelectedDateDisplay() {
        if (selectedDate != null) {
            String[] daysOfWeek = {"Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"};
            String[] months = {"января", "февраля", "марта", "апреля", "мая", "июня", 
                             "июля", "августа", "сентября", "октября", "ноября", "декабря"};
            
            int dayOfWeek = selectedDate.getDayOfWeek().getValue() % 7;
            int month = selectedDate.getMonthValue() - 1;
            
            String dateStr = daysOfWeek[dayOfWeek] + ", " + selectedDate.getDayOfMonth() + 
                           " " + months[month] + " " + selectedDate.getYear();
            tvSelectedDate.setText("Занятия на " + dateStr);
        }
    }

    private void loadSessionsForDate(LocalDate date) {
        viewModel.loadSessionsForDate(date);
    }

    private void observeViewModel() {
        viewModel.getLoading().observe(this, isLoading -> {
            progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        });

        viewModel.getSessionsForDate().observe(this, sessions -> {
            if (sessions == null || sessions.isEmpty()) {
                recyclerView.setVisibility(View.GONE);
                tvNoSessions.setVisibility(View.VISIBLE);
            } else {
                recyclerView.setVisibility(View.VISIBLE);
                tvNoSessions.setVisibility(View.GONE);
                adapter.updateSessions(sessions);
            }
        });

        viewModel.getError().observe(this, error -> {
            if (error != null) {
                boolean isLimitExhausted = error.contains("Исчерпан лимит групповых посещений");
                boolean needSingleGroup = MembershipRepository.NEED_PAY_SINGLE_GROUP_SESSION.equals(error);
                if ((isLimitExhausted || needSingleGroup) && pendingGroupPaymentSessionId != null && !waitingForGroupPayment) {
                    waitingForGroupPayment = true;
                    Intent pi = new Intent(this, PaymentActivity.class);
                    if (needSingleGroup) {
                        pi.putExtra(PaymentActivity.EXTRA_PAY_SINGLE_GROUP_SESSION_ID, pendingGroupPaymentSessionId);
                    } else {
                        pi.putExtra(PaymentActivity.EXTRA_GROUP_TOPUP, true);
                        pi.putExtra(PaymentActivity.EXTRA_GROUP_TOPUP_COUNT, 1);
                    }
                    paymentLauncher.launch(pi);
                    viewModel.clearError();
                    return;
                }
                Toast.makeText(this, error, Toast.LENGTH_LONG).show();
                viewModel.clearError();
            }
        });

        viewModel.getSignupSuccess().observe(this, success -> {
            if (success != null && success) {
                Toast.makeText(this, "Запись успешно обновлена", Toast.LENGTH_SHORT).show();
                viewModel.clearSignupSuccess();
                pendingGroupPaymentSessionId = null;
                waitingForGroupPayment = false;
            }
        });
        viewModel.getSessionStatusChanged().observe(this, sessionIdWithTimestamp -> {
            if (sessionIdWithTimestamp != null && !sessionIdWithTimestamp.isEmpty()) {
                adapter.notifyDataSetChanged();
            }
        });
        viewModel.getAllSessions().observe(this, allSessions -> {
            if (allSessions != null && !allSessions.isEmpty()) {
                markDatesWithSessions(allSessions);
            }
        });
    }

    private void markDatesWithSessions(List<Session> sessions) {
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private static class SessionAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<SessionAdapter.ViewHolder> {
        List<Session> sessions;
        private CalendarViewModel viewModel;
        private final CalendarActivity host;
        private final boolean adminMode;

        SessionAdapter(CalendarActivity host, List<Session> sessions, CalendarViewModel viewModel, boolean adminMode) {
            this.host = host;
            this.sessions = sessions;
            this.viewModel = viewModel;
            this.adminMode = adminMode;
        }

        void updateSessions(List<Session> newSessions) {
            this.sessions = newSessions != null ? newSessions : new ArrayList<>();
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull android.view.ViewGroup parent, int viewType) {
            android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_session, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Session session = sessions.get(position);
            holder.bind(session);
        }

        @Override
        public int getItemCount() {
            return sessions.size();
        }

        class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            android.widget.TextView tvTitle;
            android.widget.TextView tvMore;
            android.widget.TextView tvTime;
            android.widget.TextView tvDate;
            android.widget.TextView tvTrainer;
            android.widget.TextView tvSpots;
            android.widget.TextView tvPrice;
            android.widget.TextView tvHall;
            android.widget.Button btnAction;
            ImageButton btnFavorite;
            View rowTrainer;
            ImageView ivTrainerPhoto;
            ImageView ivCover;

            ViewHolder(@NonNull android.view.View itemView) {
                super(itemView);
                ivCover = itemView.findViewById(R.id.iv_session_cover);
                tvTitle = itemView.findViewById(R.id.tv_session_title);
                tvMore = itemView.findViewById(R.id.tv_session_more);
                btnFavorite = itemView.findViewById(R.id.btn_session_favorite);
                rowTrainer = itemView.findViewById(R.id.row_session_trainer_block);
                ivTrainerPhoto = itemView.findViewById(R.id.iv_session_trainer_photo);
                tvTime = itemView.findViewById(R.id.tv_session_time);
                tvDate = itemView.findViewById(R.id.tv_session_date);
                tvTrainer = itemView.findViewById(R.id.tv_session_trainer);
                tvPrice = itemView.findViewById(R.id.tv_session_price);
                tvHall = itemView.findViewById(R.id.tv_session_hall);
                tvSpots = itemView.findViewById(R.id.tv_session_spots);
                btnAction = itemView.findViewById(R.id.btn_session_action);
            }

            void bind(Session session) {
                android.widget.TextView tvClients = itemView.findViewById(R.id.tv_session_clients);
                if (tvClients != null) {
                    tvClients.setVisibility(android.view.View.GONE);
                }

                if (ivCover != null) {
                    String u = session.getImageUrl();
                    if (u != null && u.startsWith("http")) {
                        ivCover.setVisibility(android.view.View.VISIBLE);
                        Glide.with(itemView.getContext()).load(u).centerCrop()
                                .placeholder(R.drawable.ic_trainer).into(ivCover);
                    } else {
                        ivCover.setVisibility(android.view.View.GONE);
                    }
                }

                tvTitle.setText(session.getTitle());
                tvTime.setText(session.getFormattedTimeRange());
                tvDate.setText(session.getFormattedDateLine());

                if (session.getTrainerName() != null && !session.getTrainerName().isEmpty()) {
                    tvTrainer.setText(session.getTrainerName());
                } else {
                    String tid = session.getTrainerId();
                    boolean hasTrainerId = tid != null && !tid.trim().isEmpty() && !"null".equalsIgnoreCase(tid.trim());
                    tvTrainer.setText(hasTrainerId ? "Тренер уточняется" : "Тренер не указан");
                }
                if (ivTrainerPhoto != null) {
                    String p = session.getTrainerPhotoUrl();
                    if (p != null && p.startsWith("http")) {
                        Glide.with(itemView.getContext()).load(p).circleCrop()
                                .placeholder(R.drawable.ic_trainer).into(ivTrainerPhoto);
                    } else {
                        ivTrainerPhoto.setImageResource(R.drawable.ic_trainer);
                    }
                }
                if (rowTrainer != null) {
                    String tid = session.getTrainerId();
                    if (tid != null && !tid.trim().isEmpty()) {
                        rowTrainer.setClickable(true);
                        rowTrainer.setOnClickListener(v -> {
                            Intent i = new Intent(v.getContext(), TrainerDetailActivity.class);
                            i.putExtra(TrainerDetailActivity.EXTRA_TRAINER_ID, tid);
                            v.getContext().startActivity(i);
                        });
                    } else {
                        rowTrainer.setOnClickListener(null);
                        rowTrainer.setClickable(false);
                    }
                }

                if (tvPrice != null) {
                    tvPrice.setText(session.getPriceLabelForCard());
                }
                if (tvHall != null) {
                    String hallLine = session.getHallLineForCard();
                    if (hallLine.isEmpty()) {
                        tvHall.setVisibility(android.view.View.GONE);
                    } else {
                        tvHall.setVisibility(android.view.View.VISIBLE);
                        tvHall.setText(hallLine);
                    }
                }

                tvSpots.setText("Мест: " + session.getSpotsTaken() + "/" + session.getCapacity());

                if (adminMode) {
                    btnAction.setVisibility(android.view.View.GONE);
                    btnAction.setOnClickListener(null);
                    if (btnFavorite != null) {
                        btnFavorite.setVisibility(android.view.View.GONE);
                    }
                    if (rowTrainer != null) {
                        rowTrainer.setOnClickListener(null);
                        rowTrainer.setClickable(false);
                    }
                    if (tvMore != null) {
                        tvMore.setOnClickListener(v -> {
                            Intent i = new Intent(itemView.getContext(), SessionDetailActivity.class);
                            i.putExtra(SessionDetailActivity.EXTRA_SESSION, session);
                            i.putExtra(SessionDetailActivity.EXTRA_ADMIN_MODE, true);
                            itemView.getContext().startActivity(i);
                        });
                    }
                    return;
                }

                boolean trainerAccount = viewModel.isTrainerAccount();
                boolean isSignedUp = viewModel.isUserSignedUp(session.getId());
                boolean canCancel = ScheduleRepository.canCancelGroupSession(session.getStartTime());
                boolean ended = session.isGroupSessionEndedNow();
                boolean started = session.hasGroupSessionStartedNow();

                if (trainerAccount) {
                    btnAction.setVisibility(android.view.View.GONE);
                    btnAction.setOnClickListener(null);
                } else {
                    btnAction.setVisibility(android.view.View.VISIBLE);
                    if (ended) {
                        btnAction.setText(R.string.session_status_completed);
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else if (isSignedUp && started) {
                        btnAction.setText(R.string.session_status_in_progress);
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else if (session.isFull() && !isSignedUp) {
                        btnAction.setText("Мест нет");
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else if (isSignedUp && !canCancel) {
                        btnAction.setText("Отмена недоступна (<2ч)");
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else if (isSignedUp) {
                        btnAction.setText("Отменить запись");
                        btnAction.setEnabled(true);
                        btnAction.setOnClickListener(v -> viewModel.cancelSession(session.getId()));
                    } else if (started) {
                        btnAction.setText(R.string.session_signup_closed);
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else {
                        btnAction.setText("Записаться");
                        btnAction.setEnabled(true);
                        btnAction.setOnClickListener(v -> GroupSignupUiHelper.showSignupWarningThen(host, () -> {
                            host.pendingGroupPaymentSessionId = session.getId();
                            viewModel.signUpForSession(session.getId());
                        }));
                    }
                }

                if (tvMore != null) {
                    tvMore.setOnClickListener(v -> {
                        Intent i = new Intent(itemView.getContext(), SessionDetailActivity.class);
                        i.putExtra(SessionDetailActivity.EXTRA_SESSION, session);
                        itemView.getContext().startActivity(i);
                    });
                }

                if (btnFavorite != null && session.getId() != null && !adminMode) {
                    FavoritesRepository fr = FavoritesRepository.getInstance(itemView.getContext());
                    btnFavorite.setImageResource(fr.isSessionFavorite(session.getId())
                            ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                    btnFavorite.setOnClickListener(v -> {
                        fr.toggleSessionFavorite(session.getId());
                        btnFavorite.setImageResource(fr.isSessionFavorite(session.getId())
                                ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                    });
                }
            }
        }
    }
}

