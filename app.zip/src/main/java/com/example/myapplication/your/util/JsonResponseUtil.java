package com.example.myapplication.your.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class JsonResponseUtil {

    private JsonResponseUtil() {
    }

    public static JSONArray requireArray(String json) throws Exception {
        if (json == null || json.trim().isEmpty()) {
            return new JSONArray();
        }
        String t = json.trim();
        if ("null".equals(t)) {
            return new JSONArray();
        }
        if (t.charAt(0) == '{') {
            JSONObject o = new JSONObject(t);
            if (o.has("message") || o.has("code") || o.has("hint") || o.has("details")) {
                String msg = o.optString("message", "").trim();
                if (msg.isEmpty()) msg = o.optString("hint", "").trim();
                if (msg.isEmpty()) msg = o.optString("details", "").trim();
                if (msg.isEmpty()) msg = o.optString("code", "").trim();
                if (msg.isEmpty()) msg = "Ошибка сервера";
                throw new Exception(msg);
            }
            throw new Exception("Сервер вернул объект вместо списка данных");
        }
        try {
            return new JSONArray(t);
        } catch (JSONException e) {
            throw new Exception("Неверный формат ответа: " + e.getMessage());
        }
    }
}
