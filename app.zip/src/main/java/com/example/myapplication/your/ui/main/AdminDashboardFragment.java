package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;
import com.example.myapplication.your.ui.admin.AdminUsersActivity;

public class AdminDashboardFragment extends Fragment {

    public AdminDashboardFragment() {}

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_admin_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.card_admin_users).setOnClickListener(v ->
                startActivity(new Intent(requireContext(), AdminUsersActivity.class)));
        view.findViewById(R.id.card_admin_schedule).setOnClickListener(v -> {
            Intent i = new Intent(requireContext(), CalendarActivity.class);
            i.putExtra(CalendarActivity.EXTRA_ADMIN_MODE, true);
            startActivity(i);
        });
    }
}
