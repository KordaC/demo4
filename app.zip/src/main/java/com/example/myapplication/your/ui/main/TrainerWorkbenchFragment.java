package com.example.myapplication.your.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.ui.trainer.CreateSessionActivity;
import com.example.myapplication.your.model.TrainerPtRow;
import com.example.myapplication.your.model.TrainerWorkbenchListItem;
import com.example.myapplication.your.viewmodel.TrainerWorkbenchViewModel;

import java.util.ArrayList;
import java.util.List;

public class TrainerWorkbenchFragment extends Fragment {

    public TrainerWorkbenchFragment() {}

    private TrainerWorkbenchViewModel viewModel;
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView tvError;
    private TextView tvEmpty;
    private TrainerMixedAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_trainer_workbench, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(TrainerWorkbenchViewModel.class);
        recyclerView = view.findViewById(R.id.recycler_trainer_sessions);
        progressBar = view.findViewById(R.id.progress_trainer_bench);
        tvError = view.findViewById(R.id.tv_trainer_bench_error);
        tvEmpty = view.findViewById(R.id.tv_trainer_bench_empty);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new TrainerMixedAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        viewModel.getLoading().observe(getViewLifecycleOwner(), loading ->
                progressBar.setVisibility(Boolean.TRUE.equals(loading) ? View.VISIBLE : View.GONE));

        viewModel.getItemsUi().observe(getViewLifecycleOwner(), rows -> {
            List<TrainerWorkbenchListItem> list = rows != null ? rows : new ArrayList<>();
            adapter.update(list);
            boolean empty = list.isEmpty();
            tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
            if (!empty) {
                tvError.setVisibility(View.GONE);
            }
        });

        viewModel.getError().observe(getViewLifecycleOwner(), err -> {
            if (err != null && !err.isEmpty()) {
                tvError.setText(err);
                tvError.setVisibility(View.VISIBLE);
                Toast.makeText(requireContext(), err, Toast.LENGTH_LONG).show();
                viewModel.clearError();
            }
        });

        view.findViewById(R.id.fab_create_session).setOnClickListener(v ->
                startActivity(new Intent(requireContext(), CreateSessionActivity.class)));
    }

    @Override
    public void onResume() {
        super.onResume();
        viewModel.loadMyUpcomingSessions();
    }

    private class TrainerMixedAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private List<TrainerWorkbenchListItem> items = new ArrayList<>();

        TrainerMixedAdapter(List<TrainerWorkbenchListItem> items) {
            this.items = items != null ? items : new ArrayList<>();
        }

        void update(List<TrainerWorkbenchListItem> next) {
            this.items = next != null ? next : new ArrayList<>();
            notifyDataSetChanged();
        }

        @Override
        public int getItemViewType(int position) {
            return items.get(position).getType();
        }

        @NonNull
        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inf = LayoutInflater.from(parent.getContext());
            if (viewType == TrainerWorkbenchListItem.TYPE_PERSONAL) {
                View v = inf.inflate(R.layout.item_trainer_pt_card, parent, false);
                return new PtVH(v);
            }
            View v = inf.inflate(R.layout.item_trainer_group_card, parent, false);
            return new GroupVH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            TrainerWorkbenchListItem row = items.get(position);
            if (holder instanceof GroupVH) {
                ((GroupVH) holder).bind(row);
            } else if (holder instanceof PtVH) {
                ((PtVH) holder).bind(row.getPersonalRow());
            }
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class GroupVH extends RecyclerView.ViewHolder {
            TextView tvTitle;
            TextView tvTime;
            TextView tvDate;
            TextView tvTrainer;
            TextView tvClients;
            TextView tvSpots;
            View cardRoot;

            GroupVH(@NonNull View itemView) {
                super(itemView);
                cardRoot = itemView.findViewById(R.id.card_trainer_group_root);
                tvTitle = itemView.findViewById(R.id.tv_session_title);
                tvTime = itemView.findViewById(R.id.tv_session_time);
                tvDate = itemView.findViewById(R.id.tv_session_date);
                tvTrainer = itemView.findViewById(R.id.tv_session_trainer);
                tvClients = itemView.findViewById(R.id.tv_session_clients);
                tvSpots = itemView.findViewById(R.id.tv_session_spots);
            }

            void bind(TrainerWorkbenchListItem row) {
                Session session = row.getGroupSession();
                if (session == null) return;
                tvTitle.setText(session.getTitle());
                tvTime.setText(session.getFormattedTimeRange());
                tvDate.setText(session.getFormattedDateLine());
                if (session.getDirectionName() != null && !session.getDirectionName().trim().isEmpty()) {
                    tvTrainer.setText(itemView.getContext().getString(
                            R.string.trainer_bench_direction_fmt, session.getDirectionName()));
                } else {
                    tvTrainer.setText("");
                }
                tvClients.setText(row.getGroupClientsLine());
                tvSpots.setText(itemView.getContext().getString(
                        R.string.trainer_bench_spots_fmt, session.getSpotsTaken(), session.getCapacity()));

                cardRoot.setOnClickListener(v -> {
                    Intent i = new Intent(v.getContext(), SessionDetailActivity.class);
                    i.putExtra(SessionDetailActivity.EXTRA_SESSION, session);
                    v.getContext().startActivity(i);
                });
            }
        }

        class PtVH extends RecyclerView.ViewHolder {
            TextView tvTime;
            TextView tvDate;
            TextView tvClient;

            PtVH(@NonNull View itemView) {
                super(itemView);
                tvTime = itemView.findViewById(R.id.tv_pt_time);
                tvDate = itemView.findViewById(R.id.tv_pt_date);
                tvClient = itemView.findViewById(R.id.tv_pt_client);
            }

            void bind(TrainerPtRow row) {
                if (row == null) return;
                tvTime.setText(row.getFormattedTimeSlot());
                tvDate.setText(row.getFormattedDateOnly());
                tvClient.setText(itemView.getContext().getString(
                        R.string.trainer_bench_client_fmt, row.getClientName()));
            }
        }
    }
}
