package com.example.myapplication.your.data;

import android.content.Context;
import android.util.Log;

import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.util.AppUserDisplayName;
import com.example.myapplication.your.util.JsonResponseUtil;
import com.example.myapplication.your.util.TimestampParseUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
// Репозиторий для работы с расписанием групповых занятий
public class ScheduleRepository {
    private static final String TAG = "ScheduleRepository";
    private static ScheduleRepository instance;
    private final Context appContext;
    private final String supabaseUrl;
    private final String supabaseKey;
    private final MembershipRepository membershipRepository;

    private ScheduleRepository(Context context) {
        appContext = context.getApplicationContext();
        supabaseUrl = SupabaseClientProvider.getSupabaseUrl();
        supabaseKey = SupabaseClientProvider.getSupabaseAnonKey();
        membershipRepository = MembershipRepository.getInstance(context);
    }

    public static synchronized ScheduleRepository getInstance(Context context) {
        if (instance == null) {
            instance = new ScheduleRepository(context);
        }
        return instance;
    }

    // Формирует строку select для запросов с вложенными объектами (club, direction, trainer)
    private static String sessionSelectEncoded() {
        try {
            String sel = "*,club(name,address,description),training_direction(name,description),trainer_profile(photo_url,app_user(name,last_name))";
            return URLEncoder.encode(sel, StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return "*";
        }
    }
    // Проверяет, отсутствует ли тренер у занятия
    private static boolean isTrainerMissing(Session s) {
        if (s == null) return true;
        String id = s.getTrainerId();
        return id == null || id.trim().isEmpty() || "null".equalsIgnoreCase(id.trim());
    }
    // Фильтрует занятия без тренера
    private static List<Session> filterSessionsWithTrainer(List<Session> sessions) {
        if (sessions == null) return new ArrayList<>();
        List<Session> out = new ArrayList<>();
        for (Session s : sessions) {
            if (!isTrainerMissing(s)) out.add(s);
        }
        return out;
    }
    // Получает предстоящие занятия
    public List<Session> getUpcomingSessions() throws Exception {
        String nowIso = java.time.OffsetDateTime.now(java.time.ZoneOffset.UTC)
                .format(java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        String timeEnc = URLEncoder.encode(nowIso, StandardCharsets.UTF_8.name());
        try {
            String url = supabaseUrl + "/rest/v1/session?select=" + sessionSelectEncoded()
                    + "&start_time=gte." + timeEnc
                    + "&order=start_time.asc&limit=100";
            Log.d(TAG, "Request URL (embed): " + url);
            String jsonResponse = makeGetRequest(url);
            Log.d(TAG, "Response length: " + (jsonResponse != null ? jsonResponse.length() : 0));
            List<Session> out = parseUpcomingSessionsFromResponse(jsonResponse);
            if (jsonResponse != null && !jsonResponse.trim().isEmpty()) {
                UiDataCache.getInstance(appContext).putScheduleUpcomingRaw(jsonResponse);
            }
            return out;
        } catch (Exception e) {
            Log.w(TAG, "Session embed failed (HTTP или тело ошибки / парсинг), fallback select=*", e);
            String url = supabaseUrl + "/rest/v1/session?select=*"
                    + "&start_time=gte." + timeEnc
                    + "&order=start_time.asc&limit=100";
            String jsonResponse = makeGetRequest(url);
            Log.d(TAG, "Fallback response length: " + (jsonResponse != null ? jsonResponse.length() : 0));
            if (jsonResponse != null && !jsonResponse.trim().isEmpty()) {
                UiDataCache.getInstance(appContext).putScheduleUpcomingRaw(jsonResponse);
            }
            return parseUpcomingSessionsFromResponse(jsonResponse);
        }
    }
    // Получает предстоящие занятия из кэша
    public List<Session> getUpcomingSessionsFromCache() {
        try {
            String raw = UiDataCache.getInstance(appContext).getScheduleUpcomingRaw();
            if (raw == null || raw.trim().isEmpty()) return null;
            return parseUpcomingSessionsFromResponse(raw);
        } catch (Exception e) {
            Log.w(TAG, "getUpcomingSessionsFromCache", e);
            return null;
        }
    }
    // Парсит JSON-ответ в список занятий и фильтрует прошедшие
    private List<Session> parseUpcomingSessionsFromResponse(String jsonResponse) throws Exception {
        List<Session> sessions = new ArrayList<>();
        if (jsonResponse == null || jsonResponse.trim().isEmpty()) return sessions;
        JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
        for (int i = 0; i < jsonArray.length(); i++) {
            Session session = mapToSession(jsonArray.getJSONObject(i));
            sessions.add(session);
        }
        LocalDateTime now = LocalDateTime.now();
        Iterator<Session> it = sessions.iterator();
        while (it.hasNext()) {
            Session s = it.next();
            if (s.getStartTime() == null || !s.getStartTime().isAfter(now)) {
                it.remove();
            }
        }
        sessions = filterSessionsWithTrainer(sessions);
        enrichTrainerNamesForSessions(sessions);
        Log.d(TAG, "Parsed " + sessions.size() + " upcoming sessions (after local filter)");
        return sessions;
    }
    private void enrichTrainerNamesForSessions(List<Session> sessions) {
        if (sessions == null || sessions.isEmpty()) return;
        java.util.LinkedHashSet<String> trainerIds = new java.util.LinkedHashSet<>();
        for (Session s : sessions) {
            if (s == null) continue;
            String tid = s.getTrainerId();
            String tn = s.getTrainerName();
            if (tid == null) continue;
            String t = tid.trim();
            if (t.isEmpty() || "null".equalsIgnoreCase(t)) continue;
            if (tn == null || tn.trim().isEmpty() || "null".equalsIgnoreCase(tn.trim())) {
                trainerIds.add(t);
            }
        }
        if (trainerIds.isEmpty()) return;

        Map<String, String> nameByTrainerProfileId = new LinkedHashMap<>();
        Map<String, String> trainerProfileUserId = new LinkedHashMap<>();
        try {
            StringBuilder inB = new StringBuilder();
            for (String id : trainerIds) {
                if (inB.length() > 0) inB.append(',');
                inB.append(id);
            }
            String sel;
            try {
                sel = URLEncoder.encode("id,user_id,app_user(name,last_name)", StandardCharsets.UTF_8.name());
            } catch (Exception e) {
                sel = "*";
            }
            String url = supabaseUrl + "/rest/v1/trainer_profile?id=in.(" + inB + ")&select=" + sel;
            JSONArray arr = JsonResponseUtil.requireArray(makeGetRequest(url));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject row = arr.getJSONObject(i);
                String id = cleanJsonText(row, "id");
                if (id == null || id.trim().isEmpty()) continue;
                String uid = cleanJsonText(row, "user_id");
                if (uid != null && !uid.trim().isEmpty()) trainerProfileUserId.put(id, uid.trim());
                if (row.has("app_user") && !row.isNull("app_user")) {
                    JSONObject au = row.getJSONObject("app_user");
                    String dn = AppUserDisplayName.fromAppUserJson(au);
                    dn = cleanNullable(dn);
                    if (dn != null) nameByTrainerProfileId.put(id.trim(), dn);
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Batch trainer_profile embed failed; will fallback", e);
        }
        try {
            java.util.LinkedHashSet<String> missingTrainerIds = new java.util.LinkedHashSet<>();
            for (String tid : trainerIds) {
                if (!nameByTrainerProfileId.containsKey(tid)) missingTrainerIds.add(tid);
            }
            if (!missingTrainerIds.isEmpty()) {
                StringBuilder inB = new StringBuilder();
                for (String id : missingTrainerIds) {
                    if (inB.length() > 0) inB.append(',');
                    inB.append(id);
                }
                String sel;
                try {
                    sel = URLEncoder.encode("id,user_id", StandardCharsets.UTF_8.name());
                } catch (Exception e) {
                    sel = "id,user_id";
                }
                String url = supabaseUrl + "/rest/v1/trainer_profile?id=in.(" + inB + ")&select=" + sel;
                JSONArray arr = JsonResponseUtil.requireArray(makeGetRequest(url));
                java.util.LinkedHashSet<String> userIds = new java.util.LinkedHashSet<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject row = arr.getJSONObject(i);
                    String id = cleanJsonText(row, "id");
                    String uid = cleanJsonText(row, "user_id");
                    if (id != null && uid != null && !id.trim().isEmpty() && !uid.trim().isEmpty()) {
                        trainerProfileUserId.put(id.trim(), uid.trim());
                        userIds.add(uid.trim());
                    }
                }
                if (!userIds.isEmpty()) {
                    StringBuilder uIn = new StringBuilder();
                    for (String uid : userIds) {
                        if (uIn.length() > 0) uIn.append(',');
                        uIn.append(uid);
                    }
                    String uSel;
                    try {
                        uSel = URLEncoder.encode("id,name,last_name", StandardCharsets.UTF_8.name());
                    } catch (Exception e) {
                        uSel = "id,name,last_name";
                    }
                    String uUrl = supabaseUrl + "/rest/v1/app_user?id=in.(" + uIn + ")&select=" + uSel;
                    JSONArray uArr = JsonResponseUtil.requireArray(makeGetRequest(uUrl));
                    Map<String, String> nameByUserId = new LinkedHashMap<>();
                    for (int i = 0; i < uArr.length(); i++) {
                        JSONObject row = uArr.getJSONObject(i);
                        String uid = cleanJsonText(row, "id");
                        if (uid == null || uid.trim().isEmpty()) continue;
                        String dn = AppUserDisplayName.fromAppUserJson(row);
                        dn = cleanNullable(dn);
                        if (dn != null) nameByUserId.put(uid.trim(), dn);
                    }
                    for (Map.Entry<String, String> e : trainerProfileUserId.entrySet()) {
                        String tid = e.getKey();
                        if (nameByTrainerProfileId.containsKey(tid)) continue;
                        String dn = nameByUserId.get(e.getValue());
                        if (dn != null) nameByTrainerProfileId.put(tid, dn);
                    }
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Batch trainer_profile plain/app_user fallback failed", e);
        }
        try {
            java.util.LinkedHashSet<String> directUserIds = new java.util.LinkedHashSet<>();
            for (String tid : trainerIds) {
                if (!nameByTrainerProfileId.containsKey(tid)) directUserIds.add(tid);
            }
            if (!directUserIds.isEmpty()) {
                StringBuilder uIn = new StringBuilder();
                for (String uid : directUserIds) {
                    if (uIn.length() > 0) uIn.append(',');
                    uIn.append(uid);
                }
                String uSel;
                try {
                    uSel = URLEncoder.encode("id,name,last_name", StandardCharsets.UTF_8.name());
                } catch (Exception e) {
                    uSel = "id,name,last_name";
                }
                String uUrl = supabaseUrl + "/rest/v1/app_user?id=in.(" + uIn + ")&select=" + uSel;
                JSONArray uArr = JsonResponseUtil.requireArray(makeGetRequest(uUrl));
                for (int i = 0; i < uArr.length(); i++) {
                    JSONObject row = uArr.getJSONObject(i);
                    String uid = cleanJsonText(row, "id");
                    if (uid == null || uid.trim().isEmpty()) continue;
                    String dn = AppUserDisplayName.fromAppUserJson(row);
                    dn = cleanNullable(dn);
                    if (dn != null) nameByTrainerProfileId.put(uid.trim(), dn);
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Batch app_user direct fallback failed", e);
        }

        for (Session s : sessions) {
            if (s == null) continue;
            String tid = s.getTrainerId();
            if (tid == null) continue;
            String dn = nameByTrainerProfileId.get(tid.trim());
            if (dn != null && !dn.trim().isEmpty()) {
                s.setTrainerName(dn.trim());
            }
        }
    }
    // Получает занятия по списку ID
    public List<Session> getSessionsByIds(List<String> sessionIds) throws Exception {
        if (sessionIds == null || sessionIds.isEmpty()) {
            return new ArrayList<>();
        }
        StringBuilder inClause = new StringBuilder();
        for (String raw : sessionIds) {
            if (raw == null) continue;
            String id = raw.trim();
            if (id.isEmpty()) continue;
            if (inClause.length() > 0) inClause.append(',');
            inClause.append(id);
        }
        if (inClause.length() == 0) {
            return new ArrayList<>();
        }
        String jsonResponse;
        try {
            String url = supabaseUrl + "/rest/v1/session?select=" + sessionSelectEncoded()
                    + "&id=in.(" + inClause + ")&order=start_time.desc";
            jsonResponse = makeGetRequest(url);
            List<Session> out = new ArrayList<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) return out;
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                out.add(mapToSession(jsonArray.getJSONObject(i)));
            }
            return filterSessionsWithTrainer(out);
        } catch (Exception e) {
            Log.w(TAG, "getSessionsByIds embed failed, fallback *", e);
            String url = supabaseUrl + "/rest/v1/session?select=*"
                    + "&id=in.(" + inClause + ")&order=start_time.desc";
            jsonResponse = makeGetRequest(url);
            List<Session> out = new ArrayList<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) return out;
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                out.add(mapToSession(jsonArray.getJSONObject(i)));
            }
            return filterSessionsWithTrainer(out);
        }
    }
    // Получает занятие по ID
    public Session getSessionById(String sessionId) throws Exception {
        if (sessionId == null || sessionId.isEmpty()) return null;
        try {
            String url = supabaseUrl + "/rest/v1/session?id=eq." + sessionId + "&select=" + sessionSelectEncoded();
            String jsonResponse = makeGetRequest(url);
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            if (jsonArray.length() == 0) return null;
            return mapToSession(jsonArray.getJSONObject(0));
        } catch (Exception e) {
            Log.w(TAG, "getSessionById embed failed, fallback *", e);
            String url = supabaseUrl + "/rest/v1/session?id=eq." + sessionId + "&select=*";
            String jsonResponse = makeGetRequest(url);
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            if (jsonArray.length() == 0) return null;
            return mapToSession(jsonArray.getJSONObject(0));
        }
    }
    // Проверяет, можно ли отменить групповое занятие
    public static boolean canCancelGroupSession(LocalDateTime startTime) {
        if (startTime == null) return false;
        return LocalDateTime.now().isBefore(startTime.minusHours(2));
    }
    // Получает занятия на конкретную дату
    public List<Session> getSessionsForDate(LocalDate date) throws Exception {
        String dayStart = date.atStartOfDay().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        String dayEnd = date.plusDays(1).atStartOfDay().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        String sel = sessionSelectEncoded();
        String urlEmbed = supabaseUrl + "/rest/v1/session"
                + "?select=" + sel
                + "&start_time=gte." + dayStart
                + "&start_time=lt." + dayEnd
                + "&order=start_time.asc";
        String urlPlain = supabaseUrl + "/rest/v1/session"
                + "?select=*"
                + "&start_time=gte." + dayStart
                + "&start_time=lt." + dayEnd
                + "&order=start_time.asc";
        String jsonResponse;
        try {
            jsonResponse = makeGetRequest(urlEmbed);
            List<Session> sessions = new ArrayList<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) return sessions;
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                sessions.add(mapToSession(jsonArray.getJSONObject(i)));
            }
            return filterSessionsWithTrainer(sessions);
        } catch (Exception e) {
            Log.w(TAG, "getSessionsForDate embed failed, fallback *", e);
            jsonResponse = makeGetRequest(urlPlain);
            List<Session> sessions = new ArrayList<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) return sessions;
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                sessions.add(mapToSession(jsonArray.getJSONObject(i)));
            }
            return filterSessionsWithTrainer(sessions);
        }
    }
    // Получает занятия конкретного тренера на дату
    public List<Session> getSessionsForTrainerOnDate(String trainerProfileId, LocalDate date) throws Exception {
        if (trainerProfileId == null || trainerProfileId.trim().isEmpty()) {
            return new ArrayList<>();
        }
        String dayStart = date.atStartOfDay().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        String dayEnd = date.plusDays(1).atStartOfDay().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        String sel = sessionSelectEncoded();
        String urlEmbed = supabaseUrl + "/rest/v1/session"
                + "?select=" + sel
                + "&trainer_id=eq." + trainerProfileId.trim()
                + "&start_time=gte." + dayStart
                + "&start_time=lt." + dayEnd
                + "&order=start_time.asc";
        String urlPlain = supabaseUrl + "/rest/v1/session"
                + "?select=*"
                + "&trainer_id=eq." + trainerProfileId.trim()
                + "&start_time=gte." + dayStart
                + "&start_time=lt." + dayEnd
                + "&order=start_time.asc";
        String jsonResponse;
        try {
            jsonResponse = makeGetRequest(urlEmbed);
            List<Session> sessions = new ArrayList<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) return sessions;
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                sessions.add(mapToSession(jsonArray.getJSONObject(i)));
            }
            return filterSessionsWithTrainer(sessions);
        } catch (Exception e) {
            Log.w(TAG, "Trainer day embed select failed, fallback *", e);
            jsonResponse = makeGetRequest(urlPlain);
            List<Session> sessions = new ArrayList<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) return sessions;
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                sessions.add(mapToSession(jsonArray.getJSONObject(i)));
            }
            return filterSessionsWithTrainer(sessions);
        }
    }
    // Получает предстоящие занятия тренера// Получает предстоящие занятия тренера
    public List<Session> getUpcomingSessionsForTrainer(String trainerProfileId, int limit) throws Exception {
        if (trainerProfileId == null || trainerProfileId.trim().isEmpty()) {
            return new ArrayList<>();
        }
        String nowIso = java.time.OffsetDateTime.now(java.time.ZoneOffset.UTC)
                .format(java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME);
        String lim = limit > 0 ? String.valueOf(limit) : "100";
        String timeEnc = URLEncoder.encode(nowIso, StandardCharsets.UTF_8.name());
        String jsonResponse;
        try {
            String url = supabaseUrl + "/rest/v1/session?select=" + sessionSelectEncoded()
                    + "&trainer_id=eq." + trainerProfileId.trim()
                    + "&start_time=gte." + timeEnc
                    + "&order=start_time.asc&limit=" + lim;
            jsonResponse = makeGetRequest(url);
            List<Session> sessions = new ArrayList<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) return sessions;
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                sessions.add(mapToSession(jsonArray.getJSONObject(i)));
            }
            return sessions;
        } catch (Exception e) {
            Log.w(TAG, "Trainer session embed select failed, fallback to *", e);
            String url = supabaseUrl + "/rest/v1/session?select=*"
                    + "&trainer_id=eq." + trainerProfileId.trim()
                    + "&start_time=gte." + timeEnc
                    + "&order=start_time.asc&limit=" + lim;
            jsonResponse = makeGetRequest(url);
            List<Session> sessions = new ArrayList<>();
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) return sessions;
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                sessions.add(mapToSession(jsonArray.getJSONObject(i)));
            }
            return sessions;
        }
    }

    public Map<String, List<String>> getSignupDisplayNamesBySessionIds(List<String> sessionIds) throws Exception {
        Map<String, List<String>> out = new LinkedHashMap<>();
        if (sessionIds == null || sessionIds.isEmpty()) return out;
        StringBuilder inClause = new StringBuilder();
        for (String raw : sessionIds) {
            if (raw == null) continue;
            String id = raw.trim();
            if (id.isEmpty()) continue;
            if (inClause.length() > 0) inClause.append(',');
            inClause.append(id);
        }
        if (inClause.length() == 0) return out;
        String url = supabaseUrl + "/rest/v1/session_signup?session_id=in.(" + inClause + ")&select=session_id,user_id";
        String jsonResponse = makeGetRequest(url);
        if (jsonResponse == null || jsonResponse.trim().isEmpty()) return out;
        JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
        LinkedHashSet<String> userIds = new LinkedHashSet<>();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            String uid = o.optString("user_id", "").trim();
            if (!uid.isEmpty()) userIds.add(uid);
        }
        Map<String, String> idToName = fetchAppUserNamesByIds(new ArrayList<>(userIds));
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            String sid = o.optString("session_id", "").trim();
            if (sid.isEmpty()) continue;
            String uid = o.optString("user_id", "").trim();
            String name = idToName.get(uid);
            if (name == null || name.isEmpty()) {
                name = "Клиент";
            }
            if (!out.containsKey(sid)) {
                out.put(sid, new ArrayList<>());
            }
            out.get(sid).add(name);
        }
        return out;
    }

    private Map<String, String> fetchAppUserNamesByIds(List<String> userIds) throws Exception {
        Map<String, String> out = new LinkedHashMap<>();
        if (userIds == null || userIds.isEmpty()) return out;
        final int chunk = 40;
        for (int start = 0; start < userIds.size(); start += chunk) {
            int end = Math.min(start + chunk, userIds.size());
            StringBuilder inB = new StringBuilder();
            for (int i = start; i < end; i++) {
                if (inB.length() > 0) inB.append(',');
                inB.append(userIds.get(i).trim());
            }
            String url = supabaseUrl + "/rest/v1/app_user?id=in.(" + inB + ")&select=id,name,last_name";
            String jsonResponse = makeGetRequest(url);
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) continue;
            JSONArray rows = JsonResponseUtil.requireArray(jsonResponse);
            for (int j = 0; j < rows.length(); j++) {
                JSONObject row = rows.getJSONObject(j);
                String id = row.optString("id", "").trim();
                if (id.isEmpty()) continue;
                String name = AppUserDisplayName.fromAppUserJson(row);
                out.put(id, name);
            }
        }
        return out;
    }
    // Получает занятия, на которые записан пользователь

    public List<Session> getUserSessions(String userId) throws Exception {
        if (userId == null || userId.trim().isEmpty()) {
            return new ArrayList<>();
        }
        try {
            String url = supabaseUrl + "/rest/v1/session_signup?user_id=eq." + userId + "&select=*,session(*)";
            String jsonResponse = makeGetRequest(url);
            List<Session> sessions = new ArrayList<>();
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                if (obj.has("session") && !obj.isNull("session")) {
                    JSONObject sessionObj = obj.getJSONObject("session");
                    sessions.add(mapToSession(sessionObj));
                }
            }
            return sessions;
        } catch (Exception embedErr) {
            // Fallback: без embed (работает даже если FK/relationship не настроены в PostgREST)
            String url = supabaseUrl + "/rest/v1/session_signup?user_id=eq." + userId + "&select=session_id";
            String jsonResponse = makeGetRequest(url);
            JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
            List<String> ids = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                String sid = o.optString("session_id", "").trim();
                if (!sid.isEmpty()) ids.add(sid);
            }
            return getSessionsByIds(ids);
        }
    }

    private static boolean isDuplicateSignupConflict(Exception e) {
        if (e == null) return false;
        String m = e.getMessage();
        if (m == null) return false;
        String u = m.toUpperCase(Locale.US);
        return u.contains("409") || u.contains("23505") || u.contains("DUPLICATE");
    }
    // Запись на групповое занятие
    public String signUpForSession(String userId, String sessionId) {
        try {
            Session session = getSessionById(sessionId);
            if (session == null || session.getStartTime() == null) {
                return "Занятие не найдено.";
            }
            if (session.isGroupSessionEndedNow()) {
                return "Занятие уже завершилось.";
            }
            if (session.hasGroupSessionStartedNow()) {
                return "Запись недоступна: занятие уже началось.";
            }
            boolean usedPaidMarker = membershipRepository.hasPaidGroupSession(userId, sessionId.trim());
            String quotaErr = membershipRepository.validateGroupSignupEligibility(userId, session);
            if (quotaErr != null) {
                return quotaErr;
            }
            JSONObject data = new JSONObject();
            data.put("user_id", userId);
            data.put("session_id", sessionId);
            String url = supabaseUrl + "/rest/v1/session_signup";
            boolean insertedNew = false;
            try {
                makePostRequest(url, data.toString());
                insertedNew = true;
            } catch (Exception e) {
                if (isDuplicateSignupConflict(e)) {
                    insertedNew = false;
                } else {
                    throw e;
                }
            }
            if (insertedNew) {
                membershipRepository.finalizeGroupSignupAfterInsert(userId, session, true, usedPaidMarker);
                membershipRepository.clearPaidGroupSessionAfterSuccessfulSignup(userId, sessionId);
            }
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error signing up for session", e);
            return "Не удалось записаться: " + (e.getMessage() != null ? e.getMessage() : e.toString());
        }
    }
    // Отмена записи на групповое занятие
    public String cancelSession(String userId, String sessionId) {
        try {
            Session s = getSessionById(sessionId);
            if (s == null || s.getStartTime() == null) {
                return "Занятие не найдено.";
            }
            if (!canCancelGroupSession(s.getStartTime())) {
                return "Отмена менее чем за 2 часа до начала невозможна.";
            }
            String url = supabaseUrl + "/rest/v1/session_signup?user_id=eq." + userId + "&session_id=eq." + sessionId;
            makeDeleteRequest(url);
            membershipRepository.restoreGroupVisitAfterGroupCancel(userId);
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error canceling session", e);
            return "Ошибка отмены: " + (e.getMessage() != null ? e.getMessage() : e.toString());
        }
    }


    public boolean isUserSignedUp(String userId, String sessionId) {
        try {
            String url = supabaseUrl + "/rest/v1/session_signup?user_id=eq." + userId + "&session_id=eq." + sessionId;
            String jsonResponse = makeGetRequest(url);
            JSONArray jsonArray = JsonResponseUtil.requireArray(jsonResponse);
            return jsonArray.length() > 0;
        } catch (Exception e) {
            Log.e(TAG, "Error checking signup", e);
            return false;
        }
    }

    public java.util.Set<String> getUserSignedUpSessionIds(String userId) {
        java.util.Set<String> ids = new java.util.HashSet<>();
        try {
            if (userId == null || userId.trim().isEmpty()) return ids;
            String url = supabaseUrl + "/rest/v1/session_signup?user_id=eq." + userId + "&select=session_id";
            String jsonResponse = makeGetRequest(url);
            if (jsonResponse == null || jsonResponse.trim().isEmpty()) return ids;
            JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String sid = obj.optString("session_id", null);
                if (sid != null && !sid.trim().isEmpty()) ids.add(sid);
            }
        } catch (Exception e) {
            Log.e(TAG, "getUserSignedUpSessionIds", e);
        }
        return ids;
    }

    private String getTrainerName(String trainerId) {
        if (trainerId == null) return null;
        String tid = trainerId.trim();
        if (tid.isEmpty() || "null".equalsIgnoreCase(tid)) return null;

        // 1) Пытаемся trainer_profile с embed app_user (может вернуть HTTP 200 + JSON-объект ошибки).
        try {
            String sel;
            try {
                sel = URLEncoder.encode("user_id,app_user(name,last_name)", StandardCharsets.UTF_8.name());
            } catch (Exception e) {
                sel = "user_id,app_user";
            }
            String url = supabaseUrl + "/rest/v1/trainer_profile?id=eq." + tid + "&select=" + sel + "&limit=1";
            String jsonResponse = makeGetRequest(url);
            JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
            if (arr.length() > 0) {
                JSONObject trainerObj = arr.getJSONObject(0);
                if (trainerObj.has("app_user") && !trainerObj.isNull("app_user")) {
                    JSONObject userObj = trainerObj.getJSONObject("app_user");
                    String dn = AppUserDisplayName.fromAppUserJson(userObj);
                    dn = cleanNullable(dn);
                    if (dn != null) return dn;
                }
                String userId = cleanJsonText(trainerObj, "user_id");
                String dn = loadAppUserDisplayNameById(userId);
                if (dn != null) return dn;
            }
        } catch (Exception e) {
            Log.w(TAG, "trainer_profile embed name failed, fallback to plain", e);
        }

        try {
            String sel;
            try {
                sel = URLEncoder.encode("user_id", StandardCharsets.UTF_8.name());
            } catch (Exception e) {
                sel = "user_id";
            }
            String url = supabaseUrl + "/rest/v1/trainer_profile?id=eq." + tid + "&select=" + sel + "&limit=1";
            String jsonResponse = makeGetRequest(url);
            JSONArray arr = JsonResponseUtil.requireArray(jsonResponse);
            if (arr.length() > 0) {
                JSONObject trainerObj = arr.getJSONObject(0);
                String userId = cleanJsonText(trainerObj, "user_id");
                String dn = loadAppUserDisplayNameById(userId);
                if (dn != null) return dn;
            }
        } catch (Exception e) {
            Log.w(TAG, "trainer_profile plain name failed", e);
        }

        try {
            String dn = loadAppUserDisplayNameById(tid);
            if (dn != null) return dn;
        } catch (Exception e) {
            Log.w(TAG, "app_user direct name failed", e);
        }
        return null;
    }

    private String loadAppUserDisplayNameById(String userId) throws Exception {
        String uid = userId != null ? userId.trim() : "";
        if (uid.isEmpty() || "null".equalsIgnoreCase(uid)) return null;
        String uSel;
        try {
            uSel = URLEncoder.encode("id,name,last_name", StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            uSel = "id,name,last_name";
        }
        String uUrl = supabaseUrl + "/rest/v1/app_user?id=eq." + uid + "&select=" + uSel + "&limit=1";
        String uJson = makeGetRequest(uUrl);
        JSONArray uArr = JsonResponseUtil.requireArray(uJson);
        if (uArr.length() == 0) return null;
        JSONObject uObj = uArr.getJSONObject(0);
        String dn = AppUserDisplayName.fromAppUserJson(uObj);
        return cleanNullable(dn);
    }

    private static String cleanJsonText(JSONObject json, String key) {
        try {
            if (json == null || !json.has(key) || json.isNull(key)) return null;
            String s = json.optString(key, "");
            s = s.trim();
            if (s.isEmpty() || "null".equalsIgnoreCase(s)) return null;
            return s;
        } catch (Exception e) {
            return null;
        }
    }

    private static String cleanNullable(String s) {
        if (s == null) return null;
        String t = s.trim();
        if (t.isEmpty() || "null".equalsIgnoreCase(t)) return null;
        return s;
    }
    // Преобразует JSON в объект Session
    private Session mapToSession(JSONObject json) {
        Session session = new Session();
        session.setId(json.optString("id"));
        session.setClubId(json.optString("club_id"));
        session.setDirectionId(json.optString("direction_id"));
        session.setTrainerId(json.optString("trainer_id"));
        session.setTitle(cleanJsonText(json, "title"));
        // Парсим данные тренера из вложенного объекта
        if (json.has("trainer_profile") && !json.isNull("trainer_profile")) {
            try {
                JSONObject trainerObj = json.getJSONObject("trainer_profile");
                session.setTrainerPhotoUrl(cleanJsonText(trainerObj, "photo_url"));
                if (trainerObj.has("app_user") && !trainerObj.isNull("app_user")) {
                    JSONObject userObj = trainerObj.getJSONObject("app_user");
                    String dn = AppUserDisplayName.fromAppUserJson(userObj);
                    session.setTrainerName(cleanNullable(dn));
                } else if (trainerObj.has("name")) {
                    session.setTrainerName(cleanJsonText(trainerObj, "name"));
                }
            } catch (Exception e) {
                Log.e(TAG, "Error parsing trainer name", e);
            }
        }
        // Парсим время начала и окончания
        String startTimeStr = json.optString("start_time");
        String endTimeStr = json.optString("end_time");
        if (startTimeStr != null && !startTimeStr.isEmpty()) {
            LocalDateTime st = TimestampParseUtil.parseSupabaseTimestampToLocal(startTimeStr);
            if (st != null) {
                session.setStartTime(st);
            } else {
                Log.e(TAG, "Error parsing start_time: " + startTimeStr);
            }
        }
        if (endTimeStr != null && !endTimeStr.isEmpty()) {
            LocalDateTime et = TimestampParseUtil.parseSupabaseTimestampToLocal(endTimeStr);
            if (et != null) {
                session.setEndTime(et);
            } else {
                Log.e(TAG, "Error parsing end_time: " + endTimeStr);
            }
        }

        session.setCapacity(json.optInt("capacity", 20));
        session.setSpotsTaken(json.optInt("spots_taken", 0));

        session.setFree(json.optBoolean("is_free", false));
        if (json.has("price") && !json.isNull("price")) {
            try {
                session.setPrice(java.math.BigDecimal.valueOf(json.optDouble("price")));
            } catch (Exception ignored) {
                session.setPrice(null);
            }
        }

        session.setDescription(cleanJsonText(json, "description"));
        session.setLevel(cleanJsonText(json, "level"));
        session.setHallNumber(cleanJsonText(json, "hall_number"));
        session.setImageUrl(cleanJsonText(json, "image_url"));
        // Парсим данные клуба
        try {
            if (json.has("club") && !json.isNull("club")) {
                JSONObject c = json.getJSONObject("club");
                session.setHallName(cleanJsonText(c, "name"));
                session.setHallAddress(cleanJsonText(c, "address"));
                if (session.getDescription() == null || session.getDescription().isEmpty()) {
                    String cd = cleanJsonText(c, "description");
                    if (cd != null && !cd.isEmpty()) session.setDescription(cd);
                }
            }
        } catch (Exception e) {
            Log.d(TAG, "club embed", e);
        }
        // Парсим данные направления тренировки
        try {
            if (json.has("training_direction") && !json.isNull("training_direction")) {
                JSONObject d = json.getJSONObject("training_direction");
                String dn = cleanJsonText(d, "name");
                if (dn != null && !dn.isEmpty()) {
                    session.setDirectionName(dn);
                }
                session.setDirectionDescription(cleanJsonText(d, "description"));
            }
        } catch (Exception e) {
            Log.d(TAG, "training_direction embed", e);
        }

        if (session.getDescription() == null || session.getDescription().isEmpty()) {
            session.setDescription(session.getDirectionDescription());
        }

        session.setTrainerName(cleanNullable(session.getTrainerName()));
        if (session.getTitle() == null || session.getTitle().isEmpty()) {
            session.setTitle("Занятие");
        }

        normalizeSessionTimes(session);
        return session;
    }

    private static void normalizeSessionTimes(Session session) {
        LocalDateTime st = session.getStartTime();
        LocalDateTime en = session.getEndTime();
        if (st == null) {
            return;
        }
        if (en == null) {
            session.setEndTime(st.plusHours(1));
            return;
        }
        if (!en.isAfter(st)) {
            session.setEndTime(st.plusHours(1));
        }
    }

    private static String readHttpBody(HttpURLConnection conn, int responseCode) throws IOException {
        InputStream stream = responseCode >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        return sb.toString();
    }
    // HTTP GET запрос с anon-ключом
    private String makeGetRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");

        int responseCode = conn.getResponseCode();
        Log.d(TAG, "GET " + urlString + " -> " + responseCode);
        
        if (responseCode >= 400) {
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8));
            StringBuilder errorResponse = new StringBuilder();
            String line;
            while ((line = errorReader.readLine()) != null) {
                errorResponse.append(line);
            }
            errorReader.close();
            throw new Exception("HTTP " + responseCode + ": " + errorResponse.toString());
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        return response.toString();
    }
    // HTTP POST запрос
    private void makePostRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int responseCode = conn.getResponseCode();
        String body = readHttpBody(conn, responseCode);
        Log.d(TAG, "POST " + urlString + " -> " + responseCode);
        if (responseCode >= 400) {
            throw new Exception("HTTP " + responseCode + ": " + body);
        }
    }
    // HTTP PATCH запрос
    private void makePatchRequest(String urlString, String jsonData) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("PATCH");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonData.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int responseCode = conn.getResponseCode();
        String body = readHttpBody(conn, responseCode);
        Log.d(TAG, "PATCH " + urlString + " -> " + responseCode);
        if (responseCode >= 400) {
            throw new Exception("HTTP " + responseCode + ": " + body);
        }
    }
    // HTTP DELETE запрос
    private void makeDeleteRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("DELETE");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + supabaseKey);
        int responseCode = conn.getResponseCode();
        String body = readHttpBody(conn, responseCode);
        Log.d(TAG, "DELETE " + urlString + " -> " + responseCode);
        if (responseCode >= 400 && responseCode != 404) {
            throw new Exception("HTTP " + responseCode + ": " + body);
        }
    }

    public static final class PickItem {
        public final String id;
        public final String name;

        public PickItem(String id, String name) {
            this.id = id != null ? id : "";
            this.name = name != null ? name : "";
        }
    }

    public List<PickItem> listTrainerProfilesForPicker() throws Exception {
        String sel;
        try {
            sel = URLEncoder.encode("id,app_user(name)", StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            sel = "id";
        }
        String url = supabaseUrl + "/rest/v1/trainer_profile?select=" + sel + "&order=id.asc&limit=500";
        String json;
        try {
            json = makeGetRequest(url);
        } catch (Exception e) {
            String token = SharedPrefManager.getInstance(appContext).getAccessToken();
            if (token == null || token.trim().isEmpty()) throw e;
            json = makeGetRequestAsUser(url, token.trim());
        }
        List<PickItem> out = new ArrayList<>();
        if (json == null || json.trim().isEmpty() || "[]".equals(json.trim())) return out;
        JSONArray arr = JsonResponseUtil.requireArray(json);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            String id = o.optString("id");
            if (id.isEmpty()) continue;
            String name = "Тренер";
            if (o.has("app_user") && !o.isNull("app_user")) {
                JSONObject au = o.getJSONObject("app_user");
                String n = au.optString("name", "").trim();
                if (!n.isEmpty()) name = n;
            }
            out.add(new PickItem(id, name));
        }
        return out;
    }

    public List<PickItem> listClubs() throws Exception {
        String url = supabaseUrl + "/rest/v1/club?select=id,name&order=name.asc&limit=500";
        String json;
        try {
            json = makeGetRequest(url);
        } catch (Exception e) {
            String token = SharedPrefManager.getInstance(appContext).getAccessToken();
            if (token == null || token.trim().isEmpty()) throw e;
            json = makeGetRequestAsUser(url, token.trim());
        }
        List<PickItem> out = new ArrayList<>();
        if (json == null || json.trim().isEmpty() || "[]".equals(json.trim())) return out;
        JSONArray arr = JsonResponseUtil.requireArray(json);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            String id = o.optString("id");
            String name = o.optString("name");
            if (!id.isEmpty()) {
                out.add(new PickItem(id, name.isEmpty() ? id : name));
            }
        }
        return out;
    }

    public Session createTrainerGroupSession(
            String accessToken,
            String trainerProfileId,
            String clubId,
            String directionId,
            String title,
            LocalDateTime startLocal,
            LocalDateTime endLocal,
            int capacity,
            boolean isFree,
            java.math.BigDecimal price,
            String description,
            String hallNumber,
            String level,
            String imageUrl
    ) throws Exception {
        if (accessToken == null || accessToken.trim().isEmpty()) throw new Exception("Нет сессии.");
        if (trainerProfileId == null || trainerProfileId.trim().isEmpty()) {
            throw new Exception("Нет профиля тренера.");
        }
        if (clubId == null || clubId.trim().isEmpty()) throw new Exception("Выберите клуб.");
        if (directionId == null || directionId.trim().isEmpty()) throw new Exception("Выберите направление.");
        String t = title != null ? title.trim() : "";
        if (t.isEmpty()) t = "Занятие";
        if (capacity < 1) capacity = 10;
        if (startLocal == null) throw new Exception("Укажите дату и время начала.");
        LocalDateTime end = endLocal;
        if (end == null || !end.isAfter(startLocal)) {
            end = startLocal.plusHours(1);
        }
        JSONObject data = new JSONObject();
        data.put("club_id", clubId.trim());
        data.put("direction_id", directionId.trim());
        data.put("trainer_id", trainerProfileId.trim());
        data.put("title", t);
        data.put("start_time", localDateTimeToUtcIso(startLocal));
        data.put("end_time", localDateTimeToUtcIso(end));
        data.put("capacity", capacity);
        data.put("spots_taken", 0);
        data.put("is_free", isFree);
        if (!isFree && price != null && price.signum() > 0) {
            data.put("price", price.doubleValue());
        }
        if (description != null && !description.trim().isEmpty()) {
            data.put("description", description.trim());
        }
        if (hallNumber != null && !hallNumber.trim().isEmpty()) {
            data.put("hall_number", hallNumber.trim());
        }
        if (level != null && !level.trim().isEmpty()) {
            data.put("level", level.trim());
        }
        if (imageUrl != null && !imageUrl.trim().isEmpty() && imageUrl.trim().startsWith("http")) {
            data.put("image_url", imageUrl.trim());
        }
        String url = supabaseUrl + "/rest/v1/session";
        String body = makePostRequestAsUser(url, data.toString(), accessToken.trim());
        JSONArray arr = JsonResponseUtil.requireArray(body);
        if (arr.length() == 0) throw new Exception("Пустой ответ сервера.");
        return mapToSession(arr.getJSONObject(0));
    }

    private static String localDateTimeToUtcIso(LocalDateTime ldt) {
        ZonedDateTime z = ZonedDateTime.of(ldt, ZoneId.systemDefault()).withZoneSameInstant(ZoneOffset.UTC);
        return z.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }

    private String makeGetRequestAsUser(String urlString, String accessToken) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        conn.setRequestProperty("Accept", "application/json");
        int responseCode = conn.getResponseCode();
        String body = readHttpBody(conn, responseCode);
        Log.d(TAG, "GET(user) " + urlString + " -> " + responseCode);
        if (responseCode >= 400) {
            throw new Exception("HTTP " + responseCode + ": " + body);
        }
        return body;
    }

    private String makePostRequestAsUser(String urlString, String jsonData, String accessToken) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("apikey", supabaseKey);
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Prefer", "return=representation");
        conn.setDoOutput(true);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonData.getBytes(StandardCharsets.UTF_8));
        }
        int responseCode = conn.getResponseCode();
        String body = readHttpBody(conn, responseCode);
        Log.d(TAG, "POST(user) " + urlString + " -> " + responseCode);
        if (responseCode >= 400) {
            throw new Exception("HTTP " + responseCode + ": " + body);
        }
        return body;
    }
}
