package com.example.myapplication.your.ui.auth;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.datepicker.MaterialDatePicker;

import com.example.myapplication.R;
import com.example.myapplication.your.util.ValidationUtils;
import com.example.myapplication.your.viewmodel.AuthViewModel;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Locale;
// Экран регистрации нового пользователя
public class RegisterFragment extends Fragment {
    private AuthViewModel viewModel;
    private RegisterListener listener;

    public interface RegisterListener {
        void onRegisterSuccess();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof RegisterListener) listener = (RegisterListener) context;
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_register, container, false);
    }

    private com.google.android.material.textfield.TextInputEditText etName, etSurname, etPatronymic, etBirthDate, etEmail, etPhone, etPass, etPassConfirm;
    private ProgressBar progressBar;
    private String birthDateIso = "";

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        etName = view.findViewById(R.id.etName);
        etSurname = view.findViewById(R.id.etSurname);
        etPatronymic = view.findViewById(R.id.etPatronymic);
        etBirthDate = view.findViewById(R.id.etBirthDate);
        etEmail = view.findViewById(R.id.etEmail);
        etPhone = view.findViewById(R.id.etPhone);
        etPass = view.findViewById(R.id.etPassword);
        etPassConfirm = view.findViewById(R.id.etPasswordConfirm);
        progressBar = view.findViewById(R.id.progressBar);

        viewModel = new ViewModelProvider(requireActivity()).get(AuthViewModel.class);

        AuthViewModel.RegisterDraft saved = viewModel.getRegisterDraft();
        if (saved != null) {
            if (saved.surname != null) etSurname.setText(saved.surname);
            if (saved.name != null) etName.setText(saved.name);
            if (saved.patronymic != null) etPatronymic.setText(saved.patronymic);
            if (saved.email != null) etEmail.setText(saved.email);
            if (saved.phone != null) etPhone.setText(saved.phone);
            if (saved.password != null) etPass.setText(saved.password);
            if (saved.passwordConfirm != null) etPassConfirm.setText(saved.passwordConfirm);
            if (saved.birthDateIso != null && !saved.birthDateIso.isEmpty()) {
                birthDateIso = saved.birthDateIso;
                try {
                    LocalDate ld = LocalDate.parse(birthDateIso);
                    etBirthDate.setText(ld.format(DateTimeFormatter.ofPattern("dd.MM.yyyy", new Locale("ru", "RU"))));
                } catch (Exception ignored) {
                }
            }
        }
// Открытие календаря при клике на поле даты рождения
        etBirthDate.setOnClickListener(v -> showBirthDatePicker());
// Кнопка регистрации
        view.findViewById(R.id.btnRegister).setOnClickListener(v -> {
            String name = etName.getText() != null ? etName.getText().toString().trim() : "";
            String surname = etSurname.getText() != null ? etSurname.getText().toString().trim() : "";
            String patronymic = etPatronymic.getText() != null ? etPatronymic.getText().toString().trim() : "";
            String email = etEmail.getText() != null ? etEmail.getText().toString().trim() : "";
            String phone = etPhone.getText() != null ? etPhone.getText().toString().trim() : "";
            String pass = etPass.getText() != null ? etPass.getText().toString() : "";
            String pass2 = etPassConfirm.getText() != null ? etPassConfirm.getText().toString() : "";
// Валидация полей
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
                Toast.makeText(requireContext(), getString(R.string.fill_required_fields), Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(surname)) {
                Toast.makeText(requireContext(), getString(R.string.surname_required), Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(name)) {
                Toast.makeText(requireContext(), getString(R.string.fill_required_fields), Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(birthDateIso)) {
                Toast.makeText(requireContext(), getString(R.string.birth_date_required), Toast.LENGTH_SHORT).show();
                return;
            }
            if (!ValidationUtils.isAtLeastYearsOld(birthDateIso, 16)) {
                Toast.makeText(requireContext(), getString(R.string.age_requirement_error), Toast.LENGTH_LONG).show();
                return;
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(requireContext(), getString(R.string.invalid_email_format), Toast.LENGTH_SHORT).show();
                return;
            }
            if (!TextUtils.isEmpty(phone) && !ValidationUtils.isValidRussianPhone(phone)) {
                Toast.makeText(requireContext(), getString(R.string.invalid_phone_format), Toast.LENGTH_SHORT).show();
                return;
            }
            if (!pass.equals(pass2)) {
                Toast.makeText(requireContext(), getString(R.string.passwords_not_match), Toast.LENGTH_SHORT).show();
                return;
            }
            if (!ValidationUtils.meetsPasswordRules(pass)) {
                Toast.makeText(requireContext(), getString(R.string.password_rules_error), Toast.LENGTH_LONG).show();
                return;
            }
            viewModel.register(name, surname, patronymic, birthDateIso, email, phone, pass);
        });
// Переход на экран входа
        view.findViewById(R.id.btnToLogin).setOnClickListener(v ->
                requireActivity().getSupportFragmentManager().popBackStack());

        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading ->
                progressBar.setVisibility(Boolean.TRUE.equals(isLoading) ? View.VISIBLE : View.GONE));

        viewModel.getUser().observe(getViewLifecycleOwner(), user -> {
            if (user != null) {
                viewModel.clearRegisterDraft();
                if (listener != null) listener.onRegisterSuccess();
            }
        });
// После регистрации Supabase отправляет письмо — надо подтвердить email
        viewModel.getPendingConfirmEmail().observe(getViewLifecycleOwner(), email -> {
            if (email == null) return;
            AuthViewModel.RegisterDraft d = new AuthViewModel.RegisterDraft();
            d.name = etName.getText() != null ? etName.getText().toString() : "";
            d.surname = etSurname.getText() != null ? etSurname.getText().toString() : "";
            d.patronymic = etPatronymic.getText() != null ? etPatronymic.getText().toString() : "";
            d.birthDateIso = birthDateIso;
            d.email = etEmail.getText() != null ? etEmail.getText().toString() : "";
            d.phone = etPhone.getText() != null ? etPhone.getText().toString() : "";
            d.password = etPass.getText() != null ? etPass.getText().toString() : "";
            d.passwordConfirm = etPassConfirm.getText() != null ? etPassConfirm.getText().toString() : "";
            viewModel.setRegisterDraft(d);
            Toast.makeText(requireContext(), R.string.register_email_sent_toast, Toast.LENGTH_LONG).show();
            ((AuthActivity) requireActivity()).openFragment(ConfirmEmailOtpFragment.newInstance(email), true);
            viewModel.clearPendingConfirmEmail();
        });

        viewModel.getError().observe(getViewLifecycleOwner(), err -> {
            if (err != null) {
                Toast.makeText(requireContext(), err, Toast.LENGTH_LONG).show();
                viewModel.clearError();
            }
        });
    }

    private void showBirthDatePicker() {

        Calendar maxCal = Calendar.getInstance();
        maxCal.add(Calendar.YEAR, -16);
        long maxMs = maxCal.getTimeInMillis();

        long selection = maxMs;
        if (!TextUtils.isEmpty(birthDateIso)) {
            try {
                LocalDate ld = LocalDate.parse(birthDateIso);
                selection = ld.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
            } catch (Exception ignored) {
            }
        }

        MaterialDatePicker<Long> picker = MaterialDatePicker.Builder.datePicker()
                .setTitleText(getString(R.string.birth_date_hint))
                .setSelection(selection)
                .build();

        picker.addOnPositiveButtonClickListener(ms -> {
            if (ms == null) return;
            LocalDate chosen = java.time.Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate();
            birthDateIso = chosen.format(DateTimeFormatter.ISO_LOCAL_DATE);
            Locale ru = new Locale("ru", "RU");
            etBirthDate.setText(chosen.format(DateTimeFormatter.ofPattern("dd.MM.yyyy", ru)));
        });

        picker.show(getParentFragmentManager(), "birth_date_picker");
    }
}
