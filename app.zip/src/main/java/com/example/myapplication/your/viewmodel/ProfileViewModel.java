package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.model.User;

public class ProfileViewModel extends AndroidViewModel {
    private SharedPrefManager prefManager;

    private MutableLiveData<User> currentUser = new MutableLiveData<>();

    public ProfileViewModel(@NonNull Application application) {
        super(application);
        prefManager = SharedPrefManager.getInstance(application);
        loadCurrentUser();
    }

    public LiveData<User> getCurrentUser() { return currentUser; }

    public void loadCurrentUser() {
        User user = prefManager.getCurrentUser();
        currentUser.setValue(user);
    }

    public void refreshUser() {
        loadCurrentUser();
    }

    public void updateUser(User user) {
        // Сохраняем полную модель пользователя
        prefManager.saveCurrentUser(user);
        currentUser.setValue(user);
    }

    public void logout() {
        SharedPrefManager.getInstance(getApplication()).logout();
    }
}

