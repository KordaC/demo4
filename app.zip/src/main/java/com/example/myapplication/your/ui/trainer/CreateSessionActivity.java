package com.example.myapplication.your.ui.trainer;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.data.TrainerRepository;
import com.example.myapplication.your.model.TrainingDirection;
import com.example.myapplication.your.model.User;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class CreateSessionActivity extends AppCompatActivity {

    public static final String EXTRA_ADMIN_MODE = "extra_admin_mode";

    private TextInputEditText etTitle;
    private TextInputEditText etDate;
    private TextInputEditText etTimeStart;
    private TextInputEditText etTimeEnd;
    private Spinner spinnerClub;
    private Spinner spinnerDirection;
    private TextInputEditText etCapacity;
    private androidx.appcompat.widget.SwitchCompat switchFree;
    private TextInputEditText etPrice;
    private TextInputEditText etDescription;
    private TextInputEditText etHall;
    private TextInputEditText etLevel;
    private TextInputEditText etSessionImageUrl;
    private ProgressBar progress;
    private MaterialButton btnCreate;
    private View rowPickTrainer;
    private Spinner spinnerTrainerProfile;
    private final List<String> trainerProfileIds = new ArrayList<>();

    private final List<String> clubIds = new ArrayList<>();
    private final List<String> directionIds = new ArrayList<>();

    private String trainerProfileId;
    private boolean adminMode;
    private ScheduleRepository scheduleRepository;
    private TrainerRepository trainerRepository;
    private SharedPrefManager prefs;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_session);
        adminMode = getIntent().getBooleanExtra(EXTRA_ADMIN_MODE, false);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(adminMode ? R.string.create_session_title_admin : R.string.create_session_title);
        }

        scheduleRepository = ScheduleRepository.getInstance(this);
        trainerRepository = TrainerRepository.getInstance(this);
        prefs = SharedPrefManager.getInstance(this);

        etTitle = findViewById(R.id.et_session_title);
        etDate = findViewById(R.id.et_session_date);
        etTimeStart = findViewById(R.id.et_time_start);
        etTimeEnd = findViewById(R.id.et_time_end);
        spinnerClub = findViewById(R.id.spinner_club);
        spinnerDirection = findViewById(R.id.spinner_direction);
        etCapacity = findViewById(R.id.et_capacity);
        switchFree = findViewById(R.id.switch_free);
        etPrice = findViewById(R.id.et_price);
        etDescription = findViewById(R.id.et_description);
        etHall = findViewById(R.id.et_hall);
        etLevel = findViewById(R.id.et_level);
        etSessionImageUrl = findViewById(R.id.et_session_image_url);
        progress = findViewById(R.id.progress_create_session);
        btnCreate = findViewById(R.id.btn_create_session);
        rowPickTrainer = findViewById(R.id.row_pick_trainer);
        spinnerTrainerProfile = findViewById(R.id.spinner_trainer_profile);
        if (adminMode && rowPickTrainer != null) {
            rowPickTrainer.setVisibility(View.VISIBLE);
        }

        etDate.setText(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
        etTimeStart.setText("10:00");
        etTimeEnd.setText("11:00");
        etCapacity.setText("12");
        switchFree.setOnCheckedChangeListener((b, v) -> etPrice.setEnabled(!v));

        User u = prefs.getCurrentUser();
        if (u == null || u.getId() == null || u.getId().trim().isEmpty()) {
            Toast.makeText(this, "Войдите в аккаунт.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        progress.setVisibility(View.VISIBLE);
        btnCreate.setEnabled(false);
        new Thread(() -> {
            try {
                if (adminMode) {
                    List<ScheduleRepository.PickItem> trainers = scheduleRepository.listTrainerProfilesForPicker();
                    List<ScheduleRepository.PickItem> clubs = scheduleRepository.listClubs();
                    List<TrainingDirection> dirList = trainerRepository.getAllDirections();
                    final List<TrainingDirection> dirsForUi = dirList;
                    final List<ScheduleRepository.PickItem> trainersFinal = trainers;
                    final List<ScheduleRepository.PickItem> clubsFinal = clubs;
                    runOnUiThread(() -> {
                        bindTrainerSpinner(trainersFinal);
                        bindClubSpinner(clubsFinal);
                        bindDirectionSpinner(dirsForUi);
                        progress.setVisibility(View.GONE);
                        btnCreate.setEnabled(true);
                    });
                    return;
                }

                String tid = trainerRepository.getTrainerProfileIdByAppUserId(u.getId());
                if (tid == null || tid.isEmpty()) {
                    runOnUiThread(() -> {
                        progress.setVisibility(View.GONE);
                        Toast.makeText(this,
                                "Нет профиля тренера (trainer_profile).",
                                Toast.LENGTH_LONG).show();
                        finish();
                    });
                    return;
                }
                trainerProfileId = tid;

                List<ScheduleRepository.PickItem> clubs = scheduleRepository.listClubs();
                List<TrainingDirection> dirList = trainerRepository.getTrainerDirections(tid);
                if (dirList.isEmpty()) {
                    dirList = trainerRepository.getAllDirections();
                }
                final List<TrainingDirection> dirsForUi = dirList;

                runOnUiThread(() -> {
                    bindClubSpinner(clubs);
                    bindDirectionSpinner(dirsForUi);
                    progress.setVisibility(View.GONE);
                    btnCreate.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    Toast.makeText(this,
                            getString(R.string.create_session_load_error) + ": " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                    finish();
                });
            }
        }).start();

        btnCreate.setOnClickListener(v -> submit());
    }

    private void bindTrainerSpinner(List<ScheduleRepository.PickItem> trainers) {
        trainerProfileIds.clear();
        List<String> labels = new ArrayList<>();
        for (ScheduleRepository.PickItem p : trainers) {
            trainerProfileIds.add(p.id);
            labels.add(p.name);
        }
        if (labels.isEmpty()) {
            labels.add("—");
            trainerProfileIds.add("");
        }
        spinnerTrainerProfile.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, labels));
    }

    private void bindClubSpinner(List<ScheduleRepository.PickItem> clubs) {
        clubIds.clear();
        List<String> labels = new ArrayList<>();
        for (ScheduleRepository.PickItem p : clubs) {
            clubIds.add(p.id);
            labels.add(p.name);
        }
        if (labels.isEmpty()) {
            labels.add("—");
            clubIds.add("");
        }
        spinnerClub.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, labels));
    }

    private void bindDirectionSpinner(List<TrainingDirection> dirs) {
        directionIds.clear();
        List<String> labels = new ArrayList<>();
        for (TrainingDirection d : dirs) {
            directionIds.add(d.getId());
            labels.add(d.getName() != null && !d.getName().isEmpty() ? d.getName() : d.getId());
        }
        if (labels.isEmpty()) {
            labels.add("—");
            directionIds.add("");
        }
        spinnerDirection.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, labels));
    }

    private void submit() {
        String token = prefs.getAccessToken();
        if (token == null || token.trim().isEmpty()) {
            Toast.makeText(this, "Нет сессии.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (adminMode) {
            int ti = spinnerTrainerProfile != null ? spinnerTrainerProfile.getSelectedItemPosition() : -1;
            if (ti < 0 || ti >= trainerProfileIds.size() || trainerProfileIds.get(ti).isEmpty()) {
                Toast.makeText(this, R.string.create_session_pick_trainer, Toast.LENGTH_SHORT).show();
                return;
            }
            trainerProfileId = trainerProfileIds.get(ti);
        } else if (trainerProfileId == null) {
            Toast.makeText(this, "Нет профиля тренера.", Toast.LENGTH_SHORT).show();
            return;
        }

        String title = text(etTitle);
        String dateStr = text(etDate);
        String tsStr = text(etTimeStart);
        String teStr = text(etTimeEnd);
        LocalDate date;
        LocalTime tStart;
        LocalTime tEnd;
        try {
            date = LocalDate.parse(dateStr.trim(), DateTimeFormatter.ISO_LOCAL_DATE);
            tStart = LocalTime.parse(tsStr.trim(), DateTimeFormatter.ofPattern("HH:mm"));
            tEnd = LocalTime.parse(teStr.trim(), DateTimeFormatter.ofPattern("HH:mm"));
        } catch (DateTimeParseException e) {
            Toast.makeText(this, "Проверьте дату и время (формат ГГГГ-ММ-ДД и ЧЧ:ММ).", Toast.LENGTH_LONG).show();
            return;
        }

        LocalDateTime start = LocalDateTime.of(date, tStart);
        LocalDateTime end = LocalDateTime.of(date, tEnd);

        int cap = 12;
        try {
            String c = text(etCapacity);
            if (!c.isEmpty()) cap = Integer.parseInt(c.trim());
        } catch (NumberFormatException ignored) {
            Toast.makeText(this, "Некорректная вместимость.", Toast.LENGTH_SHORT).show();
            return;
        }

        int ci = spinnerClub.getSelectedItemPosition();
        int di = spinnerDirection.getSelectedItemPosition();
        if (ci < 0 || ci >= clubIds.size() || clubIds.get(ci).isEmpty()) {
            Toast.makeText(this, R.string.create_session_club, Toast.LENGTH_SHORT).show();
            return;
        }
        if (di < 0 || di >= directionIds.size() || directionIds.get(di).isEmpty()) {
            Toast.makeText(this, R.string.create_session_direction, Toast.LENGTH_SHORT).show();
            return;
        }

        boolean free = switchFree.isChecked();
        BigDecimal price = null;
        if (!free) {
            String ps = text(etPrice);
            if (!ps.isEmpty()) {
                try {
                    price = new BigDecimal(ps.replace(',', '.').trim());
                } catch (Exception e) {
                    Toast.makeText(this, "Некорректная цена.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        }

        progress.setVisibility(View.VISIBLE);
        btnCreate.setEnabled(false);

        final String clubId = clubIds.get(ci);
        final String dirId = directionIds.get(di);
        final String desc = text(etDescription);
        final String hall = text(etHall);
        final String level = text(etLevel);
        final String imageUrl = text(etSessionImageUrl);
        final int capFinal = cap;
        final boolean freeFinal = free;
        final BigDecimal priceFinal = price;
        final LocalDateTime startFinal = start;
        final LocalDateTime endFinal = end;
        final String titleFinal = title.isEmpty() ? null : title;

        new Thread(() -> {
            try {
                scheduleRepository.createTrainerGroupSession(
                        token.trim(),
                        trainerProfileId,
                        clubId,
                        dirId,
                        titleFinal,
                        startFinal,
                        endFinal,
                        capFinal,
                        freeFinal,
                        priceFinal,
                        desc.isEmpty() ? null : desc,
                        hall.isEmpty() ? null : hall,
                        level.isEmpty() ? null : level,
                        imageUrl.isEmpty() ? null : imageUrl
                );
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    btnCreate.setEnabled(true);
                    Toast.makeText(this, R.string.create_session_success, Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    btnCreate.setEnabled(true);
                    Toast.makeText(this,
                            e.getMessage() != null ? e.getMessage() : e.toString(),
                            Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private static String text(TextInputEditText et) {
        if (et == null || et.getText() == null) return "";
        return et.getText().toString().trim();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
