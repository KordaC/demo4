package com.example.myapplication.your.ui.main;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.data.FavoritesRepository;
import com.example.myapplication.your.data.MembershipRepository;
import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.util.GroupSignupUiHelper;
import com.example.myapplication.your.viewmodel.ScheduleViewModel;
import com.example.myapplication.your.ui.trainer.CreateSessionActivity;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class ScheduleFragment extends Fragment {

    private static final String ARG_ADMIN_MODE = "admin_mode";

    private boolean adminMode;
    private ScheduleViewModel viewModel;
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private View tvEmptySessions;
    private android.widget.TextView tvErrorSessions;
    private SessionAdapter adapter;
    private Spinner spDirection;
    private Spinner spTrainer;
    private List<Session> rawSessions = new ArrayList<>();
    private String pendingGroupPaymentSessionId;
    private boolean waitingForGroupPayment = false;
    private ActivityResultLauncher<Intent> paymentLauncher;

    public static ScheduleFragment newInstance(boolean adminMode) {
        ScheduleFragment f = new ScheduleFragment();
        Bundle args = new Bundle();
        args.putBoolean(ARG_ADMIN_MODE, adminMode);
        f.setArguments(args);
        return f;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_schedule, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        adminMode = getArguments() != null && getArguments().getBoolean(ARG_ADMIN_MODE, false);

        viewModel = new ViewModelProvider(this).get(ScheduleViewModel.class);

        recyclerView = view.findViewById(R.id.recycler_sessions);
        progressBar = view.findViewById(R.id.progress_bar);
        tvEmptySessions = view.findViewById(R.id.tv_empty_sessions);
        tvErrorSessions = view.findViewById(R.id.tv_error_sessions);
        spDirection = view.findViewById(R.id.spinner_filter_direction);
        spTrainer = view.findViewById(R.id.spinner_filter_trainer);
        Button btnReset = view.findViewById(R.id.btn_filter_reset);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new SessionAdapter(new ArrayList<>(), viewModel, adminMode);
        recyclerView.setAdapter(adapter);

        View fabAdmin = view.findViewById(R.id.fab_create_session_admin);
        if (fabAdmin != null) {
            fabAdmin.setVisibility(adminMode ? View.VISIBLE : View.GONE);
            fabAdmin.setOnClickListener(v -> {
                Intent i = new Intent(requireContext(), CreateSessionActivity.class);
                i.putExtra(CreateSessionActivity.EXTRA_ADMIN_MODE, true);
                startActivity(i);
            });
        }

        AdapterView.OnItemSelectedListener fl = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                applyFilters();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        };
        spDirection.setOnItemSelectedListener(fl);
        spTrainer.setOnItemSelectedListener(fl);
        btnReset.setOnClickListener(v -> {
            spDirection.setSelection(0);
            spTrainer.setSelection(0);
            applyFilters();
        });

        Button btnCalendar = view.findViewById(R.id.btn_calendar);
        btnCalendar.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), CalendarActivity.class);
            if (adminMode) {
                intent.putExtra(CalendarActivity.EXTRA_ADMIN_MODE, true);
            }
            startActivity(intent);
        });

        observeViewModel();

        paymentLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    waitingForGroupPayment = false;
                    if (result.getResultCode() == Activity.RESULT_OK && pendingGroupPaymentSessionId != null) {
                        // pending очищается в observe signupSuccess; иначе при повторном NEED_PAY не откроется оплата
                        viewModel.signUpForSession(pendingGroupPaymentSessionId);
                    }
                }
        );
    }

    @Override
    public void onResume() {
        super.onResume();
        viewModel.loadUpcomingSessions();
    }

    private void observeViewModel() {
        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE));

        viewModel.getUpcomingSessions().observe(getViewLifecycleOwner(), sessions -> {
            rawSessions = sessions != null ? new ArrayList<>(sessions) : new ArrayList<>();
            rebuildFilterSpinners();
            applyFilters();
        });

        viewModel.getError().observe(getViewLifecycleOwner(), error -> {
            if (error != null) {
                boolean isLimitExhausted = error.contains("Исчерпан лимит групповых посещений");
                boolean needSingleGroup = MembershipRepository.NEED_PAY_SINGLE_GROUP_SESSION.equals(error);
                if ((isLimitExhausted || needSingleGroup) && pendingGroupPaymentSessionId != null && !waitingForGroupPayment) {
                    waitingForGroupPayment = true;
                    Intent pi = new Intent(requireContext(), PaymentActivity.class);
                    if (needSingleGroup) {
                        pi.putExtra(PaymentActivity.EXTRA_PAY_SINGLE_GROUP_SESSION_ID, pendingGroupPaymentSessionId);
                    } else {
                        pi.putExtra(PaymentActivity.EXTRA_GROUP_TOPUP, true);
                        pi.putExtra(PaymentActivity.EXTRA_GROUP_TOPUP_COUNT, 1);
                    }
                    paymentLauncher.launch(pi);
                    viewModel.clearError();
                    return;
                }
                Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show();
                if (tvErrorSessions != null) {
                    tvErrorSessions.setText("Ошибка: " + error);
                    tvErrorSessions.setVisibility(View.VISIBLE);
                }
                viewModel.clearError();
            } else {
                if (tvErrorSessions != null) tvErrorSessions.setVisibility(View.GONE);
            }
        });

        viewModel.getSignupSuccess().observe(getViewLifecycleOwner(), success -> {
            if (success != null && success) {
                Toast.makeText(requireContext(), "Запись успешно обновлена", Toast.LENGTH_SHORT).show();
                viewModel.clearSignupSuccess();
                pendingGroupPaymentSessionId = null;
                waitingForGroupPayment = false;
            }
        });

        viewModel.getSessionStatusChanged().observe(getViewLifecycleOwner(), sessionIdWithTimestamp -> {
            if (sessionIdWithTimestamp != null && !sessionIdWithTimestamp.isEmpty()) {
                adapter.notifyDataSetChanged();
            }
        });
    }

    private void rebuildFilterSpinners() {
        if (getContext() == null) return;
        Set<String> dirs = new LinkedHashSet<>();
        dirs.add("Все");
        Set<String> trainers = new LinkedHashSet<>();
        trainers.add("Все");
        for (Session s : rawSessions) {
            if (s.getDirectionName() != null && !s.getDirectionName().isEmpty()) dirs.add(s.getDirectionName());
            if (s.getTrainerName() != null && !s.getTrainerName().isEmpty()) trainers.add(s.getTrainerName());
        }
        spDirection.setAdapter(newAdapter(new ArrayList<>(dirs)));
        spTrainer.setAdapter(newAdapter(new ArrayList<>(trainers)));
    }

    private ArrayAdapter<String> newAdapter(List<String> items) {
        ArrayAdapter<String> ad = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return ad;
    }

    private void applyFilters() {
        String dir = spDirection.getSelectedItem() != null ? spDirection.getSelectedItem().toString() : "Все";
        String trainer = spTrainer.getSelectedItem() != null ? spTrainer.getSelectedItem().toString() : "Все";
        List<Session> filtered = new ArrayList<>();
        for (Session s : rawSessions) {
            if (!"Все".equals(dir)) {
                String d = s.getDirectionName();
                if (d == null || !d.equals(dir)) continue;
            }
            if (!"Все".equals(trainer)) {
                String t = s.getTrainerName();
                if (t == null || !t.equals(trainer)) continue;
            }
            filtered.add(s);
        }
        adapter.updateSessions(filtered);
        boolean empty = filtered.isEmpty();
        if (tvEmptySessions != null) tvEmptySessions.setVisibility(empty ? View.VISIBLE : View.GONE);
        if (!empty && tvErrorSessions != null) tvErrorSessions.setVisibility(View.GONE);
    }

    private class SessionAdapter extends RecyclerView.Adapter<SessionAdapter.ViewHolder> {
        private List<Session> sessions;
        private final ScheduleViewModel viewModel;
        private final boolean adminMode;

        SessionAdapter(List<Session> sessions, ScheduleViewModel viewModel, boolean adminMode) {
            this.sessions = sessions;
            this.viewModel = viewModel;
            this.adminMode = adminMode;
        }

        void updateSessions(List<Session> newSessions) {
            this.sessions = newSessions != null ? newSessions : new ArrayList<>();
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_session, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            holder.bind(sessions.get(position));
        }

        @Override
        public int getItemCount() {
            return sessions.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            android.widget.TextView tvTitle;
            android.widget.TextView tvMore;
            android.widget.TextView tvTime;
            android.widget.TextView tvDate;
            android.widget.TextView tvTrainer;
            android.widget.TextView tvSpots;
            android.widget.TextView tvPrice;
            android.widget.TextView tvHall;
            android.widget.Button btnAction;
            ImageButton btnFavorite;
            View rowTrainer;
            ImageView ivTrainerPhoto;
            ImageView ivCover;

            ViewHolder(@NonNull View itemView) {
                super(itemView);
                ivCover = itemView.findViewById(R.id.iv_session_cover);
                tvTitle = itemView.findViewById(R.id.tv_session_title);
                tvMore = itemView.findViewById(R.id.tv_session_more);
                btnFavorite = itemView.findViewById(R.id.btn_session_favorite);
                rowTrainer = itemView.findViewById(R.id.row_session_trainer_block);
                ivTrainerPhoto = itemView.findViewById(R.id.iv_session_trainer_photo);
                tvTime = itemView.findViewById(R.id.tv_session_time);
                tvDate = itemView.findViewById(R.id.tv_session_date);
                tvTrainer = itemView.findViewById(R.id.tv_session_trainer);
                tvPrice = itemView.findViewById(R.id.tv_session_price);
                tvHall = itemView.findViewById(R.id.tv_session_hall);
                tvSpots = itemView.findViewById(R.id.tv_session_spots);
                btnAction = itemView.findViewById(R.id.btn_session_action);
            }

            void bind(Session session) {
                android.widget.TextView tvClients = itemView.findViewById(R.id.tv_session_clients);
                if (tvClients != null) {
                    tvClients.setVisibility(View.GONE);
                }

                if (ivCover != null) {
                    String u = session.getImageUrl();
                    if (u != null && u.startsWith("http")) {
                        ivCover.setVisibility(View.VISIBLE);
                        Glide.with(itemView.getContext()).load(u).centerCrop()
                                .placeholder(R.drawable.ic_trainer).into(ivCover);
                    } else {
                        ivCover.setVisibility(View.GONE);
                    }
                }

                tvTitle.setText(session.getTitle());
                tvTime.setText(session.getFormattedTimeRange());
                tvDate.setText(session.getFormattedDateLine());

                if (session.getTrainerName() != null && !session.getTrainerName().isEmpty()) {
                    tvTrainer.setText(session.getTrainerName());
                } else {
                    String tid = session.getTrainerId();
                    boolean hasTrainerId = tid != null && !tid.trim().isEmpty() && !"null".equalsIgnoreCase(tid.trim());
                    tvTrainer.setText(hasTrainerId ? "Тренер уточняется" : "Тренер не указан");
                }
                if (ivTrainerPhoto != null) {
                    String p = session.getTrainerPhotoUrl();
                    if (p != null && p.startsWith("http")) {
                        Glide.with(itemView.getContext()).load(p).circleCrop()
                                .placeholder(R.drawable.ic_trainer).into(ivTrainerPhoto);
                    } else {
                        ivTrainerPhoto.setImageResource(R.drawable.ic_trainer);
                    }
                }
                if (rowTrainer != null) {
                    String tid = session.getTrainerId();
                    if (tid != null && !tid.trim().isEmpty()) {
                        rowTrainer.setClickable(true);
                        rowTrainer.setOnClickListener(v -> {
                            Intent i = new Intent(v.getContext(), TrainerDetailActivity.class);
                            i.putExtra(TrainerDetailActivity.EXTRA_TRAINER_ID, tid);
                            v.getContext().startActivity(i);
                        });
                    } else {
                        rowTrainer.setOnClickListener(null);
                        rowTrainer.setClickable(false);
                    }
                }

                if (tvPrice != null) {
                    tvPrice.setText(session.getPriceLabelForCard());
                }
                if (tvHall != null) {
                    String hallLine = session.getHallLineForCard();
                    if (hallLine.isEmpty()) {
                        tvHall.setVisibility(View.GONE);
                    } else {
                        tvHall.setVisibility(View.VISIBLE);
                        tvHall.setText(hallLine);
                    }
                }

                tvSpots.setText("Мест: " + session.getSpotsTaken() + "/" + session.getCapacity());

                if (adminMode) {
                    btnAction.setVisibility(View.GONE);
                    btnAction.setOnClickListener(null);
                    if (btnFavorite != null) {
                        btnFavorite.setVisibility(View.GONE);
                    }
                    if (rowTrainer != null) {
                        rowTrainer.setOnClickListener(null);
                        rowTrainer.setClickable(false);
                    }
                    if (tvMore != null) {
                        tvMore.setOnClickListener(v -> {
                            Intent i = new Intent(itemView.getContext(), SessionDetailActivity.class);
                            i.putExtra(SessionDetailActivity.EXTRA_SESSION, session);
                            i.putExtra(SessionDetailActivity.EXTRA_ADMIN_MODE, true);
                            itemView.getContext().startActivity(i);
                        });
                    }
                    return;
                }

                boolean trainerAccount = viewModel.isTrainerAccount();
                boolean isSignedUp = viewModel.isUserSignedUp(session.getId());
                boolean canCancel = ScheduleRepository.canCancelGroupSession(session.getStartTime());
                boolean ended = session.isGroupSessionEndedNow();
                boolean started = session.hasGroupSessionStartedNow();

                if (trainerAccount) {
                    btnAction.setVisibility(View.GONE);
                    btnAction.setOnClickListener(null);
                } else {
                    btnAction.setVisibility(View.VISIBLE);
                    if (ended) {
                        btnAction.setText(R.string.session_status_completed);
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else if (isSignedUp && started) {
                        btnAction.setText(R.string.session_status_in_progress);
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else if (session.isFull() && !isSignedUp) {
                        btnAction.setText("Мест нет");
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else if (isSignedUp && !canCancel) {
                        btnAction.setText("Отмена недоступна (<2ч)");
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else if (isSignedUp) {
                        btnAction.setText("Отменить запись");
                        btnAction.setEnabled(true);
                        btnAction.setOnClickListener(v -> viewModel.cancelSession(session.getId()));
                    } else if (started) {
                        btnAction.setText(R.string.session_signup_closed);
                        btnAction.setEnabled(false);
                        btnAction.setOnClickListener(null);
                    } else {
                        btnAction.setText("Записаться");
                        btnAction.setEnabled(true);
                        btnAction.setOnClickListener(v -> GroupSignupUiHelper.showSignupWarningThen(requireContext(), () -> {
                            pendingGroupPaymentSessionId = session.getId();
                            viewModel.signUpForSession(session.getId());
                        }));
                    }
                }

                if (tvMore != null) {
                    tvMore.setOnClickListener(v -> {
                        Intent i = new Intent(itemView.getContext(), SessionDetailActivity.class);
                        i.putExtra(SessionDetailActivity.EXTRA_SESSION, session);
                        itemView.getContext().startActivity(i);
                    });
                }

                if (btnFavorite != null && session.getId() != null && !adminMode) {
                    FavoritesRepository fr = FavoritesRepository.getInstance(itemView.getContext());
                    btnFavorite.setImageResource(fr.isSessionFavorite(session.getId())
                            ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                    btnFavorite.setOnClickListener(v -> {
                        fr.toggleSessionFavorite(session.getId());
                        btnFavorite.setImageResource(fr.isSessionFavorite(session.getId())
                                ? R.drawable.ic_favorite_filled : R.drawable.ic_favorite_outline);
                    });
                }
            }
        }
    }
}
