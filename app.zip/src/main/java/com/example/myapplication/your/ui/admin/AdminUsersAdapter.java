package com.example.myapplication.your.ui.admin;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.model.AppUserAdminRow;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class AdminUsersAdapter extends RecyclerView.Adapter<AdminUsersAdapter.Holder> {

    public interface OnChangeRoleListener {
        void onChangeRole(AppUserAdminRow row);
    }

    private final List<AppUserAdminRow> data = new ArrayList<>();
    private final OnChangeRoleListener listener;

    public AdminUsersAdapter(OnChangeRoleListener listener) {
        this.listener = listener;
    }

    public void setData(List<AppUserAdminRow> list) {
        data.clear();
        if (list != null) data.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_admin_user, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        AppUserAdminRow row = data.get(position);
        h.tvName.setText(row.getDisplayName());
        h.tvEmail.setText(row.getEmail() != null ? row.getEmail() : "—");
        h.tvPhone.setText(row.getPhone() != null && !row.getPhone().trim().isEmpty() ? row.getPhone() : "—");
        h.tvRole.setText(roleLabel(h.itemView, row.getRole()));
        h.btnRole.setOnClickListener(v -> {
            if (listener != null) listener.onChangeRole(row);
        });
    }

    private static String roleLabel(View any, String role) {
        if (role == null) return any.getContext().getString(R.string.admin_role_client);
        switch (role.trim()) {
            case "trainer":
                return any.getContext().getString(R.string.admin_role_trainer);
            case "admin":
                return any.getContext().getString(R.string.admin_role_admin);
            default:
                return any.getContext().getString(R.string.admin_role_client);
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final TextView tvName;
        final TextView tvEmail;
        final TextView tvPhone;
        final TextView tvRole;
        final MaterialButton btnRole;

        Holder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_admin_user_name);
            tvEmail = itemView.findViewById(R.id.tv_admin_user_email);
            tvPhone = itemView.findViewById(R.id.tv_admin_user_phone);
            tvRole = itemView.findViewById(R.id.tv_admin_user_role);
            btnRole = itemView.findViewById(R.id.btn_admin_change_role);
        }
    }
}
