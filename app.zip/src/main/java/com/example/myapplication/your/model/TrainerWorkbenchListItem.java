package com.example.myapplication.your.model;


public class TrainerWorkbenchListItem {

    public static final int TYPE_GROUP = 0;
    public static final int TYPE_PERSONAL = 1;

    private final int type;
    private final Session groupSession;
    private final String groupClientsLine;
    private final TrainerPtRow personalRow;

    private TrainerWorkbenchListItem(int type, Session groupSession, String groupClientsLine, TrainerPtRow personalRow) {
        this.type = type;
        this.groupSession = groupSession;
        this.groupClientsLine = groupClientsLine != null ? groupClientsLine : "";
        this.personalRow = personalRow;
    }

    public static TrainerWorkbenchListItem group(Session session, String clientsLine) {
        return new TrainerWorkbenchListItem(TYPE_GROUP, session, clientsLine, null);
    }

    public static TrainerWorkbenchListItem personal(TrainerPtRow row) {
        return new TrainerWorkbenchListItem(TYPE_PERSONAL, null, "", row);
    }

    public int getType() { return type; }
    public Session getGroupSession() { return groupSession; }
    public String getGroupClientsLine() { return groupClientsLine; }
    public TrainerPtRow getPersonalRow() { return personalRow; }

    public long getSortTimeMillis() {
        if (type == TYPE_GROUP && groupSession != null && groupSession.getStartTime() != null) {
            return groupSession.getStartTime()
                    .atZone(java.time.ZoneId.systemDefault())
                    .toInstant()
                    .toEpochMilli();
        }
        if (type == TYPE_PERSONAL && personalRow != null && personalRow.getStartTime() != null) {
            return personalRow.getStartTime()
                    .atZone(java.time.ZoneId.systemDefault())
                    .toInstant()
                    .toEpochMilli();
        }
        return Long.MAX_VALUE;
    }
}
