package com.example.myapplication.your.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.model.ServiceItem;
import com.example.myapplication.your.viewmodel.ServiceViewModel;

import java.util.ArrayList;
import java.util.List;

public class ServicesFragment extends Fragment {
    private ServiceViewModel viewModel;
    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private ServiceAdapter adapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_services, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(ServiceViewModel.class);

        recyclerView = view.findViewById(R.id.recycler_services);
        progressBar = view.findViewById(R.id.progress_bar);

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ServiceAdapter(new ArrayList<>(), serviceId -> {
            viewModel.purchaseService(serviceId, null);
        });
        recyclerView.setAdapter(adapter);

        observeViewModel();
        viewModel.loadServices();
    }

    private void observeViewModel() {
        viewModel.getLoading().observe(getViewLifecycleOwner(), isLoading -> {
            progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
        });

        viewModel.getServices().observe(getViewLifecycleOwner(), services -> {
            adapter.updateServices(services);
        });

        viewModel.getError().observe(getViewLifecycleOwner(), error -> {
            if (error != null) {
                Toast.makeText(requireContext(), error, Toast.LENGTH_SHORT).show();
                viewModel.clearError();
            }
        });

        viewModel.getPurchaseSuccess().observe(getViewLifecycleOwner(), success -> {
            if (success != null && success) {
                Toast.makeText(requireContext(), "Услуга успешно приобретена!", Toast.LENGTH_SHORT).show();
                viewModel.clearPurchaseSuccess();
            }
        });
    }


    private static class ServiceAdapter extends androidx.recyclerview.widget.RecyclerView.Adapter<ServiceAdapter.ViewHolder> {
        private List<ServiceItem> services;
        private OnServiceClickListener listener;

        interface OnServiceClickListener {
            void onServiceClick(String serviceId);
        }

        ServiceAdapter(List<ServiceItem> services, OnServiceClickListener listener) {
            this.services = services;
            this.listener = listener;
        }

        void updateServices(List<ServiceItem> newServices) {
            this.services = newServices != null ? newServices : new ArrayList<>();
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_service, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ServiceItem service = services.get(position);
            holder.bind(service, listener);
        }

        @Override
        public int getItemCount() {
            return services.size();
        }

        static class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
            android.widget.TextView tvName;
            android.widget.TextView tvDescription;
            android.widget.TextView tvPrice;
            android.widget.Button btnBuy;

            ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tv_service_name);
                tvDescription = itemView.findViewById(R.id.tv_service_description);
                tvPrice = itemView.findViewById(R.id.tv_service_price);
                btnBuy = itemView.findViewById(R.id.btn_buy_service);
            }

            void bind(ServiceItem service, OnServiceClickListener listener) {
                tvName.setText(service.getName());
                tvDescription.setText(service.getDescription() != null ? service.getDescription() : "");
                tvPrice.setText(service.getFormattedPrice());
                
                btnBuy.setOnClickListener(v -> {
                    if (listener != null) {
                        listener.onServiceClick(service.getId());
                    }
                });
            }
        }
    }
}
