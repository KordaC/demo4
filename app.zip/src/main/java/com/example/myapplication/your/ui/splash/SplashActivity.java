package com.example.myapplication.your.ui.splash;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.BuildConfig;
import com.example.myapplication.your.ui.main.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.model.User;
import com.example.myapplication.your.ui.auth.AuthActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        if (!isSupabaseConfigured()) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.supabase_config_missing_title)
                    .setMessage(R.string.supabase_config_missing_message)
                    .setPositiveButton(android.R.string.ok, (d, w) -> finish())
                    .setCancelable(false)
                    .show();
            return;
        }

        new Handler().postDelayed(() -> {

            User user = SharedPrefManager
                    .getInstance(this)
                    .getCurrentUser();

            if (user != null) {
                startActivity(new Intent(this, MainActivity.class));
            } else {
                startActivity(new Intent(this, AuthActivity.class));
            }

            finish();

        }, 1500);
    }

    private static boolean isSupabaseConfigured() {
        String url = BuildConfig.SUPABASE_URL;
        String key = BuildConfig.SUPABASE_ANON_KEY;
        return url != null && !url.trim().isEmpty()
                && key != null && !key.trim().isEmpty();
    }
}