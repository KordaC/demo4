package com.example.myapplication.your.ui.trainer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.your.ui.main.PaymentActivity;
import com.example.myapplication.your.viewmodel.TrainerBookingViewModel;

import java.util.Calendar;
import java.util.ArrayList;
import java.util.List;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class TrainerCalendarActivity extends AppCompatActivity {

    public static final String EXTRA_TRAINER_ID = "trainer_id";
    public static final String EXTRA_RESCHEDULE_BOOKING_ID = "reschedule_booking_id";

    private String trainerId;
    private String rescheduleBookingId;
    private LocalDate selectedDate;
    private TrainerBookingViewModel viewModel;
    private ActivityResultLauncher<Intent> ptPaymentLauncher;
    private String pendingPtTime;
    private TimeAdapter timeAdapter;
    private View timeSection;
    private TextView tvPastDateHint;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainer_calendar);

        rescheduleBookingId = getIntent().getStringExtra(EXTRA_RESCHEDULE_BOOKING_ID);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(
                    rescheduleBookingId != null && !rescheduleBookingId.isEmpty()
                            ? getString(R.string.trainer_calendar_title_reschedule)
                            : getString(R.string.trainer_calendar_title_book));
        }

        trainerId = getIntent().getStringExtra(EXTRA_TRAINER_ID);
        if (trainerId == null) trainerId = "";
        selectedDate = LocalDate.now();

        viewModel = new ViewModelProvider(this).get(TrainerBookingViewModel.class);

        ptPaymentLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() != RESULT_OK) {
                        pendingPtTime = null;
                        return;
                    }
                    String t = pendingPtTime;
                    pendingPtTime = null;
                    if (t == null || trainerId == null || selectedDate == null) return;
                    if (selectedDate.isBefore(LocalDate.now())) return;
                    viewModel.bookSlot(trainerId, selectedDate, t);
                });

        CalendarView calendarView = findViewById(R.id.calendar_view);
        RecyclerView recyclerTimes = findViewById(R.id.recyclerTimes);
        ProgressBar progressBar = findViewById(R.id.progress_trainer_booking);
        timeSection = findViewById(R.id.time_section);
        tvPastDateHint = findViewById(R.id.tv_past_date_hint);

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        calendarView.setMinDate(cal.getTimeInMillis());

        List<String> slots = viewModel.getTimeSlots().getValue();
        if (slots == null) slots = new ArrayList<>();
        recyclerTimes.setLayoutManager(new GridLayoutManager(this, 3));
        timeAdapter = new TimeAdapter(slots, new ArrayList<>(), time -> onTimeSlotChosen(time));
        timeAdapter.setSelectedDate(selectedDate);
        recyclerTimes.setAdapter(timeAdapter);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = LocalDate.of(year, month + 1, dayOfMonth);
            if (timeAdapter != null) {
                timeAdapter.setSelectedDate(selectedDate);
            }
            updateTimeSectionVisibility();
            if (!selectedDate.isBefore(LocalDate.now())) {
                viewModel.loadBusySlots(trainerId, selectedDate);
            }
        });
        updateTimeSectionVisibility();

        viewModel.getBusySlots().observe(this, busy -> {
            if (timeAdapter != null) timeAdapter.setBusyTimes(busy != null ? busy : new ArrayList<>());
        });
        viewModel.getLoading().observe(this, loading -> {
            if (progressBar != null) progressBar.setVisibility(Boolean.TRUE.equals(loading) ? View.VISIBLE : View.GONE);
        });
        viewModel.getError().observe(this, error -> {
            if (error != null) {
                Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
                viewModel.clearError();
            }
        });
        viewModel.getBookingSuccess().observe(this, success -> {
            if (Boolean.TRUE.equals(success)) {
                Toast.makeText(this, getString(R.string.trainer_booking_success), Toast.LENGTH_SHORT).show();
                viewModel.clearBookingSuccess();
                if (trainerId != null && !trainerId.isEmpty() && selectedDate != null && !selectedDate.isBefore(LocalDate.now())) {
                    viewModel.loadBusySlots(trainerId, selectedDate);
                }
            }
        });
        viewModel.getRescheduleSuccess().observe(this, ok -> {
            if (Boolean.TRUE.equals(ok)) {
                Toast.makeText(this, getString(R.string.trainer_reschedule_success), Toast.LENGTH_SHORT).show();
                viewModel.clearRescheduleSuccess();
                if (trainerId != null && !trainerId.isEmpty() && selectedDate != null && !selectedDate.isBefore(LocalDate.now())) {
                    viewModel.loadBusySlots(trainerId, selectedDate);
                }
                finish();
            }
        });

        if (!selectedDate.isBefore(LocalDate.now())) {
            viewModel.loadBusySlots(trainerId, selectedDate);
        }
    }

    private void onTimeSlotChosen(String time) {
        if (selectedDate == null) return;
        if (selectedDate.isBefore(LocalDate.now())) {
            Toast.makeText(this, "Выберите будущую дату", Toast.LENGTH_SHORT).show();
            return;
        }
        if (selectedDate.equals(LocalDate.now())) {
            try {
                LocalTime slotTime = LocalTime.parse(time, DateTimeFormatter.ofPattern("HH:mm"));
                if (!slotTime.isAfter(LocalTime.now())) {
                    Toast.makeText(this, "Нельзя записаться на прошедшее время", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Exception ignored) {
            }
        }
        if (rescheduleBookingId != null && !rescheduleBookingId.isEmpty()) {
            viewModel.rescheduleBooking(rescheduleBookingId, trainerId, selectedDate, time);
            return;
        }
        pendingPtTime = time;
        Intent pay = new Intent(this, PaymentActivity.class);
        pay.putExtra(PaymentActivity.EXTRA_PT_TRAINER_ID, trainerId);
        pay.putExtra(PaymentActivity.EXTRA_PT_DATE_ISO, selectedDate.toString());
        pay.putExtra(PaymentActivity.EXTRA_PT_TIME, time);
        ptPaymentLauncher.launch(pay);
    }

    private void updateTimeSectionVisibility() {
        boolean isPast = selectedDate != null && selectedDate.isBefore(LocalDate.now());
        if (timeSection != null) timeSection.setVisibility(isPast ? View.GONE : View.VISIBLE);
        if (tvPastDateHint != null) {
            tvPastDateHint.setVisibility(isPast ? View.VISIBLE : View.GONE);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
