package com.example.myapplication.your.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Session implements Serializable {
    private String id;
    private String clubId;
    private String directionId;
    private String trainerId;
    private String title;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private int capacity;
    private int spotsTaken;
    private String directionName;
    private String trainerName;

    private String description;
    private String hallName;
    private String hallAddress;
    private String imageUrl;
    private String hallNumber;
    private String level;
    private String directionDescription;
    private String trainerPhotoUrl;
    private boolean free;
    private java.math.BigDecimal price;

    public Session() {}

    public Session(String id, String title, LocalDateTime startTime, LocalDateTime endTime, 
                   int capacity, int spotsTaken) {
        this.id = id;
        this.title = title;
        this.startTime = startTime;
        this.endTime = endTime;
        this.capacity = capacity;
        this.spotsTaken = spotsTaken;

    }


    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getClubId() { return clubId; }
    public void setClubId(String clubId) { this.clubId = clubId; }

    public String getDirectionId() { return directionId; }
    public void setDirectionId(String directionId) { this.directionId = directionId; }

    public String getTrainerId() { return trainerId; }
    public void setTrainerId(String trainerId) { this.trainerId = trainerId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }

    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }

    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }

    public int getSpotsTaken() { return spotsTaken; }
    public void setSpotsTaken(int spotsTaken) { this.spotsTaken = spotsTaken; }

    public String getDirectionName() { return directionName; }
    public void setDirectionName(String directionName) { this.directionName = directionName; }

    public String getTrainerName() { return trainerName; }
    public void setTrainerName(String trainerName) { this.trainerName = trainerName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getHallName() { return hallName; }
    public void setHallName(String hallName) { this.hallName = hallName; }

    public String getHallAddress() { return hallAddress; }
    public void setHallAddress(String hallAddress) { this.hallAddress = hallAddress; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getHallNumber() { return hallNumber; }
    public void setHallNumber(String hallNumber) { this.hallNumber = hallNumber; }

    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }

    public String getDirectionDescription() { return directionDescription; }
    public void setDirectionDescription(String directionDescription) { this.directionDescription = directionDescription; }

    public String getTrainerPhotoUrl() { return trainerPhotoUrl; }
    public void setTrainerPhotoUrl(String trainerPhotoUrl) { this.trainerPhotoUrl = trainerPhotoUrl; }

    public boolean isFree() { return free; }
    public void setFree(boolean free) { this.free = free; }

    public boolean requiresPaidGroupSticker() {
        if (!free) return true;
        return price != null && price.compareTo(java.math.BigDecimal.ZERO) > 0;
    }

    public java.math.BigDecimal getPrice() { return price; }
    public void setPrice(java.math.BigDecimal price) { this.price = price; }

    public boolean isGroupSessionEndedNow() {
        LocalDateTime now = LocalDateTime.now();
        if (endTime != null) {
            return now.isAfter(endTime);
        }
        if (startTime != null) {
            return now.isAfter(startTime.plusHours(1));
        }
        return false;
    }

    public boolean hasGroupSessionStartedNow() {
        LocalDateTime now = LocalDateTime.now();
        return startTime != null && !now.isBefore(startTime);
    }
    public String getSubtitleLine() {
        StringBuilder sb = new StringBuilder();
        if (directionName != null && !directionName.isEmpty()) {
            sb.append(directionName);
        }
        if (hallName != null && !hallName.isEmpty()) {
            if (sb.length() > 0) sb.append(" · ");
            sb.append(hallName);
        }
        return sb.toString();
    }

    public String getPriceLabelForCard() {
        if (free) {
            return "Бесплатно";
        }
        if (price != null && price.signum() > 0) {
            return price.stripTrailingZeros().toPlainString().replace('.', ',') + " ₽";
        }
        return "По абонементу";
    }

    public String getHallLineForCard() {
        StringBuilder sb = new StringBuilder();
        if (hallNumber != null && !hallNumber.trim().isEmpty() && !"null".equalsIgnoreCase(hallNumber.trim())) {
            sb.append("Зал № ").append(hallNumber.trim());
        }
        if (hallName != null && !hallName.trim().isEmpty()) {
            if (sb.length() > 0) sb.append(" · ");
            sb.append(hallName.trim());
        }
        return sb.toString();
    }

    public int getSpotsLeft() {
        return capacity - spotsTaken;
    }

    public boolean isFull() {
        return spotsTaken >= capacity;
    }




    public String getFormattedStartTime() {
        if (startTime == null) return "";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        return startTime.format(formatter);
    }


    public String getFormattedDateLine() {
        if (startTime == null) return "";
        return startTime.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    }

    public String getFormattedTimeRange() {
        if (startTime == null || endTime == null) return "";
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        return startTime.format(timeFormatter) + " - " + endTime.format(timeFormatter);
    }

    public String getFormattedDateTimeLine() {
        if (startTime == null) return "";
        if (endTime == null) return getFormattedStartTime();
        DateTimeFormatter date = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        DateTimeFormatter hm = DateTimeFormatter.ofPattern("HH:mm");
        return startTime.format(date) + ", " + startTime.format(hm) + " – " + endTime.format(hm);
    }

    public static boolean isPresentableText(String s) {
        if (s == null) return false;
        String t = s.trim();
        return !t.isEmpty() && !"null".equalsIgnoreCase(t);
    }
}

