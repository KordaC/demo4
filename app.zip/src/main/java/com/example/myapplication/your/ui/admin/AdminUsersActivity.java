package com.example.myapplication.your.ui.admin;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.myapplication.R;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.model.AppUserAdminRow;
import com.example.myapplication.your.model.User;
import com.example.myapplication.your.viewmodel.AdminUsersViewModel;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.List;

public class AdminUsersActivity extends AppCompatActivity implements AdminUsersAdapter.OnChangeRoleListener {

    private AdminUsersViewModel viewModel;
    private AdminUsersAdapter adapter;
    private SwipeRefreshLayout swipe;
    private TextView tvEmpty;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        User cur = SharedPrefManager.getInstance(this).getCurrentUser();
        if (cur == null || !cur.isAdmin()) {
            Toast.makeText(this, R.string.admin_access_denied, Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_admin_users);

        MaterialToolbar tb = findViewById(R.id.toolbar_admin_users);
        tb.setNavigationOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        swipe = findViewById(R.id.swipe_admin_users);
        tvEmpty = findViewById(R.id.tv_admin_users_empty);
        RecyclerView rv = findViewById(R.id.rv_admin_users);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AdminUsersAdapter(this);
        rv.setAdapter(adapter);

        viewModel = new ViewModelProvider(this).get(AdminUsersViewModel.class);

        swipe.setOnRefreshListener(() -> viewModel.loadUsers());

        viewModel.getUsers().observe(this, this::applyList);
        viewModel.getLoading().observe(this, loading -> {
            boolean on = Boolean.TRUE.equals(loading);
            swipe.setRefreshing(on);
        });
        viewModel.getError().observe(this, err -> {
            if (err != null) {
                Toast.makeText(this, err, Toast.LENGTH_LONG).show();
                viewModel.clearError();
            }
        });

        viewModel.loadUsers();
    }

    private void applyList(List<AppUserAdminRow> list) {
        adapter.setData(list);
        boolean empty = list == null || list.isEmpty();
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onChangeRole(AppUserAdminRow row) {
        User self = SharedPrefManager.getInstance(this).getCurrentUser();
        String[] values = new String[]{User.ROLE_CLIENT, User.ROLE_TRAINER, User.ROLE_ADMIN};
        String[] labels = new String[]{
                getString(R.string.admin_role_client),
                getString(R.string.admin_role_trainer),
                getString(R.string.admin_role_admin)
        };
        new AlertDialog.Builder(this)
                .setTitle(R.string.admin_pick_role_title)
                .setItems(labels, (d, which) -> {
                    String newRole = values[which];
                    if (self != null && self.getId() != null && self.getId().equals(row.getId())
                            && !User.ROLE_ADMIN.equals(newRole)) {
                        new AlertDialog.Builder(this)
                                .setMessage(R.string.admin_demote_self_warning)
                                .setNegativeButton(android.R.string.cancel, null)
                                .setPositiveButton(R.string.admin_continue, (d2, w) ->
                                        viewModel.updateRole(row.getId(), newRole))
                                .show();
                    } else {
                        viewModel.updateRole(row.getId(), newRole);
                    }
                })
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }
}
