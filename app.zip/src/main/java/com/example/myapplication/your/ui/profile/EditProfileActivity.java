package com.example.myapplication.your.ui.profile;

import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.your.data.MembershipRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.model.User;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class EditProfileActivity extends AppCompatActivity {

    private TextView tvFullName, tvEmail, tvPhone, tvBirth;
    private Button btnSave, btnPick;
    private ImageView ivAvatar;
    private User user;

    private final ActivityResultLauncher<String> pickImage =
            registerForActivityResult(new ActivityResultContracts.GetContent(), this::onPickedImage);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Редактирование профиля");
        }

        tvFullName = findViewById(R.id.tv_profile_full_name);
        tvEmail = findViewById(R.id.tv_profile_email);
        tvPhone = findViewById(R.id.tv_profile_phone);
        tvBirth = findViewById(R.id.tv_profile_birth);
        btnSave = findViewById(R.id.btn_save);
        btnPick = findViewById(R.id.btn_pick_avatar);
        ivAvatar = findViewById(R.id.iv_edit_avatar);

        user = SharedPrefManager.getInstance(this).getCurrentUser();

        if (user != null) {
            tvFullName.setText(buildFullName(user));
            tvEmail.setText(user.getEmail() != null ? user.getEmail() : "—");
            tvPhone.setText(user.getPhone() != null && !user.getPhone().isEmpty() ? user.getPhone() : "—");
            tvBirth.setText(formatBirthDate(user.getBirthDate()));

            if (user.getAvatarUrl() != null && !user.getAvatarUrl().isEmpty()) {
                if (user.getAvatarUrl().startsWith("http")) {
                    Glide.with(this).load(user.getAvatarUrl()).circleCrop().into(ivAvatar);
                } else {
                    Glide.with(this).load(new File(user.getAvatarUrl())).circleCrop().into(ivAvatar);
                }
            }
        }

        btnPick.setOnClickListener(v -> pickImage.launch("image/*"));

        btnSave.setOnClickListener(v -> saveProfile());
    }

    private static String buildFullName(User u) {
        if (u == null) return "—";
        String full = u.getFullNameOfficial();
        return full != null && !full.trim().isEmpty() ? full.trim() : "—";
    }

    private static String formatBirthDate(String iso) {
        if (iso == null || iso.trim().isEmpty()) return "—";
        String t = iso.trim();
        try {
            if (t.length() >= 10) {
                LocalDate d = LocalDate.parse(t.substring(0, 10));
                return d.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
            }
        } catch (DateTimeParseException ignored) {
        }
        return t;
    }

    private void onPickedImage(Uri uri) {
        if (uri == null || user == null || user.getId() == null) return;
        try {
            File out = new File(getFilesDir(), "avatar_" + user.getId() + ".jpg");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream os = new FileOutputStream(out)) {
                if (in == null) return;
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            user.setAvatarUrl(out.getAbsolutePath());
            Glide.with(this).load(out).circleCrop().into(ivAvatar);
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось сохранить фото", Toast.LENGTH_SHORT).show();
        }
    }
    private void saveProfile() {
        if (user == null) {
            finish();
            return;
        }
        btnSave.setEnabled(false);
        new Thread(() -> {
            try {
                String av = user.getAvatarUrl();
                if (av != null && !av.trim().isEmpty() && !av.startsWith("http")) {
                    File f = new File(av.trim());
                    if (f.isFile()) {
                        String publicUrl = MembershipRepository.getInstance(this)
                                .uploadUserAvatarFile(f, user.getId());
                        if (publicUrl == null) {
                            runOnUiThread(() -> {
                                btnSave.setEnabled(true);
                                Toast.makeText(this,
                                        "Не удалось загрузить фото. Проверьте интернет и политику Storage (supabase_storage_avatars.sql).",
                                        Toast.LENGTH_LONG).show();
                            });
                            return;
                        }
                        user.setAvatarUrl(publicUrl);
                    }
                }
                SharedPrefManager.getInstance(this).saveCurrentUser(user);
                MembershipRepository.getInstance(this).ensureAppUser(user);
                MembershipRepository.getInstance(this).updateAppUserProfile(user);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Профиль сохранён", Toast.LENGTH_SHORT).show();
                    finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    btnSave.setEnabled(true);
                    Toast.makeText(this,
                            e.getMessage() != null ? e.getMessage() : "Ошибка сохранения",
                            Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
