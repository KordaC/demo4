package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.ServiceRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.model.ServiceItem;
import com.example.myapplication.your.model.User;

import java.util.List;

public class ServiceViewModel extends AndroidViewModel {
    private ServiceRepository repository;
    private SharedPrefManager prefManager;

    private MutableLiveData<Boolean> loading = new MutableLiveData<>();
    private MutableLiveData<List<ServiceItem>> services = new MutableLiveData<>();
    private MutableLiveData<String> error = new MutableLiveData<>();
    private MutableLiveData<Boolean> purchaseSuccess = new MutableLiveData<>();

    public ServiceViewModel(@NonNull Application application) {
        super(application);
        repository = ServiceRepository.getInstance(application);
        prefManager = SharedPrefManager.getInstance(application);
    }

    public LiveData<Boolean> getLoading() { return loading; }
    public LiveData<List<ServiceItem>> getServices() { return services; }
    public LiveData<String> getError() { return error; }
    public LiveData<Boolean> getPurchaseSuccess() { return purchaseSuccess; }

    public void loadServices() {
        loading.setValue(true);
        new Thread(() -> {
            try {
                List<ServiceItem> serviceList = repository.getAllServices();
                services.postValue(serviceList);
            } catch (Exception e) {
                error.postValue("Ошибка загрузки услуг: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void loadServicesByCategory(String category) {
        loading.setValue(true);
        new Thread(() -> {
            try {
                List<ServiceItem> serviceList = repository.getServicesByCategory(category);
                services.postValue(serviceList);
            } catch (Exception e) {
                error.postValue("Ошибка загрузки услуг: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void purchaseService(String serviceId, String note) {
        loading.setValue(true);
        new Thread(() -> {
            try {
                User currentUser = prefManager.getCurrentUser();
                if (currentUser == null || currentUser.getId() == null) {
                    error.postValue("Пользователь не авторизован");
                    return;
                }

                boolean success = repository.purchaseService(currentUser.getId(), serviceId, note);
                if (success) {
                    purchaseSuccess.postValue(true);
                } else {
                    error.postValue("Не удалось купить услугу");
                }
            } catch (Exception e) {
                error.postValue("Ошибка покупки: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    public void clearError() {
        error.setValue(null);
    }

    public void clearPurchaseSuccess() {
        purchaseSuccess.setValue(false);
    }
}

