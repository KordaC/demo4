package com.example.myapplication.your.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.myapplication.your.data.AuthRepository;
import com.example.myapplication.your.data.MembershipRepository;
import com.example.myapplication.your.data.PersonalTrainingRepository;
import com.example.myapplication.your.data.ScheduleRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.data.TrainerRepository;
import com.example.myapplication.your.model.MembershipPurchase;
import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.model.TrainerProfile;
import com.example.myapplication.your.model.UnifiedBooking;
import com.example.myapplication.your.model.User;
import com.example.myapplication.your.model.UserPersonalBooking;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class HomeViewModel extends AndroidViewModel {
    private final SharedPrefManager prefManager;
    private final ScheduleRepository scheduleRepository;
    private final PersonalTrainingRepository ptRepository;
    private final TrainerRepository trainerRepository;
    private final MembershipRepository membershipRepository;

    private final MutableLiveData<Boolean> loading = new MutableLiveData<>(false);
    private final MutableLiveData<String> error = new MutableLiveData<>();

    private final MutableLiveData<UnifiedBooking> nearestBooking = new MutableLiveData<>();
    private final MutableLiveData<List<Session>> todaySessions = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<MembershipPurchase> activeMembership = new MutableLiveData<>();
    private final MutableLiveData<Integer> activeMembershipExtraCount = new MutableLiveData<>(0);

    public HomeViewModel(@NonNull Application application) {
        super(application);
        prefManager = SharedPrefManager.getInstance(application);
        scheduleRepository = ScheduleRepository.getInstance(application);
        ptRepository = PersonalTrainingRepository.getInstance(application);
        trainerRepository = TrainerRepository.getInstance(application);
        membershipRepository = MembershipRepository.getInstance(application);
    }

    public LiveData<Boolean> getLoading() { return loading; }
    public LiveData<String> getError() { return error; }

    public LiveData<UnifiedBooking> getNearestBooking() { return nearestBooking; }
    public LiveData<List<Session>> getTodaySessions() { return todaySessions; }
    public LiveData<MembershipPurchase> getActiveMembership() { return activeMembership; }
    public LiveData<Integer> getActiveMembershipExtraCount() { return activeMembershipExtraCount; }
    // Загрузка данных для главного экрана
    public void loadDashboard() {
        User user = prefManager.getCurrentUser();
        if (user == null || user.getId() == null) {
            error.setValue("Войдите в аккаунт");
            nearestBooking.setValue(null);
            todaySessions.setValue(new ArrayList<>());
            activeMembership.setValue(null);
            activeMembershipExtraCount.setValue(0);
            return;
        }

        error.setValue(null);
        loading.setValue(true);

        new Thread(() -> {
            try {
                String uidEarly = user.getId();
                List<MembershipPurchase> mc = membershipRepository.getActiveMembershipsFromCache(uidEarly);
                if (mc != null && !mc.isEmpty()) {
                    activeMembership.postValue(mc.get(0));
                    activeMembershipExtraCount.postValue(Math.max(0, mc.size() - 1));
                }
                List<Session> upCache = scheduleRepository.getUpcomingSessionsFromCache();
                if (upCache != null && !upCache.isEmpty()) {
                    LocalDate today = LocalDate.now();
                    LocalDateTime nowLine = LocalDateTime.now();
                    List<Session> filteredToday = new ArrayList<>();
                    for (Session s : upCache) {
                        if (s.getStartTime() == null) continue;
                        if (!s.getStartTime().toLocalDate().equals(today)) continue;
                        if (!s.getStartTime().isAfter(nowLine)) continue;
                        filteredToday.add(s);
                        if (filteredToday.size() >= 3) break;
                    }
                    if (!filteredToday.isEmpty()) {
                        todaySessions.postValue(filteredToday);
                    }
                }

                AuthRepository.getInstance(getApplication()).tryRefreshAccessToken();
                User synced = membershipRepository.syncStoredUserIdWithJwt();
                String uid = synced != null && synced.getId() != null ? synced.getId() : user.getId();

                // 1) Активный абонемент
                List<MembershipPurchase> mlist = membershipRepository.getActiveMemberships(uid);
                activeMembership.postValue(mlist.isEmpty() ? null : mlist.get(0));
                activeMembershipExtraCount.postValue(Math.max(0, mlist.size() - 1));

                // 2) Сегодня в расписании (мини-список)
                List<Session> todays = scheduleRepository.getSessionsForDate(LocalDate.now());
                LocalDateTime now = LocalDateTime.now();
                List<Session> filtered = new ArrayList<>();
                for (Session s : todays) {
                    if (s.getStartTime() != null && s.getStartTime().isAfter(now)) {
                        filtered.add(s);
                    }
                    if (filtered.size() >= 3) break;
                }
                todaySessions.postValue(filtered);

                // 3) Ближайшая запись (групповая или персональная)
                UnifiedBooking nearest = computeNearestBooking(uid);
                nearestBooking.postValue(nearest);
            } catch (Exception e) {
                error.postValue("Ошибка загрузки: " + e.getMessage());
            } finally {
                loading.postValue(false);
            }
        }).start();
    }

    private UnifiedBooking computeNearestBooking(String userId) {
        try {
            List<UserPersonalBooking> personal = ptRepository.getUserBookings(userId);
            List<Session> groupSessions = scheduleRepository.getUserSessions(userId);

            // Подтягиваем имена тренеров для персональных
            List<TrainerProfile> trainers = trainerRepository.getAllTrainers();
            Map<String, String> idToName = trainers.stream()
                    .filter(t -> t.getId() != null)
                    .collect(Collectors.toMap(TrainerProfile::getId, t -> t.getName() != null ? t.getName() : "Тренер", (a, b) -> a));
            for (UserPersonalBooking b : personal) {
                if (b.getTrainerId() != null) {
                    b.setTrainerName(idToName.get(b.getTrainerId()));
                }
                if (b.getTrainerName() == null) b.setTrainerName("Тренер");
            }

            LocalDateTime now = LocalDateTime.now();
            long nowMs = System.currentTimeMillis();

            List<UnifiedBooking> merged = new ArrayList<>();
            for (Session s : groupSessions) {
                if (s.getStartTime() == null) continue;
                // пропускаем завершённые
                if (s.getEndTime() != null) {
                    if (!s.getEndTime().isAfter(now)) continue;
                } else {
                    if (!s.getStartTime().isAfter(now)) continue;
                }
                merged.add(UnifiedBooking.fromGroupSession(s));
            }
            for (UserPersonalBooking b : personal) {
                if ("cancelled".equalsIgnoreCase(b.getStatus())) continue;
                if (b.getSortTimeMillis() < nowMs) continue;
                merged.add(UnifiedBooking.fromPersonal(b));
            }

            if (merged.isEmpty()) return null;
            // ближайшая — минимальное время
            merged.sort(Comparator.comparingLong(UnifiedBooking::getSortTimeMillis));
            return merged.get(0);
        } catch (Exception e) {
            return null;
        }
    }

    public void clearError() { error.setValue(null); }
}

