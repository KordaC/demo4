package com.example.myapplication.your.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class MembershipPlan implements Serializable {
    private String id;
    private String name;
    private String description;
    private BigDecimal price;
    private int durationDays;
    private Integer visitLimit;
    private int freezeDays;
    private boolean includesGroupPrograms;
    private boolean isActive;

    private Integer groupVisitsPerMonth;
    private String planTier;

    private String planKind;

    public MembershipPlan() {}

    public MembershipPlan(String id, String name, String description, BigDecimal price, 
                         int durationDays, Integer visitLimit, int freezeDays, 
                         boolean includesGroupPrograms, boolean isActive) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.durationDays = durationDays;
        this.visitLimit = visitLimit;
        this.freezeDays = freezeDays;
        this.includesGroupPrograms = includesGroupPrograms;
        this.isActive = isActive;
    }


    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public int getDurationDays() { return durationDays; }
    public void setDurationDays(int durationDays) { this.durationDays = durationDays; }

    public Integer getVisitLimit() { return visitLimit; }
    public void setVisitLimit(Integer visitLimit) { this.visitLimit = visitLimit; }

    public int getFreezeDays() { return freezeDays; }
    public void setFreezeDays(int freezeDays) { this.freezeDays = freezeDays; }

    public boolean isIncludesGroupPrograms() { return includesGroupPrograms; }
    public void setIncludesGroupPrograms(boolean includesGroupPrograms) { 
        this.includesGroupPrograms = includesGroupPrograms; 
    }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public Integer getGroupVisitsPerMonth() { return groupVisitsPerMonth; }
    public void setGroupVisitsPerMonth(Integer groupVisitsPerMonth) { this.groupVisitsPerMonth = groupVisitsPerMonth; }

    public String getPlanTier() { return planTier; }
    public void setPlanTier(String planTier) { this.planTier = planTier; }

    public String getPlanKind() { return planKind; }
    public void setPlanKind(String planKind) { this.planKind = planKind; }

    public boolean isUnlimited() {
        return visitLimit == null;
    }
}

