package com.example.myapplication.your.data;

import android.os.Handler;
import android.os.Looper;

import com.example.myapplication.your.model.Session;
import com.example.myapplication.your.util.TimestampParseUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class SessionRepository {

    private static final String SUPABASE_URL =
            "https://wqgwfwhcasewgopcnezd.supabase.co/rest/v1/sessions";

    private static final String API_KEY =
            "sb_secret_wYYZiH9ZIxZWqVRSXW-N4w_QC0ttl9N";

    public interface SessionCallback{
        void onSuccess(ArrayList<Session> sessions);
        void onError(String error);
    }

    public void loadSessions(SessionCallback callback){

        new Thread(() -> {

            try{

                URL url = new URL(SUPABASE_URL);

                HttpURLConnection conn =
                        (HttpURLConnection) url.openConnection();

                conn.setRequestMethod("GET");

                conn.setRequestProperty("apikey",API_KEY);
                conn.setRequestProperty("Authorization","Bearer "+API_KEY);
                conn.setRequestProperty("Content-Type","application/json");

                BufferedReader reader =
                        new BufferedReader(
                                new InputStreamReader(conn.getInputStream())
                        );

                StringBuilder response = new StringBuilder();
                String line;

                while((line = reader.readLine()) != null){
                    response.append(line);
                }

                JSONArray array = new JSONArray(response.toString());

                ArrayList<Session> sessions = new ArrayList<>();

                for (int i = 0; i < array.length(); i++) {
                    JSONObject obj = array.getJSONObject(i);
                    Session session = new Session();
                    session.setId(obj.optString("id", ""));
                    session.setTitle(obj.optString("title", obj.optString("name", "")));
                    session.setTrainerName(obj.optString("trainer_name", obj.optString("trainer")));
                    session.setCapacity(obj.optInt("capacity", 20));
                    session.setSpotsTaken(obj.optInt("spots_taken", 0));
                    String startStr = obj.optString("start_time", obj.optString("time", null));
                    if (startStr != null && !startStr.isEmpty()) {
                        java.time.LocalDateTime st = TimestampParseUtil.parseSupabaseTimestampToLocal(startStr);
                        if (st != null) session.setStartTime(st);
                    }
                    String endStr = obj.optString("end_time");
                    if (endStr != null && !endStr.isEmpty()) {
                        java.time.LocalDateTime et = TimestampParseUtil.parseSupabaseTimestampToLocal(endStr);
                        if (et != null) session.setEndTime(et);
                    }
                    sessions.add(session);
                }

                new Handler(Looper.getMainLooper()).post(() ->
                        callback.onSuccess(sessions)
                );

            }
            catch(Exception e){

                new Handler(Looper.getMainLooper()).post(() ->
                        callback.onError(e.getMessage())
                );
            }

        }).start();

    }

}