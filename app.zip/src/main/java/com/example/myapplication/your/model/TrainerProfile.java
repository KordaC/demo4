package com.example.myapplication.your.model;

import java.io.Serializable;
import java.util.List;

public class TrainerProfile implements Serializable {
    private String id;
    private String userId;
    private String name;
    private String bio;
    private Integer experienceYears;
    private List<String> specializations;
    private String photoUrl;
    private Double rating;
    private Integer reviewCount;

    public TrainerProfile() {}

    public TrainerProfile(String id, String userId, String name) {
        this.id = id;
        this.userId = userId;
        this.name = name;
    }


    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }

    public Integer getExperienceYears() { return experienceYears; }
    public void setExperienceYears(Integer experienceYears) { this.experienceYears = experienceYears; }

    public List<String> getSpecializations() { return specializations; }
    public void setSpecializations(List<String> specializations) { this.specializations = specializations; }

    public String getPhotoUrl() { return photoUrl; }
    public void setPhotoUrl(String photoUrl) { this.photoUrl = photoUrl; }

    public Double getRating() { return rating; }
    public void setRating(Double rating) { this.rating = rating; }

    public Integer getReviewCount() { return reviewCount; }
    public void setReviewCount(Integer reviewCount) { this.reviewCount = reviewCount; }

    public String getFormattedRating() {
        if (rating == null) return "Нет оценок";
        return String.format("%.1f", rating) + " (" + (reviewCount != null ? reviewCount : 0) + " отзывов)";
    }

    public String getFormattedExperience() {
        if (experienceYears == null) return "";
        if (experienceYears == 1) return "1 год опыта";
        if (experienceYears < 5) return experienceYears + " года опыта";
        return experienceYears + " лет опыта";
    }
}

