package com.example.myapplication.your.ui.main;


import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import com.example.myapplication.R;
import com.example.myapplication.your.data.AuthRepository;
import com.example.myapplication.your.data.FavoritesRepository;
import com.example.myapplication.your.data.SharedPrefManager;
import com.example.myapplication.your.data.TrainerProfileIdCache;
import com.example.myapplication.your.model.User;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private String appliedRoleForNav;
    private boolean profileSyncStarted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        nav.getMenu().clear();

        User u = SharedPrefManager.getInstance(this).getCurrentUser();
        final String role = (u != null) ? u.getRole() : User.ROLE_CLIENT;
        appliedRoleForNav = role;

        Fragment start;
        if (User.ROLE_ADMIN.equals(role)) {
            nav.inflateMenu(R.menu.bottom_nav_admin);
            start = new AdminDashboardFragment();
        } else if (User.ROLE_TRAINER.equals(role)) {
            nav.inflateMenu(R.menu.bottom_nav_trainer);
            start = new TrainerWorkbenchFragment();
        } else {
            nav.inflateMenu(R.menu.bottom_nav_menu);
            start = new HomeFragment();
        }

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.main_container, start)
                    .commit();
        }

        nav.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) {
                if (User.ROLE_ADMIN.equals(role)) {
                    load(new AdminDashboardFragment());
                } else {
                    load(new HomeFragment());
                }
                return true;
            }
            if (itemId == R.id.nav_trainer_bench) {
                load(new TrainerWorkbenchFragment());
                return true;
            }
            if (itemId == R.id.nav_schedule) {
                if (User.ROLE_ADMIN.equals(role)) {
                    load(ScheduleFragment.newInstance(true));
                } else {
                    load(new ScheduleFragment());
                }
                return true;
            }
            if (itemId == R.id.nav_trainers) {
                if (User.ROLE_ADMIN.equals(role)) {
                    load(TrainersFragment.newInstance(true));
                } else {
                    load(new TrainersFragment());
                }
                return true;
            }
            if (itemId == R.id.nav_profile) {
                load(new ProfileFragment());
                return true;
            }
            if (itemId == R.id.nav_myclub) {
                load(new MyClubFragment());
                return true;
            }
            return false;
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!profileSyncStarted) {
            profileSyncStarted = true;
            AuthRepository.getInstance(getApplicationContext()).syncCurrentUserProfileFromServer(user -> {
                if (isFinishing() || user == null) return;
                String fromServer = user.getRole();
                if (!fromServer.equals(appliedRoleForNav)) {
                    TrainerProfileIdCache.clear();
                    recreate();
                }
            });
        }
        new Thread(() -> FavoritesRepository.getInstance(getApplicationContext()).syncFromServerIfLoggedIn()).start();
    }

    private void load(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.main_container, fragment)
                .commit();
    }
}
