package com.example.myapplication.your.model;

public class TrainerBooking {

    private String id;
    private String trainerId;
    private String userId;
    private String date;
    private String time;

    public TrainerBooking(String id, String trainerId, String userId, String date, String time) {
        this.id = id;
        this.trainerId = trainerId;
        this.userId = userId;
        this.date = date;
        this.time = time;
    }

    public String getTrainerId() {
        return trainerId;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }
}