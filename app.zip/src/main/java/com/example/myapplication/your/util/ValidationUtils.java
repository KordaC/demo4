package com.example.myapplication.your.util;

import android.util.Patterns;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;

public final class ValidationUtils {

    private ValidationUtils() {}

    private static final DateTimeFormatter ISO_DATE = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final Pattern EMAIL_FALLBACK =
            Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$", Pattern.CASE_INSENSITIVE);

    public static boolean isValidIsoDate(String s) {
        if (s == null) return false;
        String t = s.trim();
        if (t.isEmpty()) return false;
        try {
            LocalDate.parse(t, ISO_DATE);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    public static Integer ageInFullYearsToday(String isoDateYyyyMmDd) {
        if (!isValidIsoDate(isoDateYyyyMmDd)) return null;
        LocalDate birth = LocalDate.parse(isoDateYyyyMmDd.trim(), ISO_DATE);
        LocalDate today = LocalDate.now();
        if (birth.isAfter(today)) return null;
        return Period.between(birth, today).getYears();
    }

    public static boolean isAtLeastYearsOld(String isoDateYyyyMmDd, int minYears) {
        Integer y = ageInFullYearsToday(isoDateYyyyMmDd);
        return y != null && y >= minYears;
    }


    public static boolean isValidRussianPhone(CharSequence phone) {
        if (phone == null) return false;
        String digitsOnly = phone.toString().replaceAll("[^0-9]", "");
        if (digitsOnly.length() == 10) {
            return digitsOnly.charAt(0) == '9';
        }
        if (digitsOnly.length() == 11) {
            char first = digitsOnly.charAt(0);
            return first == '7' || first == '8';
        }
        return false;
    }

    public static boolean looksLikeEmail(CharSequence input) {
        if (input == null) return false;
        try {
            if (Patterns.EMAIL_ADDRESS != null) {
                return Patterns.EMAIL_ADDRESS.matcher(input).matches();
            }
        } catch (Throwable ignored) {
            // Fallback ниже
        }
        return EMAIL_FALLBACK.matcher(input).matches();
    }
    public static boolean looksLikePhone(CharSequence input) {
        if (input == null || input.length() == 0) return false;
        String s = input.toString().trim();
        if (s.contains("@")) return false;
        String digitsOnly = s.replaceAll("[^0-9]", "");
        return digitsOnly.length() >= 10;
    }
    public static boolean meetsPasswordRules(String password) {
        if (password == null || password.length() < 6) return false;
        boolean letter = false;
        boolean digit = false;
        boolean special = false;
        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isLetter(c)) {
                letter = true;
            } else if (Character.isDigit(c)) {
                digit = true;
            } else if (!Character.isWhitespace(c)) {
                special = true;
            }
        }
        return letter && digit && special;
    }
}
