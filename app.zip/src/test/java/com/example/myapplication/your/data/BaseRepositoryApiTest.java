package com.example.myapplication.your.data;

import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.After;
import org.junit.Before;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Базовый класс для API-тестов репозиториев.
 * Поднимает MockWebServer, который заменяет реальный Supabase.
 */
public abstract class BaseRepositoryApiTest {

    protected MockWebServer server;
    protected String mockBaseUrl;

    @Before
    public void setUpServer() throws IOException {
        server = new MockWebServer();
        server.start();
        mockBaseUrl = server.url("/").toString(); // http://localhost:XXXXX/
    }

    @After
    public void tearDownServer() throws IOException {
        server.shutdown();
    }

    // ======================== Утилиты для enqueue ========================

    /** 200 OK с JSON-массивом. */
    protected void enqueueJsonArray(String body) {
        server.enqueue(jsonResponse(body));
    }

    /** 200 OK с JSON-объектом. */
    protected void enqueueJsonObject(String body) {
        server.enqueue(jsonResponse(body));
    }

    /** Произвольный ответ (код, headers, body). */
    protected void enqueueResponse(int code, String body) {
        server.enqueue(new MockResponse()
                .setResponseCode(code)
                .setHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(body));
    }

    /** 401 Unauthorized. */
    protected void enqueue401(String errorBody) {
        enqueueResponse(401, errorBody != null ? errorBody
                : "{\"error\":\"Invalid API key\",\"message\":\"No API key found\"}");
    }

    /** 500 Server Error. */
    protected void enqueue500() {
        enqueueResponse(500, "{\"message\":\"Internal server error\"}");
    }

    /** Пустой массив. */
    protected void enqueueEmptyArray() {
        enqueueJsonArray("[]");
    }

    // ======================== Утилиты для проверки запросов ========================

    /** Забрать последний запрос и проверить метод. */
    protected RecordedRequest takeRequestAndCheckMethod(String expectedMethod) throws InterruptedException {
        RecordedRequest request = server.takeRequest();
        assertEquals(expectedMethod, request.getMethod());
        return request;
    }

    /** Проверить, что путь содержит подстроку. */
    protected void assertPathContains(RecordedRequest request, String... substrings) {
        String path = request.getPath();
        for (String sub : substrings) {
            assertTrue("Path '" + path + "' не содержит '" + sub + "'", path.contains(sub));
        }
    }

    /** Проверить заголовок Authorization. */
    protected void assertAuthHeader(RecordedRequest request, String expectedKey) {
        String auth = request.getHeader("Authorization");
        assertNotNull("Authorization header отсутствует", auth);
        assertTrue("Неверный Bearer token", auth.equals("Bearer " + expectedKey));
    }

    /** Проверить заголовок apikey. */
    protected void assertApikeyHeader(RecordedRequest request, String expectedKey) {
        assertEquals(expectedKey, request.getHeader("apikey"));
    }

    // ======================== Фабрики JSON ========================

    private MockResponse jsonResponse(String body) {
        return new MockResponse()
                .setResponseCode(200)
                .setHeader("Content-Type", "application/json; charset=utf-8")
                .setBody(body);
    }

    /** Простой JSON-объект с access_token и user (для auth-тестов). */
    protected String authTokenResponse(String accessToken, String userId, String email, String name) {
        return "{"
                + "\"access_token\":\"" + accessToken + "\","
                + "\"refresh_token\":\"refresh-token-123\","
                + "\"token_type\":\"bearer\","
                + "\"expires_in\":3600,"
                + "\"user\":{"
                +   "\"id\":\"" + userId + "\","
                +   "\"email\":\"" + email + "\","
                +   "\"user_metadata\":{"
                +       "\"name\":\"" + name + "\","
                +       "\"surname\":\"Иванов\","
                +       "\"patronymic\":\"Иванович\""
                +   "}"
                + "}"
                + "}";
    }

    /** Пример JSON-сессии для ScheduleRepository. */
    protected String sessionJson(String id, String title, String startTime, String endTime,
                                  int capacity, int spotsTaken, String trainerName,
                                  String directionName, String hallName) {
        return "{"
                + "\"id\":\"" + id + "\","
                + "\"title\":\"" + title + "\","
                + "\"start_time\":\"" + startTime + "\","
                + "\"end_time\":\"" + endTime + "\","
                + "\"capacity\":" + capacity + ","
                + "\"spots_taken\":" + spotsTaken + ","
                + "\"trainer_name\":\"" + (trainerName != null ? trainerName : "") + "\","
                + "\"direction_name\":\"" + (directionName != null ? directionName : "") + "\","
                + "\"hall_name\":\"" + (hallName != null ? hallName : "") + "\""
                + "}";
    }
}
