package com.example.myapplication.your.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import java.time.LocalDateTime;

public class SessionTest {
    private Session session;

    @Before
    public void setUp() {
        session = new Session();
    }

    @Test
    public void subtitleLine_buildsFromDirectionAndHall() {
        Session s = new Session();
        s.setDirectionName("Йога");
        s.setHallName("Зал 1");
        assertEquals("Йога · Зал 1", s.getSubtitleLine());
    }

    @Test
    public void subtitleLine_omitsMissingParts() {
        Session s = new Session();
        s.setDirectionName("Силовая");
        assertEquals("Силовая", s.getSubtitleLine());

        Session s2 = new Session();
        s2.setHallName("Зал A");
        assertEquals("Зал A", s2.getSubtitleLine());
    }

    @Test
    public void spotsLeft_and_isFull_workCorrectly() {
        Session s = new Session();
        s.setCapacity(10);
        s.setSpotsTaken(9);
        assertEquals(1, s.getSpotsLeft());
        assertFalse(s.isFull());

        s.setSpotsTaken(10);
        assertEquals(0, s.getSpotsLeft());
        assertTrue(s.isFull());
    }

    @Test
    public void formattedTimeRange_usesStartAndEnd() {
        Session s = new Session();
        s.setStartTime(LocalDateTime.of(2026, 3, 30, 10, 0));
        s.setEndTime(LocalDateTime.of(2026, 3, 30, 11, 0));
        assertEquals("10:00 - 11:00", s.getFormattedTimeRange());
    }

    @Test
    public void constructor_initializesWithDefaults() {
        Session newSession = new Session();
        assertNotNull(newSession);
        assertEquals(0, newSession.getCapacity());
        assertEquals(0, newSession.getSpotsTaken());
    }
}


