package com.example.myapplication.your.data;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import okhttp3.mockwebserver.RecordedRequest;

/**
 * API-тесты TrainerRepository через MockWebServer.
 */
public class TrainerRepositoryApiTest extends BaseRepositoryApiTest {

    private static final String TEST_KEY = "test-anon-key-123";

    // ======================== GET /rest/v1/trainer_profile ========================

    @Test
    public void getAllTrainers_200_returnsTrainersList() throws Exception {
        String trainersBody = "["
                + trainerProfileJson("trainer-1", "user-1", "Опытный тренер", 10,
                        "[\"Йога\",\"Пилатес\"]", "https://example.com/photo1.jpg", "Иванов Иван")
                + ","
                + trainerProfileJson("trainer-2", "user-2", "Мастер спорта", 5,
                        "[\"Кроссфит\"]", "https://example.com/photo2.jpg", "Петрова Анна")
                + "]";

        enqueueJsonArray(trainersBody);

        String url = mockBaseUrl + "rest/v1/trainer_profile?select=*&order=id.asc";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(2, jsonArray.size());

        JsonObject first = jsonArray.get(0).getAsJsonObject();
        assertEquals("trainer-1", first.get("id").getAsString());
        assertEquals("user-1", first.get("user_id").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "/rest/v1/trainer_profile");
    }

    @Test
    public void getAllTrainers_empty_returnsEmptyList() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/trainer_profile?select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    @Test
    public void getAllTrainers_withNullBio_parsesCorrectly() throws Exception {
        String trainersBody = "[{\"id\":\"trainer-3\",\"user_id\":\"user-3\",\"bio\":null,\"experience_years\":null,\"specializations\":[],\"photo_url\":null,\"app_user\":null}]";

        enqueueJsonArray(trainersBody);

        String url = mockBaseUrl + "rest/v1/trainer_profile?select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());
        JsonObject t = jsonArray.get(0).getAsJsonObject();
        assertEquals("trainer-3", t.get("id").getAsString());
    }

    @Test
    public void getAllTrainers_500_throwsException() throws Exception {
        enqueue500();

        String url = mockBaseUrl + "rest/v1/trainer_profile?select=*";

        try {
            makeGetRequest(url);
            fail("Ожидалось исключение при 500");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("500"));
        }
    }

    @Test
    public void getTrainerById_200_returnsSingleTrainer() throws Exception {
        String trainerBody = "["
                + trainerProfileJson("trainer-99", "user-99", "Элитный тренер", 15,
                        "[\"Бокс\",\"ММА\"]", "https://example.com/elite.jpg", "Сидоров Виктор")
                + "]";

        enqueueJsonArray(trainerBody);

        String url = mockBaseUrl + "rest/v1/trainer_profile?id=eq.trainer-99&select=*&limit=1";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());
        assertEquals("trainer-99", jsonArray.get(0).getAsJsonObject().get("id").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "id=eq.trainer-99");
    }

    @Test
    public void getTrainerById_notFound_emptyArray() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/trainer_profile?id=eq.nonexistent&select=*&limit=1";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    @Test
    public void getTrainersByIds_200_returnsMultipleTrainers() throws Exception {
        String trainersBody = "["
                + trainerProfileJson("trainer-1", "user-1", "Тренер 1", 3, "[\"Йога\"]", null, "Тренер Один")
                + ","
                + trainerProfileJson("trainer-2", "user-2", "Тренер 2", 7, "[\"Пилатес\"]", null, "Тренер Два")
                + "]";

        enqueueJsonArray(trainersBody);

        String url = mockBaseUrl + "rest/v1/trainer_profile?id=in.(trainer-1,trainer-2)&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(2, jsonArray.size());
    }

    // ======================== GET /rest/v1/trainer_profile (by user_id) ========================

    @Test
    public void getTrainerProfileIdByAppUserId_200_returnsId() throws Exception {
        String profileBody = "[{\"id\":\"trainer-1\"}]";
        enqueueJsonArray(profileBody);

        String url = mockBaseUrl + "rest/v1/trainer_profile?user_id=eq.user-1&select=id&limit=1";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());
        assertEquals("trainer-1", jsonArray.get(0).getAsJsonObject().get("id").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "user_id=eq.user-1");
    }

    @Test
    public void getTrainerProfileIdByAppUserId_notFound_returnsEmpty() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/trainer_profile?user_id=eq.nonexistent&select=id&limit=1";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    // ======================== GET /rest/v1/trainer_review ========================

    @Test
    public void getReviews_200_returnsReviewsList() throws Exception {
        String reviewsBody = "["
                + reviewJson("review-1", "user-10", "trainer-1", 5, "Отличный тренер!", "2025-04-10T10:00:00Z", "Алексей")
                + ","
                + reviewJson("review-2", "user-11", "trainer-1", 4, "Хорошо", "2025-04-08T15:30:00Z", "Мария")
                + "]";

        enqueueJsonArray(reviewsBody);

        String url = mockBaseUrl + "rest/v1/trainer_review?trainer_id=eq.trainer-1&select=*&order=created_at.desc";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(2, jsonArray.size());

        JsonObject first = jsonArray.get(0).getAsJsonObject();
        assertEquals("review-1", first.get("id").getAsString());
        assertEquals(5, first.get("rating").getAsInt());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "/rest/v1/trainer_review", "trainer_id=eq.trainer-1");
    }

    @Test
    public void getReviews_empty_returnsEmptyList() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/trainer_review?trainer_id=eq.trainer-1&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    // ======================== POST /rest/v1/trainer_review ========================

    @Test
    public void submitReview_201_success() throws Exception {
        enqueueResponse(201, "{\"id\":\"review-new\"}");

        String url = mockBaseUrl + "rest/v1/trainer_review";
        String body = "{\"user_id\":\"user-100\",\"trainer_id\":\"trainer-1\",\"rating\":5,\"comment\":\"Супер!\"}";

        String response = makePostRequest(url, body);

        JsonObject result = JsonParser.parseString(response).getAsJsonObject();
        assertEquals("review-new", result.get("id").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/rest/v1/trainer_review");
    }

    @Test
    public void submitReview_409_duplicate_retriesWithPatch() throws Exception {
        enqueueResponse(409,
                "{\"message\":\"duplicate key value violates unique constraint\","
                        + "\"code\":\"23505\"}");

        String url = mockBaseUrl + "rest/v1/trainer_review";
        String body = "{\"user_id\":\"user-100\",\"trainer_id\":\"trainer-1\",\"rating\":4,\"comment\":\"Обновлённый\"}";

        try {
            makePostRequest(url, body);
            fail("Ожидалось исключение при 409");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("409") || e.getMessage().contains("23505"));
        }
    }

    // ======================== GET /rest/v1/trainer_review (find existing) ========================

    @Test
    public void findExistingReview_200_returnsReviewId() throws Exception {
        String reviewBody = "[{\"id\":\"review-existing\"}]";
        enqueueJsonArray(reviewBody);

        String url = mockBaseUrl + "rest/v1/trainer_review?trainer_id=eq.trainer-1&user_id=eq.user-100&select=id&limit=1";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());
        assertEquals("review-existing", jsonArray.get(0).getAsJsonObject().get("id").getAsString());
    }

    // ======================== GET /rest/v1/training_direction ========================

    @Test
    public void getAllDirections_200_returnsDirectionsList() throws Exception {
        String directionsBody = "["
                + directionJson("dir-1", "Йога", "Практика йоги", "https://example.com/icons/yoga.png")
                + ","
                + directionJson("dir-2", "Пилатес", "Упражнения на укрепление мышц", null)
                + "]";

        enqueueJsonArray(directionsBody);

        String url = mockBaseUrl + "rest/v1/training_direction?select=*&order=name.asc";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(2, jsonArray.size());

        JsonObject first = jsonArray.get(0).getAsJsonObject();
        assertEquals("dir-1", first.get("id").getAsString());
        assertEquals("Йога", first.get("name").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "/rest/v1/training_direction");
    }

    @Test
    public void getAllDirections_empty_returnsEmptyList() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/training_direction?select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    // ======================== GET /rest/v1/trainer_direction ========================

    @Test
    public void getTrainerDirections_200_returnsDirections() throws Exception {
        String directionsBody = "["
                + "{\"direction_id\":\"dir-1\",\"training_direction\":{\"id\":\"dir-1\",\"name\":\"Йога\"}}"
                + ","
                + "{\"direction_id\":\"dir-2\",\"training_direction\":{\"id\":\"dir-2\",\"name\":\"Пилатес\"}}"
                + "]";

        enqueueJsonArray(directionsBody);

        String url = mockBaseUrl + "rest/v1/trainer_direction?trainer_id=eq.trainer-1&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(2, jsonArray.size());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "/rest/v1/trainer_direction", "trainer_id=eq.trainer-1");
    }

    @Test
    public void getTrainerDirections_noDirections_returnsEmpty() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/trainer_direction?trainer_id=eq.trainer-999&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    // ======================== Утилиты JSON ========================

    private String trainerProfileJson(String id, String userId, String bio, Integer experienceYears,
                                       String specializations, String photoUrl, String appUserName) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"id\":\"").append(id).append("\",");
        sb.append("\"user_id\":\"").append(userId).append("\",");
        if (bio != null) {
            sb.append("\"bio\":\"").append(bio).append("\",");
        } else {
            sb.append("\"bio\":null,");
        }
        if (experienceYears != null) {
            sb.append("\"experience_years\":").append(experienceYears).append(",");
        } else {
            sb.append("\"experience_years\":null,");
        }
        sb.append("\"specializations\":").append(specializations).append(",");
        if (photoUrl != null) {
            sb.append("\"photo_url\":\"").append(photoUrl).append("\",");
        } else {
            sb.append("\"photo_url\":null,");
        }
        if (appUserName != null) {
            sb.append("\"app_user\":{\"name\":\"").append(appUserName).append("\"}");
        } else {
            sb.append("\"app_user\":null");
        }
        sb.append("}");
        return sb.toString();
    }

    private String reviewJson(String id, String userId, String trainerId, int rating,
                               String comment, String createdAt, String appUserName) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"id\":\"").append(id).append("\",");
        sb.append("\"user_id\":\"").append(userId).append("\",");
        sb.append("\"trainer_id\":\"").append(trainerId).append("\",");
        sb.append("\"rating\":").append(rating).append(",");
        sb.append("\"comment\":\"").append(comment).append("\",");
        sb.append("\"created_at\":\"").append(createdAt).append("\"");
        if (appUserName != null) {
            sb.append(",\"app_user\":{\"name\":\"").append(appUserName).append("\"}");
        }
        sb.append("}");
        return sb.toString();
    }

    private String directionJson(String id, String name, String description, String iconUrl) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"id\":\"").append(id).append("\",");
        sb.append("\"name\":\"").append(name).append("\",");
        if (description != null) {
            sb.append("\"description\":\"").append(description).append("\",");
        } else {
            sb.append("\"description\":null,");
        }
        if (iconUrl != null) {
            sb.append("\"icon_url\":\"").append(iconUrl).append("\"");
        } else {
            sb.append("\"icon_url\":null");
        }
        sb.append("}");
        return sb.toString();
    }

    // ======================== Утилиты HTTP ========================

    private String makeGetRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("apikey", TEST_KEY);

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null) throw new Exception("HTTP " + code + ": пустой stream");

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }

    private String makePostRequest(String urlString, String jsonBody) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("apikey", TEST_KEY);
        conn.setDoOutput(true);

        byte[] input = jsonBody.getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(input, 0, input.length);
        }

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null && code < 400) throw new Exception("HTTP " + code + ": пустой stream");

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }
}
