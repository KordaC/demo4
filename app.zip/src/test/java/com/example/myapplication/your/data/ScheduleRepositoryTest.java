package com.example.myapplication.your.data;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.time.LocalDateTime;

public class ScheduleRepositoryTest {

    @Test
    public void canCancelGroupSession_moreThanTwoHoursBeforeStart_true() {
        LocalDateTime start = LocalDateTime.now().plusHours(3);
        assertTrue(ScheduleRepository.canCancelGroupSession(start));
    }

    @Test
    public void canCancelGroupSession_lessThanTwoHoursBeforeStart_false() {
        LocalDateTime start = LocalDateTime.now().plusHours(1);
        assertFalse(ScheduleRepository.canCancelGroupSession(start));
    }

    @Test
    public void canCancelGroupSession_exactlyTwoHoursBeforeStart_false() {
        // По правилу: отмена разрешена только если now < start - 2h.
        // Если start = now + 2h, то start - 2h = now, и условие isBefore(now) = false.
        LocalDateTime start = LocalDateTime.now().plusHours(2);
        assertFalse(ScheduleRepository.canCancelGroupSession(start));
    }
}

