package com.example.myapplication.your.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.time.LocalDateTime;

//public class UnifiedBookingTest {
//
//    @Test
//    public void fromPersonal_usesTrainerNameOrFallback() {
//        UserPersonalBooking b = new UserPersonalBooking("pb1", "t1", "30.03.2026, 10:00", "requested", 123L);
//        b.setTrainerName("Иван Петров");
//
//        UnifiedBooking u = UnifiedBooking.fromPersonal(b);
//        assertEquals(UnifiedBooking.Kind.PERSONAL, u.getKind());
//        assertEquals("pb1", u.getId());
//        assertEquals("Иван Петров", u.getTitleLine());
//        assertEquals("30.03.2026, 10:00", u.getDetailLine());
//        assertEquals("Запланировано", u.getStatusLine());
//        assertEquals(123L, u.getSortTimeMillis());
//        assertEquals("Персональное", u.getKindBadge());
//    }
//
//    @Test
//    public void fromGroupSession_buildsDetailLine() {
//        Session s = new Session();
//        s.setId("gs1");
//        s.setTitle("Йога");
//        s.setStartTime(LocalDateTime.of(2026, 3, 30, 10, 0));
//        s.setEndTime(LocalDateTime.of(2026, 3, 30, 11, 0));
//        s.setTrainerName("Мария");
//        s.setDirectionName("Йога");
//
//        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
//        assertEquals(UnifiedBooking.Kind.GROUP, u.getKind());
//        assertEquals("gs1", u.getId());
//        assertEquals("Йога", u.getTitleLine());
//        assertEquals("Запись на групповое занятие", u.getStatusLine());
//        assertEquals("Групповое", u.getKindBadge());
//
//        // Дата/время + тренер + направление
//        assertEquals("30.03.2026 10:00 · Мария · Йога", u.getDetailLine());
//    }
//}
public class UnifiedBookingTest {

    private static final LocalDateTime TEST_START = LocalDateTime.of(2026, 3, 30, 10, 0);
    private static final LocalDateTime TEST_END = LocalDateTime.of(2026, 3, 30, 11, 0);

    @Test
    public void fromPersonal_usesTrainerNameOrFallback() {
        UserPersonalBooking b = new UserPersonalBooking("pb1", "t1", "30.03.2026, 10:00", "requested", 123L);
        b.setTrainerName("Иван Петров");

        UnifiedBooking u = UnifiedBooking.fromPersonal(b);
        assertEquals(UnifiedBooking.Kind.PERSONAL, u.getKind());
        assertEquals("pb1", u.getId());
        assertEquals("Иван Петров", u.getTitleLine());
        assertEquals("30.03.2026, 10:00", u.getDetailLine());
        assertEquals("Запланировано", u.getStatusLine());
        assertEquals(123L, u.getSortTimeMillis());
        assertEquals("Персональное", u.getKindBadge());
    }

    @Test
    public void fromPersonal_nullTrainerName_usesFallback() {
        UserPersonalBooking b = new UserPersonalBooking("pb2", "t2", "31.03.2026, 11:00", "approved", 456L);
        b.setTrainerName(null);

        UnifiedBooking u = UnifiedBooking.fromPersonal(b);
        assertEquals("Персональная тренировка", u.getTitleLine());
    }

    @Test
    public void fromPersonal_emptyTrainerName_usesFallback() {
        UserPersonalBooking b = new UserPersonalBooking("pb3", "t3", "01.04.2026, 12:00", "cancelled", 789L);
        b.setTrainerName("");

        UnifiedBooking u = UnifiedBooking.fromPersonal(b);
        assertEquals("Персональная тренировка", u.getTitleLine());
    }

    @Test
    public void fromPersonal_declinedStatus_showsCancelled() {
        UserPersonalBooking b = new UserPersonalBooking("pb4", "t4", "02.04.2026, 13:00", "declined", 999L);
        b.setTrainerName("Анна");

        UnifiedBooking u = UnifiedBooking.fromPersonal(b);
        assertEquals("Отменено", u.getStatusLine());
    }

    @Test
    public void fromPersonal_doneStatus_showsCompleted() {
        UserPersonalBooking b = new UserPersonalBooking("pb5", "t5", "03.04.2026, 14:00", "done", 1000L);
        b.setTrainerName("Петр");

        UnifiedBooking u = UnifiedBooking.fromPersonal(b);
        assertEquals("Проведено", u.getStatusLine());
    }

    @Test
    public void fromGroupSession_buildsDetailLine() {
        Session s = new Session();
        s.setId("gs1");
        s.setTitle("Йога");
        s.setStartTime(TEST_START);
        s.setEndTime(TEST_END);
        s.setTrainerName("Мария");
        s.setDirectionName("Йога");

        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertEquals(UnifiedBooking.Kind.GROUP, u.getKind());
        assertEquals("gs1", u.getId());
        assertEquals("Йога", u.getTitleLine());
        assertEquals("Запись на групповое занятие", u.getStatusLine());
        assertEquals("Групповое", u.getKindBadge());

        // Дата/время + тренер + направление
        assertEquals("30.03.2026 10:00 · Мария · Йога", u.getDetailLine());
    }

    @Test
    public void fromGroupSession_missingTrainerName_omitsFromDetail() {
        Session s = new Session();
        s.setId("gs2");
        s.setTitle("Пилатес");
        s.setStartTime(TEST_START);
        s.setEndTime(TEST_END);
        s.setTrainerName(null);
        s.setDirectionName("Пилатес");

        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertEquals("30.03.2026 10:00 · Пилатес", u.getDetailLine());
    }

    @Test
    public void fromGroupSession_missingDirectionName_omitsFromDetail() {
        Session s = new Session();
        s.setId("gs3");
        s.setTitle("Кроссфит");
        s.setStartTime(TEST_START);
        s.setEndTime(TEST_END);
        s.setTrainerName("Алексей");
        s.setDirectionName(null);

        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertEquals("30.03.2026 10:00 · Алексей", u.getDetailLine());
    }

    @Test
    public void fromGroupSession_missingBothTrainerAndDirection_showsOnlyDateTime() {
        Session s = new Session();
        s.setId("gs4");
        s.setTitle("Стретчинг");
        s.setStartTime(TEST_START);
        s.setEndTime(TEST_END);
        s.setTrainerName(null);
        s.setDirectionName(null);

        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertEquals("30.03.2026 10:00", u.getDetailLine());
    }

    @Test
    public void fromGroupSession_usesTitleForTitleLine() {
        Session s = new Session();
        s.setId("gs5");
        s.setTitle("Zumba");
        s.setStartTime(TEST_START);
        s.setEndTime(TEST_END);
        s.setTrainerName("Елена");
        s.setDirectionName("Танцы");

        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertEquals("Zumba", u.getTitleLine());
    }

    @Test
    public void fromGroupSession_startTimeWithoutEndTime_handlesGracefully() {
        Session s = new Session();
        s.setId("gs6");
        s.setTitle("Бокс");
        s.setStartTime(TEST_START);
        s.setEndTime(null);
        s.setTrainerName("Дмитрий");
        s.setDirectionName("Боевые искусства");

        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertNotNull(u.getDetailLine());
        assertTrue(u.getDetailLine().startsWith("30.03.2026 10:00"));
    }

    @Test
    public void fromGroupSession_nullStartTime_handlesGracefully() {
        Session s = new Session();
        s.setId("gs7");
        s.setTitle("Медитация");
        s.setStartTime(null);
        s.setEndTime(TEST_END);
        s.setTrainerName("Ольга");
        s.setDirectionName("Релакс");

        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertEquals("", u.getDetailLine());
    }

    @Test
    public void fromGroupSession_statusLine_alwaysReturnsBookingText() {
        Session s = new Session();
        s.setId("gs8");
        s.setTitle("Тай-бо");
        s.setStartTime(TEST_START);
        s.setEndTime(TEST_END);

        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertEquals("Запись на групповое занятие", u.getStatusLine());
    }

    @Test
    public void fromGroupSession_kindBadge_alwaysReturnsGroupText() {
        Session s = new Session();
        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertEquals("Групповое", u.getKindBadge());
    }

    @Test
    public void fromGroupSession_sortTimeMillis_returnsZero() {
        Session s = new Session();
        UnifiedBooking u = UnifiedBooking.fromGroupSession(s);
        assertEquals(0L, u.getSortTimeMillis());
    }

    @Test
    public void fromPersonal_withCustomStatus_usesRawStatus() {
        UserPersonalBooking b = new UserPersonalBooking("pb6", "t6", "04.04.2026, 15:00", "pending_review", 2000L);
        b.setTrainerName("Сергей");

        UnifiedBooking u = UnifiedBooking.fromPersonal(b);
        assertEquals("pending_review", u.getStatusLine());
    }

    @Test
    public void fromPersonal_sortTimeMillis_passedThrough() {
        UserPersonalBooking b = new UserPersonalBooking("pb7", "t7", "05.04.2026, 16:00", "requested", 1744128000000L);

        UnifiedBooking u = UnifiedBooking.fromPersonal(b);
        assertEquals(1744128000000L, u.getSortTimeMillis());
    }

    @Test
    public void fromPersonal_detailLine_matchesDateTimeFormatted() {
        UserPersonalBooking b = new UserPersonalBooking("pb8", "t8", "06.04.2026, 17:30", "approved", 0L);

        UnifiedBooking u = UnifiedBooking.fromPersonal(b);
        assertEquals("06.04.2026, 17:30", u.getDetailLine());
    }
}



