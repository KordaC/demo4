package com.example.myapplication.your.data;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import okhttp3.mockwebserver.RecordedRequest;

/**
 * API-тесты AuthRepository через MockWebServer.
 */
public class AuthRepositoryApiTest extends BaseRepositoryApiTest {

    private static final String TEST_KEY = "test-anon-key-123";

    // ======================== POST /auth/v1/token (login) ========================

    @Test
    public void login_200_returnsTokenAndUser() throws Exception {
        String tokenResponse = authTokenResponse(
                "fake-jwt-access-token",
                "user-uuid-001",
                "test@example.com",
                "Алексей"
        );
        enqueueJsonObject(tokenResponse);

        String url = mockBaseUrl + "auth/v1/token?grant_type=password";
        String body = "{\"email\":\"test@example.com\",\"password\":\"secret123\"}";
        String response = makePostRequest(url, body);

        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
        assertEquals("fake-jwt-access-token", json.get("access_token").getAsString());
        assertEquals("user-uuid-001", json.get("user").getAsJsonObject().get("id").getAsString());
        assertEquals("test@example.com", json.get("user").getAsJsonObject().get("email").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/auth/v1/token", "grant_type=password");
    }

    @Test
    public void login_400_wrongPassword_returnsError() throws Exception {
        enqueueResponse(400,
                "{\"error_code\":400,\"msg\":\"Invalid login credentials\"}");

        String url = mockBaseUrl + "auth/v1/token?grant_type=password";
        String body = "{\"email\":\"test@example.com\",\"password\":\"wrong\"}";

        try {
            makePostRequest(url, body);
            fail("Ожидалось исключение при 400");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("400") || e.getMessage().contains("Invalid"));
        }
    }

    @Test
    public void login_401_unverifiedEmail() throws Exception {
        enqueueResponse(401,
                "{\"error_code\":401,\"msg\":\"Email not confirmed\"}");

        String url = mockBaseUrl + "auth/v1/token?grant_type=password";
        String body = "{\"email\":\"unverified@example.com\",\"password\":\"secret\"}";

        try {
            makePostRequest(url, body);
            fail("Ожидалось исключение при 401");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("401") || e.getMessage().contains("Email"));
        }
    }

    // ======================== POST /auth/v1/signup ========================

    @Test
    public void signup_200_returnsPendingConfirmation() throws Exception {
        String signupResponse = "{"
                + "\"email\":\"newuser@example.com\","
                + "\"confirmation_sent_at\":\"2025-04-14T10:00:00Z\""
                + "}";
        enqueueJsonObject(signupResponse);

        String url = mockBaseUrl + "auth/v1/signup";
        String body = "{\"email\":\"newuser@example.com\",\"password\":\"secret123\",\"data\":{\"name\":\"Новый\"}}";
        String response = makePostRequest(url, body);

        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
        assertEquals("newuser@example.com", json.get("email").getAsString());
        assertFalse(json.has("access_token"));

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/auth/v1/signup");
    }

    @Test
    public void signup_400_emailAlreadyRegistered() throws Exception {
        enqueueResponse(400,
                "{\"error_code\":400,\"msg\":\"User already registered\"}");

        String url = mockBaseUrl + "auth/v1/signup";
        String body = "{\"email\":\"exists@example.com\",\"password\":\"secret\"}";

        try {
            makePostRequest(url, body);
            fail("Ожидалось исключение");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("400") || e.getMessage().contains("already"));
        }
    }

    // ======================== POST /auth/v1/verify (OTP) ========================

    @Test
    public void verifyOtp_200_returnsToken() throws Exception {
        String verifyResponse = authTokenResponse(
                "verified-jwt-token",
                "user-uuid-002",
                "otpuser@example.com",
                "ОТП"
        );
        enqueueJsonObject(verifyResponse);

        String url = mockBaseUrl + "auth/v1/verify";
        String body = "{\"type\":\"signup\",\"email\":\"otpuser@example.com\",\"token\":\"123456\"}";
        String response = makePostRequest(url, body);

        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
        assertEquals("verified-jwt-token", json.get("access_token").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/auth/v1/verify");
    }

    @Test
    public void verifyOtp_400_invalidToken() throws Exception {
        enqueueResponse(400,
                "{\"error_code\":400,\"msg\":\"Invalid token\"}");

        String url = mockBaseUrl + "auth/v1/verify";
        String body = "{\"type\":\"signup\",\"email\":\"otpuser@example.com\",\"token\":\"wrong\"}";

        try {
            makePostRequest(url, body);
            fail("Ожидалось исключение");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("400") || e.getMessage().contains("Invalid"));
        }
    }

    @Test
    public void verifyOtp_403_expiredToken() throws Exception {
        enqueueResponse(403,
                "{\"error_code\":403,\"msg\":\"Token has expired\"}");

        String url = mockBaseUrl + "auth/v1/verify";
        String body = "{\"type\":\"signup\",\"email\":\"otpuser@example.com\",\"token\":\"expired\"}";

        try {
            makePostRequest(url, body);
            fail("Ожидалось исключение");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("403") || e.getMessage().contains("expired"));
        }
    }

    // ======================== POST /auth/v1/token?grant_type=refresh_token ========================

    @Test
    public void refresh_200_returnsNewToken() throws Exception {
        String refreshResponse = authTokenResponse(
                "new-access-token",
                "user-uuid-001",
                "test@example.com",
                "Алексей"
        );
        enqueueJsonObject(refreshResponse);

        String url = mockBaseUrl + "auth/v1/token?grant_type=refresh_token";
        String body = "{\"refresh_token\":\"refresh-token-123\"}";
        String response = makePostRequest(url, body);

        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
        assertEquals("new-access-token", json.get("access_token").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/auth/v1/token", "grant_type=refresh_token");
    }

    @Test
    public void refresh_400_invalidRefreshToken() throws Exception {
        enqueueResponse(400,
                "{\"error_code\":400,\"msg\":\"Invalid Refresh Token\"}");

        String url = mockBaseUrl + "auth/v1/token?grant_type=refresh_token";
        String body = "{\"refresh_token\":\"invalid-token\"}";

        try {
            makePostRequest(url, body);
            fail("Ожидалось исключение");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("400") || e.getMessage().contains("Invalid"));
        }
    }

    @Test
    public void refresh_403_expiredRefreshToken() throws Exception {
        enqueueResponse(403,
                "{\"error_code\":403,\"msg\":\"Refresh Token has expired\"}");

        String url = mockBaseUrl + "auth/v1/token?grant_type=refresh_token";
        String body = "{\"refresh_token\":\"expired-refresh\"}";

        try {
            makePostRequest(url, body);
            fail("Ожидалось исключение");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("403") || e.getMessage().contains("expired"));
        }
    }

    // ======================== PATCH /rest/v1/app_user (role update) ========================

    @Test
    public void patchUserRole_200_success() throws Exception {
        enqueueResponse(200, "");

        String url = mockBaseUrl + "rest/v1/app_user?id=eq.user-uuid-001";
        String body = "{\"role\":\"trainer\"}";
        String response = makePatchRequest(url, body);

        assertNotNull(response);

        RecordedRequest request = takeRequestAndCheckMethod("PATCH");
        assertPathContains(request, "/rest/v1/app_user", "id=eq.user-uuid-001");
    }

    @Test
    public void patchUserRole_403_rlsDenied() throws Exception {
        enqueueResponse(403,
                "{\"message\":\"new row violates row-level security policy\"}");

        String url = mockBaseUrl + "rest/v1/app_user?id=eq.user-uuid-001";
        String body = "{\"role\":\"admin\"}";

        try {
            makePatchRequest(url, body);
            fail("Ожидалось исключение");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("403") || e.getMessage().contains("security"));
        }
    }

    // ======================== POST /rest/v1/rpc/get_my_app_role ========================

    @Test
    public void rpcGetMyAppRole_200_returnsTrainer() throws Exception {
        enqueueResponse(200, "\"trainer\"");

        String url = mockBaseUrl + "rest/v1/rpc/get_my_app_role";
        String body = "{}";
        String response = makePostRequest(url, body);

        // Ответ — строка "trainer", без кавычек JSON
        String trimmed = response.trim().replace("\"", "");
        assertEquals("trainer", trimmed);

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/rest/v1/rpc/get_my_app_role");
    }

    @Test
    public void rpcGetMyAppRole_404_rpcNotFound() throws Exception {
        enqueueResponse(404, "{\"message\":\"RPC not found\"}");

        String url = mockBaseUrl + "rest/v1/rpc/get_my_app_role";
        String body = "{}";

        try {
            makePostRequest(url, body);
            fail("Ожидалось исключение");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("404"));
        }
    }

    // ======================== Проверка заголовков ========================

    @Test
    public void login_includesApikeyAndContentType() throws Exception {
        enqueueJsonObject(authTokenResponse("t", "u", "e@x.com", "N"));

        String url = mockBaseUrl + "auth/v1/token?grant_type=password";
        String body = "{\"email\":\"e@x.com\",\"password\":\"p\"}";
        makePostRequest(url, body);

        RecordedRequest request = server.takeRequest();
        assertEquals("POST", request.getMethod());
        assertEquals("application/json", request.getHeader("Content-Type"));
    }

    // ======================== Утилиты HTTP ========================

    private String makePostRequest(String urlString, String jsonBody) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("apikey", TEST_KEY);
        conn.setRequestProperty("Authorization", "Bearer " + TEST_KEY);
        conn.setDoOutput(true);

        byte[] input = jsonBody.getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(input, 0, input.length);
        }

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null && code < 400) throw new Exception("HTTP " + code + ": пустой stream");

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }

    private String makePatchRequest(String urlString, String jsonBody) throws Exception {
        URL url = new URL(urlString);
        // OkHttp-подход для PATCH: используем POST + X-HTTP-Method-Override,
        // т.к. HttpURLConnection не поддерживает PATCH на некоторых JVM
        okhttp3.OkHttpClient client = new okhttp3.OkHttpClient();
        okhttp3.RequestBody body = okhttp3.RequestBody.create(
                jsonBody, okhttp3.MediaType.parse("application/json"));
        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(urlString)
                .method("PATCH", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("apikey", TEST_KEY)
                .addHeader("Authorization", "Bearer " + TEST_KEY)
                .addHeader("Prefer", "return=minimal")
                .build();

        try (okhttp3.Response response = client.newCall(request).execute()) {
            int code = response.code();
            String responseBody = response.body() != null ? response.body().string() : "";
            if (code >= 400) {
                throw new Exception("HTTP " + code + ": " + responseBody);
            }
            return responseBody;
        }
    }
}
