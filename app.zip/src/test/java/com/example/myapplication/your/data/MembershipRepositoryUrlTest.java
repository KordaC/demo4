package com.example.myapplication.your.data;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Тестируем только формат URL, без сетевых вызовов.
 */
public class MembershipRepositoryUrlTest {

    @Test
    public void avatarPublicUrl_cacheBustParamPresent() {
        // Формат, который сейчас используется в MembershipRepository.uploadUserAvatarFile:
        // {SUPABASE_URL}/storage/v1/object/public/avatars/{uid}/avatar.jpg?v={timestamp}
        String supabaseUrl = "https://example.supabase.co";
        String uid = "00000000-0000-0000-0000-000000000000";
        String objectPath = uid + "/avatar.jpg";
        long v = 1712486400000L;
        String url = supabaseUrl + "/storage/v1/object/public/avatars/" + objectPath + "?v=" + v;

        assertTrue(url.contains("/storage/v1/object/public/avatars/" + uid + "/avatar.jpg"));
        assertTrue(url.contains("?v="));
    }
}

