package com.example.myapplication.your.util;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ValidationUtilsTest {

    @Test
    public void isValidIsoDate_acceptsYyyyMmDd() {
        assertTrue(ValidationUtils.isValidIsoDate("2026-04-07"));
        assertTrue(ValidationUtils.isValidIsoDate(" 2026-04-07 "));
    }

    @Test
    public void isValidIsoDate_rejectsInvalidOrEmpty() {
        assertFalse(ValidationUtils.isValidIsoDate(null));
        assertFalse(ValidationUtils.isValidIsoDate(""));
        assertFalse(ValidationUtils.isValidIsoDate("2026-13-01"));
        assertFalse(ValidationUtils.isValidIsoDate("07.04.2026"));
    }

    @Test
    public void russianPhone_acceptsCommonForms() {
        assertTrue(ValidationUtils.isValidRussianPhone("+7 999 123-45-67"));
        assertTrue(ValidationUtils.isValidRussianPhone("8 (999) 123-45-67"));
        assertTrue(ValidationUtils.isValidRussianPhone("9991234567"));
        assertTrue(ValidationUtils.isValidRussianPhone("79991234567"));
    }

    @Test
    public void russianPhone_rejectsShortOrNonRussian() {
        assertFalse(ValidationUtils.isValidRussianPhone(null));
        assertFalse(ValidationUtils.isValidRussianPhone("123"));
        assertFalse(ValidationUtils.isValidRussianPhone("+1 555 123 4567"));
        assertFalse(ValidationUtils.isValidRussianPhone("900123456")); // 9 digits
    }

    @Test
    public void meetsPasswordRules_requiresLetterDigitAndSpecial() {
        assertFalse(ValidationUtils.meetsPasswordRules(null));
        assertFalse(ValidationUtils.meetsPasswordRules("12345!"));     // no letter
        assertFalse(ValidationUtils.meetsPasswordRules("abcdef!"));    // no digit
        assertFalse(ValidationUtils.meetsPasswordRules("abc1234"));    // no special
        assertFalse(ValidationUtils.meetsPasswordRules("a1!  "));      // too short (len<6)
        assertTrue(ValidationUtils.meetsPasswordRules("abc123!"));
        assertTrue(ValidationUtils.meetsPasswordRules("Пароль1!"));
    }

    @Test
    public void looksLikePhone_and_looksLikeEmail() {
        assertTrue(ValidationUtils.looksLikeEmail("a@b.com"));
        assertFalse(ValidationUtils.looksLikeEmail("9991234567"));

        assertTrue(ValidationUtils.looksLikePhone("+7 (999) 123-45-67"));
        assertTrue(ValidationUtils.looksLikePhone("9991234567"));
        assertFalse(ValidationUtils.looksLikePhone("a@b.com"));
    }
    @Test
    public void looksLikeEmail_acceptsValidEmails() {
        assertTrue(ValidationUtils.looksLikeEmail("user@example.com"));
        assertTrue(ValidationUtils.looksLikeEmail("name.surname@domain.co.uk"));
        assertTrue(ValidationUtils.looksLikeEmail("test+label@domain.org"));
    }

    @Test
    public void looksLikeEmail_rejectsInvalidEmails() {
        assertFalse(ValidationUtils.looksLikeEmail(null));
        assertFalse(ValidationUtils.looksLikeEmail(""));
        assertFalse(ValidationUtils.looksLikeEmail("user@"));
        assertFalse(ValidationUtils.looksLikeEmail("@domain.com"));
        assertFalse(ValidationUtils.looksLikeEmail("user@domain"));
    }

    @Test
    public void looksLikePhone_acceptsValidPhoneForms() {
        assertTrue(ValidationUtils.looksLikePhone("+7 999 123-45-67"));
        assertTrue(ValidationUtils.looksLikePhone("8 (999) 123-45-67"));
        assertTrue(ValidationUtils.looksLikePhone("9991234567"));
        assertTrue(ValidationUtils.looksLikePhone("+79991234567"));
    }

    @Test
    public void looksLikePhone_rejectsInvalidPhones() {
        assertFalse(ValidationUtils.looksLikePhone(null));
        assertFalse(ValidationUtils.looksLikePhone(""));
        assertFalse(ValidationUtils.looksLikePhone("123"));
        assertFalse(ValidationUtils.looksLikePhone("abc"));
        assertFalse(ValidationUtils.looksLikePhone("a@b.com"));
    }

    @Test
    public void meetsPasswordRules_rejectsTooShortPasswords() {
        assertFalse(ValidationUtils.meetsPasswordRules("a1!"));
        assertFalse(ValidationUtils.meetsPasswordRules("Ab1!"));
    }

    @Test
    public void meetsPasswordRules_rejectsMissingDigit() {
        assertFalse(ValidationUtils.meetsPasswordRules("abcdef!"));
        assertFalse(ValidationUtils.meetsPasswordRules("Password!"));
    }

    @Test
    public void meetsPasswordRules_rejectsMissingLetter() {
        assertFalse(ValidationUtils.meetsPasswordRules("123456!"));
        assertFalse(ValidationUtils.meetsPasswordRules("123!@#"));
    }

    @Test
    public void meetsPasswordRules_rejectsMissingSpecial() {
        assertFalse(ValidationUtils.meetsPasswordRules("abc12345"));
        assertFalse(ValidationUtils.meetsPasswordRules("Password123"));
    }

    @Test
    public void meetsPasswordRules_acceptsValidPasswords() {
        assertTrue(ValidationUtils.meetsPasswordRules("abc123!"));
        assertTrue(ValidationUtils.meetsPasswordRules("Пароль1!"));
        assertTrue(ValidationUtils.meetsPasswordRules("StrongP@ss1"));
    }

    @Test
    public void meetsPasswordRules_handlesNullAndEmpty() {
        assertFalse(ValidationUtils.meetsPasswordRules(null));
        assertFalse(ValidationUtils.meetsPasswordRules(""));
    }

    @Test
    public void isValidRussianPhone_acceptsAllRussianFormats() {
        assertTrue(ValidationUtils.isValidRussianPhone("+79991234567"));
        assertTrue(ValidationUtils.isValidRussianPhone("8-999-123-45-67"));
        assertTrue(ValidationUtils.isValidRussianPhone("89991234567"));
        assertTrue(ValidationUtils.isValidRussianPhone("+7 999 123-45-67"));
    }

    @Test
    public void isValidRussianPhone_rejectsNonRussian() {
        assertFalse(ValidationUtils.isValidRussianPhone("+19991234567"));
        assertFalse(ValidationUtils.isValidRussianPhone("1234567"));
    }

    @Test
    public void isValidIsoDate_acceptsValidDates() {
        assertTrue(ValidationUtils.isValidIsoDate("2026-04-07"));
        assertTrue(ValidationUtils.isValidIsoDate("2026-12-31"));
        assertTrue(ValidationUtils.isValidIsoDate("2026-01-01"));
    }

    @Test
    public void isValidIsoDate_rejectsInvalidDates() {
        assertFalse(ValidationUtils.isValidIsoDate("2026-13-01"));
        assertFalse(ValidationUtils.isValidIsoDate("2026-00-01"));
        assertFalse(ValidationUtils.isValidIsoDate("2026-04-32"));
        assertFalse(ValidationUtils.isValidIsoDate("07.04.2026"));
    }
}


