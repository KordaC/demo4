package com.example.myapplication.your.data;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import okhttp3.mockwebserver.RecordedRequest;

/**
 * API-тесты MembershipRepository через MockWebServer.
 */
public class MembershipRepositoryApiTest extends BaseRepositoryApiTest {

    private static final String TEST_KEY = "test-anon-key-123";
    private static final String TEST_TOKEN = "test-jwt-token";

    // ======================== GET /rest/v1/membership_plan ========================

    @Test
    public void getAllPlans_200_returnsPlansList() throws Exception {
        String plansBody = "["
                + membershipPlanJson("plan-1", "Месяц", 5000, 30, 20, 5, true)
                + ","
                + membershipPlanJson("plan-2", "Квартал", 12000, 90, 60, 10, true)
                + "]";

        enqueueJsonArray(plansBody);

        String url = mockBaseUrl + "rest/v1/membership_plan?is_active=eq.true&select=*&order=price.asc";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(2, jsonArray.size());

        JsonObject first = jsonArray.get(0).getAsJsonObject();
        assertEquals("plan-1", first.get("id").getAsString());
        assertEquals("Месяц", first.get("name").getAsString());
        assertEquals(5000, first.get("price").getAsInt());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "/rest/v1/membership_plan");
    }

    @Test
    public void getAllPlans_empty_returnsEmptyList() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/membership_plan?is_active=eq.true&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    @Test
    public void getAllPlans_500_throwsException() throws Exception {
        enqueue500();

        String url = mockBaseUrl + "rest/v1/membership_plan?is_active=eq.true&select=*";

        try {
            makeGetRequest(url);
            fail("Ожидалось исключение при 500");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("500"));
        }
    }

    @Test
    public void getPlanById_200_returnsSinglePlan() throws Exception {
        String planBody = "[" + membershipPlanJson("plan-99", "Неделя", 1500, 7, 5, 0, true) + "]";
        enqueueJsonArray(planBody);

        String url = mockBaseUrl + "rest/v1/membership_plan?id=eq.plan-99";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());
        assertEquals("plan-99", jsonArray.get(0).getAsJsonObject().get("id").getAsString());
    }

    @Test
    public void getPlanById_notFound_emptyArray() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/membership_plan?id=eq.nonexistent";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    // ======================== GET /rest/v1/membership_purchase ========================

    @Test
    public void getActiveMemberships_200_returnsPurchases() throws Exception {
        String purchasesBody = "["
                + membershipPurchaseJson("purchase-1", "user-1", "plan-1",
                        "2025-04-01", "2025-05-01", "active", 20, 5)
                + "]";

        enqueueJsonArray(purchasesBody);

        String url = mockBaseUrl + "rest/v1/membership_purchase"
                + "?user_id=eq.user-1&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());

        JsonObject purchase = jsonArray.get(0).getAsJsonObject();
        assertEquals("purchase-1", purchase.get("id").getAsString());
        assertEquals("active", purchase.get("status").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "/rest/v1/membership_purchase", "user_id=eq.user-1");
    }

    @Test
    public void getActiveMemberships_noActive_returnsEmpty() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/membership_purchase?user_id=eq.user-1&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    @Test
    public void getActiveMemberships_frozen_returnsFrozenPurchase() throws Exception {
        String frozenBody = "["
                + membershipPurchaseJson("purchase-2", "user-2", "plan-2",
                        "2025-03-01", "2025-06-01", "frozen", 60, 15)
                + "]";

        enqueueJsonArray(frozenBody);

        String url = mockBaseUrl + "rest/v1/membership_purchase?user_id=eq.user-2&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());
        assertEquals("frozen", jsonArray.get(0).getAsJsonObject().get("status").getAsString());
    }

    // ======================== POST /rest/v1/membership_purchase ========================

    @Test
    public void purchaseMembership_201_success() throws Exception {
        String createdBody = "{"
                + "\"id\":\"purchase-new\","
                + "\"user_id\":\"user-1\","
                + "\"plan_id\":\"plan-1\","
                + "\"status\":\"active\""
                + "}";

        enqueueResponse(201, createdBody);

        String url = mockBaseUrl + "rest/v1/membership_purchase";
        String body = "{\"user_id\":\"user-1\",\"plan_id\":\"plan-1\",\"status\":\"active\"}";

        String response = makePostRequestWithAuth(url, body);

        JsonObject result = JsonParser.parseString(response).getAsJsonObject();
        assertEquals("purchase-new", result.get("id").getAsString());
        assertEquals("active", result.get("status").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/rest/v1/membership_purchase");
    }

    @Test
    public void purchaseMembership_409_duplicate_throwsException() throws Exception {
        enqueueResponse(409,
                "{\"message\":\"duplicate key value violates unique constraint\","
                        + "\"code\":\"23505\"}");

        String url = mockBaseUrl + "rest/v1/membership_purchase";
        String body = "{\"user_id\":\"user-1\",\"plan_id\":\"plan-1\",\"status\":\"active\"}";

        try {
            makePostRequestWithAuth(url, body);
            fail("Ожидалось исключение при 409");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("409") || e.getMessage().contains("23505"));
        }
    }

    // ======================== PATCH /rest/v1/membership_purchase (freeze/unfreeze) ========================

    @Test
    public void freezeMembership_200_success() throws Exception {
        enqueueResponse(200, "");

        String url = mockBaseUrl + "rest/v1/membership_purchase?id=eq.purchase-1";
        String body = "{\"status\":\"frozen\",\"freeze_days_used\":5}";

        String response = makePatchRequestWithAuth(url, body);
        assertNotNull(response);

        RecordedRequest request = takeRequestAndCheckMethod("PATCH");
        assertPathContains(request, "/rest/v1/membership_purchase", "id=eq.purchase-1");
    }

    @Test
    public void unfreezeMembership_200_success() throws Exception {
        enqueueResponse(200, "");

        String url = mockBaseUrl + "rest/v1/membership_purchase?id=eq.purchase-1";
        String body = "{\"status\":\"active\"}";

        String response = makePatchRequestWithAuth(url, body);
        assertNotNull(response);

        RecordedRequest request = takeRequestAndCheckMethod("PATCH");
        assertPathContains(request, "id=eq.purchase-1");
    }

    // ======================== POST/GET/PATCH /rest/v1/app_user ========================

    @Test
    public void ensureAppUser_upsert_200_success() throws Exception {
        String upsertedBody = "["
                + "{\"id\":\"user-1\",\"email\":\"test@example.com\",\"name\":\"Алексей\"}"
                + "]";

        enqueueJsonArray(upsertedBody);

        String url = mockBaseUrl + "rest/v1/app_user";
        String body = "{\"id\":\"user-1\",\"email\":\"test@example.com\",\"name\":\"Алексей\"}";

        String response = makePostRequestWithAuth(url, body);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());
        assertEquals("user-1", jsonArray.get(0).getAsJsonObject().get("id").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/rest/v1/app_user");
    }

    @Test
    public void patchAppUser_200_success() throws Exception {
        enqueueResponse(200, "");

        String url = mockBaseUrl + "rest/v1/app_user?id=eq.user-1";
        String body = "{\"name\":\"НовоеИмя\",\"phone\":\"+79001234567\"}";

        String response = makePatchRequestWithAuth(url, body);
        assertNotNull(response);

        RecordedRequest request = takeRequestAndCheckMethod("PATCH");
        assertPathContains(request, "/rest/v1/app_user", "id=eq.user-1");
    }

    @Test
    public void getAppUserById_exists_returnsRow() throws Exception {
        String userBody = "["
                + "{\"id\":\"user-1\",\"email\":\"test@example.com\"}"
                + "]";

        enqueueJsonArray(userBody);

        String url = mockBaseUrl + "rest/v1/app_user?id=eq.user-1&select=id&limit=1";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());
        assertEquals("user-1", jsonArray.get(0).getAsJsonObject().get("id").getAsString());
    }

    @Test
    public void getAppUserById_notFound_emptyArray() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/app_user?id=eq.nonexistent&select=id&limit=1";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    // ======================== RPC /rest/v1/rpc/ensure_app_user_for_auth ========================

    @Test
    public void rpcEnsureAppUser_200_success() throws Exception {
        enqueueResponse(200, "");

        String url = mockBaseUrl + "rest/v1/rpc/ensure_app_user_for_auth";
        String body = "{\"p_email\":\"test@example.com\"}";

        String response = makePostRequestWithAuth(url, body);
        assertNotNull(response);

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/rest/v1/rpc/ensure_app_user_for_auth");
    }

    @Test
    public void rpcEnsureAppUser_404_rpcNotFound() throws Exception {
        enqueueResponse(404, "{\"message\":\"RPC not found\"}");

        String url = mockBaseUrl + "rest/v1/rpc/ensure_app_user_for_auth";
        String body = "{\"p_email\":\"test@example.com\"}";

        try {
            makePostRequestWithAuth(url, body);
            fail("Ожидалось исключение при 404");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("404"));
        }
    }

    // ======================== Утилиты JSON ========================

    private String membershipPlanJson(String id, String name, int price, int durationDays,
                                       int groupVisitsPerMonth, int freezeDaysAllowed,
                                       boolean includesGroupPrograms) {
        return "{"
                + "\"id\":\"" + id + "\","
                + "\"name\":\"" + name + "\","
                + "\"price\":" + price + ","
                + "\"duration_days\":" + durationDays + ","
                + "\"group_visits_per_month\":" + groupVisitsPerMonth + ","
                + "\"freeze_days_allowed\":" + freezeDaysAllowed + ","
                + "\"includes_group_programs\":" + includesGroupPrograms
                + "}";
    }

    private String membershipPurchaseJson(String id, String userId, String planId,
                                           String startDate, String endDate, String status,
                                           int groupVisitsRemaining, int freezeDaysUsed) {
        return "{"
                + "\"id\":\"" + id + "\","
                + "\"user_id\":\"" + userId + "\","
                + "\"plan_id\":\"" + planId + "\","
                + "\"start_date\":\"" + startDate + "\","
                + "\"end_date\":\"" + endDate + "\","
                + "\"status\":\"" + status + "\","
                + "\"group_visits_remaining\":" + groupVisitsRemaining + ","
                + "\"freeze_days_used\":" + freezeDaysUsed
                + "}";
    }

    // ======================== Утилиты HTTP ========================

    private String makeGetRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null) throw new Exception("HTTP " + code + ": пустой stream");

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }

    private String makePostRequestWithAuth(String urlString, String jsonBody) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("apikey", TEST_KEY);
        conn.setRequestProperty("Authorization", "Bearer " + TEST_TOKEN);
        conn.setDoOutput(true);

        byte[] input = jsonBody.getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(input, 0, input.length);
        }

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null && code < 400) throw new Exception("HTTP " + code + ": пустой stream");

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }

    private String makePatchRequestWithAuth(String urlString, String jsonBody) throws Exception {
        okhttp3.OkHttpClient client = new okhttp3.OkHttpClient();
        okhttp3.RequestBody body = okhttp3.RequestBody.create(
                jsonBody, okhttp3.MediaType.parse("application/json"));
        okhttp3.Request request = new okhttp3.Request.Builder()
                .url(urlString)
                .method("PATCH", body)
                .addHeader("Content-Type", "application/json")
                .addHeader("apikey", TEST_KEY)
                .addHeader("Authorization", "Bearer " + TEST_TOKEN)
                .addHeader("Prefer", "return=minimal")
                .build();

        try (okhttp3.Response response = client.newCall(request).execute()) {
            int code = response.code();
            String responseBody = response.body() != null ? response.body().string() : "";
            if (code >= 400) {
                throw new Exception("HTTP " + code + ": " + responseBody);
            }
            return responseBody;
        }
    }
}
