package com.example.myapplication.your.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import java.time.LocalDateTime;

public class TimestampParseUtilTest {

    @Test
    public void parseSupabaseTimestampToLocal_nullOrEmpty_returnsNull() {
        assertNull(TimestampParseUtil.parseSupabaseTimestampToLocal(null));
        assertNull(TimestampParseUtil.parseSupabaseTimestampToLocal(""));
        assertNull(TimestampParseUtil.parseSupabaseTimestampToLocal("   "));
    }

    @Test
    public void parseSupabaseTimestampToLocal_acceptsSpaceSeparatedTimestamp() {
        // Формат, который иногда возвращают SQL/логи: "YYYY-MM-DD HH:MM:SS"
        LocalDateTime dt = TimestampParseUtil.parseSupabaseTimestampToLocal("2026-04-07 10:11:12");
        // Внутри утилиты такой формат трактуется как UTC-наивный и конвертится в local.
        // Поэтому час зависит от временной зоны запуска теста; проверяем только дату и минуты.
        assertEquals(2026, dt.getYear());
        assertEquals(4, dt.getMonthValue());
        assertEquals(7, dt.getDayOfMonth());
        assertEquals(11, dt.getMinute());
    }
    @Test
    public void parseSupabaseTimestampToLocal_acceptsStandardIsoFormat() {
        LocalDateTime dt = TimestampParseUtil.parseSupabaseTimestampToLocal("2026-04-07T10:11:12");
        assertNotNull(dt);
        assertEquals(2026, dt.getYear());
        assertEquals(4, dt.getMonthValue());
        assertEquals(7, dt.getDayOfMonth());
    }

    @Test
    public void parseSupabaseTimestampToLocal_handlesMultipleSpaces() {
        LocalDateTime dt = TimestampParseUtil.parseSupabaseTimestampToLocal("2026-04-07  10:11:12");
        assertNotNull(dt);
        assertEquals(2026, dt.getYear());
    }


}

