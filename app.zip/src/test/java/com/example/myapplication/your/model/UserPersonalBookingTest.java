package com.example.myapplication.your.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class UserPersonalBookingTest {

//    @Test
//    public void statusDisplay_requested() {
//        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "requested", 0L);
//        assertEquals("Запланировано", b.getStatusDisplay());
//    }
//
//    @Test
//    public void statusDisplay_approved() {
//        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "approved", 0L);
//        assertEquals("Запланировано", b.getStatusDisplay());
//    }
//
//    @Test
//    public void statusDisplay_cancelled() {
//        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "cancelled", 0L);
//        assertEquals("Отменено", b.getStatusDisplay());
//    }
//
//    @Test
//    public void statusDisplay_unknown_returnsRaw() {
//        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "custom_status", 0L);
//        assertEquals("custom_status", b.getStatusDisplay());
//    }
@Test
public void statusDisplay_requested() {
    UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "requested", 0L);
    assertEquals("Запланировано", b.getStatusDisplay());
}

    @Test
    public void statusDisplay_approved() {
        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "approved", 0L);
        assertEquals("Запланировано", b.getStatusDisplay());
    }

    @Test
    public void statusDisplay_cancelled() {
        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "cancelled", 0L);
        assertEquals("Отменено", b.getStatusDisplay());
    }

    @Test
    public void statusDisplay_declined() {
        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "declined", 0L);
        assertEquals("Отменено", b.getStatusDisplay());
    }

    @Test
    public void statusDisplay_done() {
        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "done", 0L);
        assertEquals("Проведено", b.getStatusDisplay());
    }

    @Test
    public void statusDisplay_nullStatus() {
        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", null, 0L);
        assertEquals("", b.getStatusDisplay());
    }

    @Test
    public void statusDisplay_emptyStatus() {
        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "", 0L);
        assertEquals("", b.getStatusDisplay());
    }

    @Test
    public void statusDisplay_unknown_returnsRaw() {
        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "custom_status", 0L);
        assertEquals("custom_status", b.getStatusDisplay());
    }

    @Test
    public void constructor_setsFieldsCorrectly() {
        UserPersonalBooking b = new UserPersonalBooking("123", "trainer_456", "15.04.2026, 14:30", "requested", 1744727400000L);

        assertEquals("123", b.getId());
        assertEquals("trainer_456", b.getTrainerId());
        assertEquals("15.04.2026, 14:30", b.getDateTimeFormatted());
        assertEquals("requested", b.getStatus());
        assertEquals(1744727400000L, b.getSortTimeMillis());
    }

    @Test
    public void settersAndGetters_workCorrectly() {
        UserPersonalBooking b = new UserPersonalBooking("", "", "", "", 0L);

        b.setId("new_id");
        b.setTrainerId("new_trainer");
        b.setTrainerName("John Doe");
        b.setDateTimeFormatted("01.01.2026, 12:00");
        b.setStatus("approved");
        b.setSortTimeMillis(123456789L);

        assertEquals("new_id", b.getId());
        assertEquals("new_trainer", b.getTrainerId());
        assertEquals("John Doe", b.getTrainerName());
        assertEquals("01.01.2026, 12:00", b.getDateTimeFormatted());
        assertEquals("approved", b.getStatus());
        assertEquals(123456789L, b.getSortTimeMillis());
    }

    @Test
    public void statusDisplay_caseSensitive_returnsRawForUppercase() {
        UserPersonalBooking b = new UserPersonalBooking("1", "t1", "30.03.2026, 10:00", "REQUESTED", 0L);
        assertEquals("REQUESTED", b.getStatusDisplay());
    }
}


