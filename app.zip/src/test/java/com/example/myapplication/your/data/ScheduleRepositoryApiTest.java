package com.example.myapplication.your.data;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import okhttp3.mockwebserver.RecordedRequest;

/**
 * API-тесты ScheduleRepository через MockWebServer.
 * Тестируем HTTP-вызовы к Supabase без реального сервера.
 */
public class ScheduleRepositoryApiTest extends BaseRepositoryApiTest {

    // ======================== GET /rest/v1/session ========================

    @Test
    public void getUpcomingSessions_200_returnsParsedList() throws Exception {
        LocalDateTime future1 = LocalDateTime.now().plusHours(5);
        LocalDateTime future2 = LocalDateTime.now().plusHours(10);
        DateTimeFormatter fmt = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        String sessionsBody = "["
                + sessionJson("sess-1", "Йога", future1.format(fmt), future1.plusHours(1).format(fmt),
                        20, 5, "Иванов И.И.", "Йога", "Зал 1")
                + ","
                + sessionJson("sess-2", "Пилатес", future2.format(fmt), future2.plusHours(1).format(fmt),
                        15, 10, "Петрова А.С.", "Пилатес", "Зал 2")
                + "]";

        enqueueJsonArray(sessionsBody);

        String url = mockBaseUrl + "rest/v1/session?select=*&start_time=gte.2025-01-01T00:00:00&order=start_time.asc&limit=100";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(2, jsonArray.size());

        JsonObject first = jsonArray.get(0).getAsJsonObject();
        assertEquals("sess-1", first.get("id").getAsString());
        assertEquals("Йога", first.get("title").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "/rest/v1/session");
    }

    @Test
    public void getUpcomingSessions_emptyArray_returnsEmptyList() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/session?select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    @Test
    public void getUpcomingSessions_401_throwsException() throws Exception {
        enqueue401(null);

        String url = mockBaseUrl + "rest/v1/session?select=*";

        try {
            makeGetRequest(url);
            assertTrue("Ожидалось исключение при 401", false);
        } catch (Exception e) {
            assertTrue("Сообщение об ошибке должно содержать код",
                    e.getMessage().contains("401") || e.getMessage().contains("API key"));
        }
    }

    @Test
    public void getUpcomingSessions_500_throwsException() throws Exception {
        enqueue500();

        String url = mockBaseUrl + "rest/v1/session?select=*";

        try {
            makeGetRequest(url);
            assertTrue("Ожидалось исключение при 500", false);
        } catch (Exception e) {
            assertTrue("Сообщение об ошибке должно содержать 500",
                    e.getMessage().contains("500"));
        }
    }

    @Test
    public void getSessionById_200_returnsSingleSession() throws Exception {
        LocalDateTime future = LocalDateTime.now().plusHours(3);
        DateTimeFormatter fmt = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

        String body = "[" + sessionJson("sess-99", "Кроссфит",
                future.format(fmt), future.plusHours(1).format(fmt),
                25, 0, "Сидоров В.В.", "Кроссфит", "Зал 3") + "]";

        enqueueJsonArray(body);

        String url = mockBaseUrl + "rest/v1/session?id=eq.sess-99&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(1, jsonArray.size());
        assertEquals("sess-99", jsonArray.get(0).getAsJsonObject().get("id").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("GET");
        assertPathContains(request, "id=eq.sess-99");
    }

    @Test
    public void getSessionById_notFound_emptyArray() throws Exception {
        enqueueEmptyArray();

        String url = mockBaseUrl + "rest/v1/session?id=eq.nonexistent&select=*";
        String response = makeGetRequest(url);

        JsonArray jsonArray = JsonParser.parseString(response).getAsJsonArray();
        assertEquals(0, jsonArray.size());
    }

    // ======================== POST /rest/v1/session_signups ========================

    @Test
    public void signupSession_201_success() throws Exception {
        enqueueResponse(201, "{\"id\":\"signup-1\",\"session_id\":\"sess-1\",\"user_id\":\"user-1\"}");

        String url = mockBaseUrl + "rest/v1/session_signups";
        String body = "{\"session_id\":\"sess-1\",\"user_id\":\"user-1\"}";

        String response = makePostRequest(url, body);

        JsonObject result = JsonParser.parseString(response).getAsJsonObject();
        assertEquals("signup-1", result.get("id").getAsString());
        assertEquals("sess-1", result.get("session_id").getAsString());

        RecordedRequest request = takeRequestAndCheckMethod("POST");
        assertPathContains(request, "/rest/v1/session_signups");
    }

    @Test
    public void signupSession_duplicate_409_throwsException() throws Exception {
        enqueueResponse(409,
                "{\"message\":\"duplicate key value violates unique constraint\","
                        + "\"code\":\"23505\"}");

        String url = mockBaseUrl + "rest/v1/session_signups";
        String body = "{\"session_id\":\"sess-1\",\"user_id\":\"user-1\"}";

        try {
            makePostRequest(url, body);
            assertTrue("Ожидалось исключение при 409", false);
        } catch (Exception e) {
            assertTrue("Сообщение должно содержать 409 или 23505",
                    e.getMessage().contains("409") || e.getMessage().contains("23505"));
        }
    }

    // ======================== DELETE /rest/v1/session_signups ========================

    @Test
    public void cancelSession_200_success() throws Exception {
        enqueueResponse(200, "");

        String url = mockBaseUrl + "rest/v1/session_signups?session_id=eq.sess-1&user_id=eq.user-1";

        String response = makeDeleteRequest(url);
        assertNotNull(response);
    }

    // ======================== Проверка заголовков ========================

    @Test
    public void getSessions_includesCorrectHeaders() throws Exception {
        enqueueJsonArray("[]");

        String url = mockBaseUrl + "rest/v1/session?select=*";
        makeGetRequest(url);

        RecordedRequest request = server.takeRequest();
        assertNotNull(request);
        assertEquals("GET", request.getMethod());
    }

    // ======================== canCancelGroupSession ========================

    @Test
    public void canCancelGroupSession_moreThan2Hours_true() {
        LocalDateTime start = LocalDateTime.now().plusHours(3);
        assertTrue(ScheduleRepository.canCancelGroupSession(start));
    }

    @Test
    public void canCancelGroupSession_lessThan2Hours_false() {
        LocalDateTime start = LocalDateTime.now().plusHours(1);
        assertFalse(ScheduleRepository.canCancelGroupSession(start));
    }

    @Test
    public void canCancelGroupSession_exactly2Hours_false() {
        LocalDateTime start = LocalDateTime.now().plusHours(2);
        assertFalse(ScheduleRepository.canCancelGroupSession(start));
    }

    @Test
    public void canCancelGroupSession_nullTime_false() {
        assertFalse(ScheduleRepository.canCancelGroupSession(null));
    }

    // ======================== Утилиты HTTP ========================

    private String makeGetRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null) throw new Exception("HTTP " + code + ": пустой stream");

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }

    private String makePostRequest(String urlString, String jsonBody) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        byte[] input = jsonBody.getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(input, 0, input.length);
        }

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (stream == null && code < 400) throw new Exception("HTTP " + code + ": пустой stream");

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();

        if (code >= 400) {
            throw new Exception("HTTP " + code + ": " + sb);
        }
        return sb.toString();
    }

    private String makeDeleteRequest(String urlString) throws Exception {
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("DELETE");

        int code = conn.getResponseCode();
        java.io.InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();

        if (stream != null) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close();
            return sb.toString();
        }
        return "";
    }
}
